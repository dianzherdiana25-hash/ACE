"""E1.4e public development: source/meta-validated question selection."""
import argparse,json,re
from pathlib import Path
from e13.contract import canonical_json
from .e14e_bank import bank,digest,FAMILIES,REGIMES
from .e14e_policy import train,validate,decide,fit5,minimax_index,SEED,ABSTAIN
from .e14d_policy import context
from .cross_episode_candidate import choose,predict,POLICIES
from .query_bank import oracle

def score(t,word):
    arr=[int(predict(t.family,word,p['input'])==p['output']) for p in t.probes]
    return {'total':sum(arr),'natural':sum(arr[:4]),'diagnostic':sum(arr[4:])}

def intervene(t):
    c=fit5(t.family,t.demos);no=score(t,c[0]);arms=[]
    for i,q in enumerate(t.pool):
        after=fit5(t.family,(*t.demos,{'input':q,'output':oracle(t.family,t.word,q)}))
        arms.append({'index':i,'score':score(t,after[0]),'labels':1})
    return c,no,arms

def source(t):
    c,no,arms=intervene(t)
    ps={p:arms[choose(p,t.family,c,t.pool,seed=SEED+t.slot)[0]]['score']['total']
        for p in POLICIES}
    return {'family':t.family,'role':t.role,'task_id':t.task_id,'bucket':context(t.family,c,t.pool),
            'candidate_count':len(c),'no_label':no['total'],'policy_scores':ps,'label_events':18}

def target(t,mapping):
    c,no,arms=intervene(t)
    a=decide(t.family,c,t.pool,mapping,SEED+t.slot)
    # Deliberate sham: unrelated all-abstain policy, no target read.
    sham=decide(t.family,c,t.pool,{'fallback':ABSTAIN},SEED+t.slot)
    gi=choose('max_partition',t.family,c,t.pool,seed=SEED+t.slot)[0]
    mi=minimax_index(t.family,c,t.pool)
    after=fit5(t.family,(*t.demos,*({'input':q,'output':oracle(t.family,t.word,q)} for q in t.pool)))
    value=lambda x:no if x['index'] is None else arms[x['index']]['score']
    scores={'inherited':value(a),'sham':value(sham),'task_local':arms[gi]['score'],
            'minimax':arms[mi]['score'],'no_label':no,'full_eight_labels':score(t,after[0])}
    return {'family':t.family,'regime':t.regime,'slot':t.slot,'task_id':t.task_id,
            'bucket':a['bucket'],'candidate_count':len(c),'inherited':a,'sham':sham,
            'local_index':gi,'minimax_index':mi,'scores':scores,'arms':arms,
            'uniform_expected':sum(x['score']['total'] for x in arms)/8,
            'hindsight_ceiling':max(x['score']['total'] for x in arms)}

def run(commit):
    if not re.fullmatch('[0-9a-f]{40}',commit):raise ValueError('source freeze SHA required')
    tr,va,te=bank()
    tr_rows=[source(x) for x in tr];va_rows=[source(x) for x in va]
    proposed={};models={};calibration={}
    for fam in FAMILIES:
        proposed[fam]=train(tr_rows,fam)
        models[fam],calibration[fam]=validate(proposed[fam],va_rows,fam)
    targets=[target(x,models[x.family]) for x in te]
    groups=[]
    for fam in FAMILIES:
        for regime in REGIMES:
            sub=[x for x in targets if x['family']==fam and x['regime']==regime]
            if len(sub)!=3:raise ValueError('missing stratum')
            groups.append({'family':fam,'regime':regime,'episodes':3,'total_probes':24,
                'scores':{k:sum(x['scores'][k]['total'] for x in sub) for k in sub[0]['scores']},
                'random_expectation':sum(x['uniform_expected'] for x in sub),
                'inherited_deployed_query_labels':sum(x['inherited']['labels'] for x in sub)})
    nq=sum(x['inherited']['labels'] for x in targets)
    costs={'source_train_tasks':12,'meta_tasks':6,'target_tasks':12,
           'source_demo_labels':24,'source_query_intervention_labels':96,'source_scoring_probe_labels':96,
           'meta_demo_labels':12,'meta_query_intervention_labels':48,'meta_scoring_probe_labels':48,
           'total_source_meta_acquisition_label_events':324,
           'target_demo_labels':24,'target_counterfactual_query_labels':96,'target_scoring_probe_labels':96,
           'research_oracle_label_events':540,
           'inherited_target_deployed_query_labels':nq,'source_acquisition_per_target':27.0,
           'target_local_one_query_labels':12,'cpu_parity_established':False}
    go=all(g['scores']['inherited']>max(g['scores']['task_local'],g['scores']['minimax'],
           g['scores']['sham'],g['scores']['no_label'],g['random_expectation']) for g in groups)
    return {'mode':'E1.4e_public_development','source_commit':commit,
       'bank_sha256':digest((tr,va,te)),'source_tasks':len(tr),'meta_tasks':len(va),
       'target_tasks':len(te),'source_mapping':proposed,'validated_mapping':models,
       'meta_validation':calibration,'source_rows':tr_rows,'meta_rows':va_rows,
       'target_rows':targets,'summary':groups,'costs':costs,
       'decision':'GO_PREDICTIVE_ONLY_COST_UNPROVEN' if go else 'HOLD_META_VALIDATED_QUERY_TRANSFER',
       'limitations':['Development-only: fixed human-specified grammar and heuristics.',
        'Researcher selected E1.4e after E1.4d outcome; not independent confirmation.',
        'No amortized cost parity (324 source/meta labels before 12 targets).',
        'Candidates and evaluator in one Python process; independent isolation unverified.',
        'Synthetic held-out probes include engineered diagnostic positives.']}

def main():
    p=argparse.ArgumentParser();p.add_argument('--source-commit',required=True)
    p.add_argument('--verify',type=Path)
    a=p.parse_args();r=run(a.source_commit)
    if a.verify and canonical_json(r)!=canonical_json(json.loads(a.verify.read_text())):
        raise ValueError('E1.4e deterministic replay mismatch')
    print(canonical_json(r).decode('utf-8'))
if __name__=='__main__':main()
