"""Source/meta-only policy; intentionally contains no evaluator or oracle imports."""
from .e14d_policy import fit5,context,ABSTAIN,minimax_index
from .cross_episode_candidate import choose,POLICIES
SEED=141904

def train(rows,fam):
    x=[r for r in rows if r['family']==fam]
    if len(x)!=6:raise ValueError('missing source training')
    model={'fallback':ABSTAIN}
    for b in ('low_ambiguity','high_ambiguity'):
        group=[r for r in x if r['bucket']==b]
        if not group:continue
        no=sum(r['no_label'] for r in group)
        gain={p:sum(r['policy_scores'][p] for r in group)-no for p in POLICIES}
        best=max(POLICIES,key=lambda p:(gain[p],-POLICIES.index(p)))
        model[b]=best if gain[best]>0 else ABSTAIN
    return model

def validate(model,rows,fam):
    x=[r for r in rows if r['family']==fam]
    if len(x)!=3:raise ValueError('missing held-out meta-validation')
    result=dict(model);audit={}
    for b in ('low_ambiguity','high_ambiguity'):
        group=[r for r in x if r['bucket']==b]
        p=model.get(b,ABSTAIN)
        gain=sum(r['policy_scores'][p]-r['no_label'] for r in group) if p!=ABSTAIN else 0
        good=p!=ABSTAIN and bool(group) and gain>0
        result[b]=p if good else ABSTAIN
        audit[b]={'count':len(group),'proposed':p,'improvement':gain,'accepted':good}
    return result,audit

def decide(fam,candidates,pool,mapping,seed):
    b=context(fam,candidates,pool)
    p=mapping.get(b,mapping.get('fallback',ABSTAIN))
    if b in ('resolved','no_disagreement') or p==ABSTAIN:
        return {'policy':ABSTAIN,'bucket':b,'index':None,'labels':0}
    ix,_=choose(p,fam,candidates,pool,seed=seed)
    return {'policy':p,'bucket':b,'index':ix,'labels':1}
