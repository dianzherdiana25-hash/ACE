"""Prescoring tests. Never score the E1.4e target held-out probes here."""
import unittest
from collections import Counter
from unittest.mock import patch
from e13.contract import canonical_json
from e13.evaluator.selection import input_key
from .e14e_bank import bank,motifs,prior_inputs,preallocate,digest,cached_prior_bank
from .e14d_bank import bank as prior_bank
from .e14e_policy import train,validate,decide,fit5,ABSTAIN,SEED
from .cross_episode_candidate import POLICIES,predict

class E14eStructure(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.groups=bank()
    def test_roles_and_new_words(self):
        a,b,c=self.groups
        self.assertEqual((len(a),len(b),len(c)),(12,6,12))
        for fam in ('S','G'):
            old={x.word for pair in cached_prior_bank() for x in pair if x.family==fam}
            words=[t.word for group in self.groups for t in group if t.family==fam]
            self.assertEqual(len(words),15)
            self.assertEqual(len(set(words)),15)
            self.assertFalse(set(words)&old)
    def test_preallocate_without_oracle(self):
        with patch('e14.e14e_bank.oracle',side_effect=AssertionError('oracle read from pool')):
            a=preallocate(prior_inputs());b=preallocate(prior_inputs())
        self.assertEqual(len(a),30)
        self.assertEqual(canonical_json(list(a.values())),canonical_json(list(b.values())))
    def test_unique_fresh_inputs(self):
        used=prior_inputs()
        for group in self.groups:
            for task in group:
                for raw in [*(d['input'] for d in task.demos),*task.pool,
                            *(p['input'] for p in task.probes)]:
                    k=input_key(task.family,raw)
                    self.assertNotIn(k,used[task.family]);used[task.family].add(k)
        self.assertEqual(digest(self.groups),digest(bank()))
    def test_paired_relatedness(self):
        train,meta,target=self.groups
        for fam in ('S','G'):
            for i in range(6):
                a=next(t for t in train if t.family==fam and t.slot==i)
                b=next(t for t in target if t.family==fam and t.slot==i)
                self.assertNotEqual(a.word,b.word)
                self.assertEqual(a.regime,b.regime)
                d=sum(x!=y for x,y in zip(a.word,b.word))
                self.assertEqual(d==1,a.regime=='related')
    def test_source_semantic_consistency(self):
        from .query_bank import oracle
        for group in self.groups[:2]:
            for task in group:
                for example in (*task.demos,*task.probes):
                    self.assertEqual(predict(task.family,task.word,example['input']),example['output'])
                    self.assertEqual(oracle(task.family,task.word,example['input']),example['output'])
    def test_meta_failure_abstains(self):
        rows=[]
        for fam in ('S','G'):
            for _ in range(6):
                rows.append({'family':fam,'bucket':'low_ambiguity','no_label':2,
                    'policy_scores':{p:8 if p=='first_disagreement' else 2 for p in POLICIES}})
        trained=train(rows,'S')
        self.assertEqual(trained['low_ambiguity'],'first_disagreement')
        meta=[{'family':'S','bucket':'low_ambiguity','no_label':8,
               'policy_scores':{p:0 for p in POLICIES}}for _ in range(3)]
        valid,audit=validate(trained,meta,'S')
        self.assertEqual(valid['low_ambiguity'],ABSTAIN)
        self.assertFalse(audit['low_ambiguity']['accepted'])
    def test_candidate_does_not_call_oracle(self):
        task=self.groups[0][0]
        with patch('e14.e14e_bank.oracle',side_effect=AssertionError('oracle in candidate')):
            c=fit5(task.family,task.demos)
            z=decide(task.family,c,task.pool,{'fallback':'max_partition'},SEED)
        self.assertIn(z['labels'],(0,1))
    def test_explicit_out_of_basis_limit(self):
        from .e14d_policy import grammar5
        for fam in ('S','G'):
            self.assertTrue(all(len(x)==5 for x in grammar5(fam)))
            self.assertNotIn((0,0,0,0,0,0),grammar5(fam))
if __name__=='__main__':unittest.main()
