"""Public-development bank: 12 train, 6 meta-validation, 12 target episodes."""
import random, hashlib
from functools import lru_cache
from e13.contract import canonical_json
from e13.evaluator.selection import input_key
from .e14d_bank import bank as prior_bank, Episode, _raw, _random_events, positive_events, negative_events
from .cross_episode_bank_v2 import _prior_inputs
from .e14d_policy import grammar5
from .query_bank import oracle

PAIR=141901; POOL=141902; DEMO=141903
FAMILIES=('S','G'); REGIMES=('related','unrelated')
ROLES=('source','meta','target')

@lru_cache(maxsize=1)
def cached_prior_bank():
    return prior_bank()

def motifs(fam):
    prior={x.word for p in cached_prior_bank() for x in p if x.family==fam}
    choices=[w for w in grammar5(fam) if w not in prior]
    random.Random(PAIR+(fam=='G')).shuffle(choices)
    used=set(); pairs=[]
    for regime in REGIMES:
        for _ in range(3):
            ab=next(((a,b) for a in choices if a not in used for b in choices
                     if b not in used and a!=b and (sum(x!=y for x,y in zip(a,b))==1 if regime=='related'
                                                  else sum(x!=y for x,y in zip(a,b))>=3)),None)
            if ab is None:raise ValueError('not enough unused grammar motifs')
            pairs.append((regime,*ab));used.update(ab)
    return tuple(pairs),tuple(x for x in choices if x not in used)[:3]

@lru_cache(maxsize=1)
def frozen_prior_inputs():
    seen=_prior_inputs()
    for pair in cached_prior_bank():
        for t in pair:
            seen[t.family].update(input_key(t.family,x) for x in
                [*(d['input'] for d in t.demos),*t.pool,*(d['input'] for d in t.probes)])
    return seen

def prior_inputs():
    return {f:set(v) for f,v in frozen_prior_inputs().items()}

def preallocate(seen):
    out={}
    for fam in FAMILIES:
        for role,n in (('source',6),('meta',3),('target',6)):
            for slot in range(n):
                rng=random.Random(POOL+1000*(fam=='G')+100*ROLES.index(role)+slot)
                out[fam,role,slot]=tuple(_raw(fam,_random_events(fam,rng,rng.randint(9,14)),rng,seen[fam])
                                         for _ in range(8))
    return out

def episode(fam,role,regime,slot,word,pool,seen):
    rng=random.Random(DEMO+1000*(fam=='G')+100*ROLES.index(role)+slot)
    demos=[]
    for kind in (('negative','positive') if slot%2 else ('negative','negative')):
        ev=positive_events(fam,word,rng) if kind=='positive' else negative_events(fam,word,rng)
        x=_raw(fam,ev,rng,seen[fam]);demos.append({'input':x,'output':oracle(fam,word,x)})
    probes=[];types=[]
    for i in range(8):
        if i<4:ev=_random_events(fam,rng,rng.randint(9,14));kind='natural'
        else:
            ev=positive_events(fam,word,rng) if i in (4,6) else negative_events(fam,word,rng)
            kind='diagnostic'
        x=_raw(fam,ev,rng,seen[fam]);probes.append({'input':x,'output':oracle(fam,word,x)});types.append(kind)
    tid=hashlib.sha256(canonical_json((fam,role,slot,regime,word))).hexdigest()[:32]
    return Episode(fam,regime,role,slot,word,tid,tuple(demos),pool,tuple(probes),tuple(types))

@lru_cache(maxsize=1)
def bank():
    seen=prior_inputs();pools=preallocate(seen)
    train=[];meta=[];target=[]
    for fam in FAMILIES:
        pairs,valid=motifs(fam)
        for slot,(regime,a,b) in enumerate(pairs):
            train.append(episode(fam,'source',regime,slot,a,pools[fam,'source',slot],seen))
            target.append(episode(fam,'target',regime,slot,b,pools[fam,'target',slot],seen))
        for slot,w in enumerate(valid):
            meta.append(episode(fam,'meta','validation',slot,w,pools[fam,'meta',slot],seen))
    return tuple(train),tuple(meta),tuple(target)

def digest(groups):
    return hashlib.sha256(canonical_json([[
        {'family':t.family,'role':t.role,'regime':t.regime,'slot':t.slot,'word':t.word,
        'task_id':t.task_id,'demos':t.demos,'pool':t.pool,'probes':t.probes} for t in group]
        for group in groups])).hexdigest()
