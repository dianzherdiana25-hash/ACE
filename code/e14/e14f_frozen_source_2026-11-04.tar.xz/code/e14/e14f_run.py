"""E1.4f public-development diagnostic: is a one-query learning opportunity present?"""
from __future__ import annotations
import argparse,json,re
from pathlib import Path
from e13.contract import canonical_json
from .e14f_bank import bank,bank_digest,FAMILIES,CLASSES
from .e14f_selector import local_selectors
from .e14d_policy import fit5
from .cross_episode_candidate import predict
from .query_bank import oracle

SEED=142004
POOLS=("random","curated")
PREVALENCES=("natural_heavy","diagnostic_heavy")


def correctness(task,word,probe_list):
    return sum(predict(task.family,word, p["input"])==p["output"] for p in probe_list)


def task_result(task):
    candidates=fit5(task.family,task.demos)
    no={p:correctness(task,candidates[0],task.probes[p]) for p in PREVALENCES}
    pools={"random":task.random_pool,"curated":task.curated_pool}
    evaluated={}
    for condition,pool in pools.items():
        selectors=local_selectors(task.family,candidates,pool,SEED+task.slot)
        arms=[]
        for i,value in enumerate(pool):
            label=oracle(task.family,task.true_word,value)
            after=fit5(task.family,(*task.demos,{"input":value,"output":label}))
            arms.append({"index":i,"scores":{p:correctness(task,after[0],task.probes[p]) for p in PREVALENCES},
                         "candidate_count":len(after),"oracle_labels":1})
        evaluated[condition]={"selectors":selectors,"arms":arms,"labels_for_exhaustive_counterfactual":8,
           "selected_reservoir_indices":list(task.curated_indices) if condition=="curated" else None,
           "candidate_prediction_evaluations_for_pool_construction":len(task.reservoir)*len(candidates) if condition=="curated" else 0}
    return {"family":task.family,"rule_class":task.rule_class,"slot":task.slot,
       "demo_regime":task.demo_regime,"task_id":task.task_id,
       "word":list(task.true_word),"candidate_count":len(candidates),
       "representable":task.true_word in candidates if task.rule_class=="in_basis" else False,
       "true_rule_in_fixed_grammar":task.rule_class=="in_basis",
       "no_label":no,"pools":evaluated}


def summarize(rows):
    summary=[]
    for family in FAMILIES:
      for cls in CLASSES:
       sub=[x for x in rows if x["family"]==family and x["rule_class"]==cls]
       if len(sub)!=6:raise ValueError("expected six tasks per family/class")
       for prevalence in PREVALENCES:
        for pool_name in POOLS:
         no=sum(r["no_label"][prevalence] for r in sub)
         gains=[];gini_gains=[];minimax_gains=[];random_scores=[]
         no_disagreement=0;with_capacity=0
         for r in sub:
          record=r["pools"][pool_name]
          vals=[arm["scores"][prevalence] for arm in record["arms"]]
          n=r["no_label"][prevalence];gains.append(max(vals)-n)
          gini_gains.append(vals[record["selectors"]["max_gini"]]-n)
          minimax_gains.append(vals[record["selectors"]["minimax"]]-n)
          random_scores.append(sum(vals)/8)
          no_disagreement+=record["selectors"]["disagreement_questions"]==0
          with_capacity+=r["true_rule_in_fixed_grammar"]
         summary.append({"family":family,"rule_class":cls,"probe_prevalence":prevalence,"pool":pool_name,
           "episodes":6,"total_probes":48,"no_label_correct":no,
           "hindsight_max_correct":no+sum(gains),"hindsight_positive_tasks":sum(x>0 for x in gains),
           "hindsight_gain":sum(gains),"max_gini_correct":no+sum(gini_gains),
           "max_gini_positive_tasks":sum(x>0 for x in gini_gains),"max_gini_gain":sum(gini_gains),
           "minimax_correct":no+sum(minimax_gains),"random_one_label_expected_correct":sum(random_scores),
           "no_disagreement_tasks":no_disagreement,"in_basis_tasks":with_capacity})
    return summary


def decide(summary):
    rows=[s for s in summary if s["rule_class"]=="in_basis" and
          s["probe_prevalence"]=="diagnostic_heavy" and s["pool"]=="curated"]
    if len(rows)!=2:return "HOLD_RESOURCE_INTEGRITY"
    if all(r["hindsight_positive_tasks"]>=3 and r["max_gini_positive_tasks"]>=2
            and r["max_gini_gain"]>0 for r in rows):
        return "OPPORTUNITY_BENCHMARK_FEASIBLE_DEVELOPMENT_ONLY"
    return "BENCHMARK_HOLD_REDESIGN"


def run(freeze_commit):
    if not isinstance(freeze_commit,str) or not re.fullmatch(r"[0-9a-f]{40}",freeze_commit):
        raise ValueError("exact frozen commit required")
    tasks=bank()
    rows=[task_result(t) for t in tasks]
    tables=summarize(rows)
    result={"mode":"E1.4f_opportunity_development","freeze_commit":freeze_commit,
      "bank_sha256":bank_digest(tasks),"tasks":len(rows),"pool_conditions":list(POOLS),
      "probe_conditions":list(PREVALENCES),"rows":rows,"summary":tables,
      "budget":{"source_demo_label_events":48,"target_oracle_query_labels_per_pool":8,
        "total_query_oracle_calls":24*2*8,"total_probe_label_events":24*16,
        "total_public_development_oracle_calls_excluding_historical_generation":24*(2+16+16),
        "deployment_one_label_per_selected_pool":1,
        "pool_curation_candidate_prediction_work_exceeds_random":True,"compute_parity_established":False},
      "decision":decide(tables),"limitations":[
        "Opportunity hindsight uses held-out scores to select the best of eight; not deployable.",
        "Curated query pools inspect only demonstrations and candidate predictions from 48 preallocated unlabeled examples.",
        "Out-of-basis true six-event word is not representable by fixed five-event candidate model.",
        "Diagnostic probe distribution is constructed, not natural real-world prevalence.",
        "Same-process evaluator/solver without verified worker isolation, public development only.",
        "No independent confirmatory inference or open-ended autonomous intelligence claim."]}
    return result


def main():
    parser=argparse.ArgumentParser();parser.add_argument("--freeze-commit",required=True)
    parser.add_argument("--verify",type=Path)
    args=parser.parse_args();result=run(args.freeze_commit)
    if args.verify and canonical_json(result)!=canonical_json(json.loads(args.verify.read_text())):
        raise ValueError("E1.4f deterministic replay differs from stored evidence")
    print(canonical_json(result).decode("utf-8"))

if __name__=="__main__":main()
