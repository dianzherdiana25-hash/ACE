"""Independent saved-JSON arithmetic integrity audit for E1.4f.

No import from candidate/solver/evaluator. Cannot prove oracle semantics or custody.
"""
import json
import argparse
from pathlib import Path

FAMILIES=('S','G');CLASSES=('in_basis','out_of_basis')
PREVALENCES=('natural_heavy','diagnostic_heavy');POOLS=('random','curated')


def ensure(condition,reason):
    if not condition:raise ValueError(reason)


def audit(r):
    ensure(r.get('mode')=='E1.4f_opportunity_development','mode')
    rows=r.get('rows')
    ensure(isinstance(rows,list) and len(rows)==24 and r.get('tasks')==24,'task count')
    ensure(len({row['task_id'] for row in rows})==24,'duplicate task')
    ensure(r['budget']['total_public_development_oracle_calls_excluding_historical_generation']==816,'call budget')
    ensure(r['budget']['total_query_oracle_calls']==384,'query calls')
    summary=[]
    for fam in FAMILIES:
      for cls in CLASSES:
       sub=[x for x in rows if x['family']==fam and x['rule_class']==cls]
       ensure(len(sub)==6 and sorted(x['slot'] for x in sub)==list(range(6)),'stratum size / slots')
       for rrow in sub:
        ensure(set(rrow['pools'])==set(POOLS),'pool identity')
        for pool in POOLS:
         data=rrow['pools'][pool]
         ensure(len(data['arms'])==8,'arm count')
         ensure([a['index'] for a in data['arms']]==list(range(8)),'arm order')
         ensure(all(a['oracle_labels']==1 for a in data['arms']),'arm costs')
         ensure(set(data['selectors'])=={'max_gini','minimax','disagreement_questions'},'selector shape')
         ensure(all(type(data['selectors'][k]) is int and 0<=data['selectors'][k]<8 for k in ('max_gini','minimax')),'selector index')
         ensure(type(data['selectors']['disagreement_questions']) is int and 0<=data['selectors']['disagreement_questions']<=8,'disagreement bounds')
         if pool=='curated':
          ensure(data['candidate_prediction_evaluations_for_pool_construction']==48*rrow['candidate_count'],'curation cost')
          ensure(len(data['selected_reservoir_indices'])==8,'curated positions')
         else:
          ensure(data['candidate_prediction_evaluations_for_pool_construction']==0,'random pool work')
        for prevalence in PREVALENCES:
         ensure(type(rrow['no_label'][prevalence]) is int and 0<=rrow['no_label'][prevalence]<=8,'no-label bounds')
         for pool in POOLS:
          for a in rrow['pools'][pool]['arms']:
           ensure(type(a['scores'][prevalence]) is int and 0<=a['scores'][prevalence]<=8,'arm score bounds')
       for prevalence in PREVALENCES:
        for pool in POOLS:
         baselines=sum(x['no_label'][prevalence] for x in sub)
         hgain=[];ggain=[];mgain=[];random=[];nd=0
         for x in sub:
          row=x['pools'][pool];vals=[v['scores'][prevalence] for v in row['arms']]
          base=x['no_label'][prevalence];hgain.append(max(vals)-base)
          ggain.append(vals[row['selectors']['max_gini']]-base)
          mgain.append(vals[row['selectors']['minimax']]-base)
          random.append(sum(vals)/8)
          nd+=row['selectors']['disagreement_questions']==0
         summary.append({'family':fam,'rule_class':cls,'probe_prevalence':prevalence,'pool':pool,
            'episodes':6,'total_probes':48,'no_label_correct':baselines,
            'hindsight_max_correct':baselines+sum(hgain),'hindsight_positive_tasks':sum(v>0 for v in hgain),
            'hindsight_gain':sum(hgain),'max_gini_correct':baselines+sum(ggain),
            'max_gini_positive_tasks':sum(v>0 for v in ggain),'max_gini_gain':sum(ggain),
            'minimax_correct':baselines+sum(mgain),'random_one_label_expected_correct':sum(random),
            'no_disagreement_tasks':nd,'in_basis_tasks':6 if cls=='in_basis' else 0})
    ensure(summary==r['summary'],'summary mismatch')
    core=[s for s in summary if s['rule_class']=='in_basis' and s['pool']=='curated' and s['probe_prevalence']=='diagnostic_heavy']
    feasible=all(s['hindsight_positive_tasks']>=3 and s['max_gini_positive_tasks']>=2 and s['max_gini_gain']>0 for s in core)
    expected='OPPORTUNITY_BENCHMARK_FEASIBLE_DEVELOPMENT_ONLY' if feasible else 'BENCHMARK_HOLD_REDESIGN'
    ensure(r.get('decision')==expected,'decision mismatch')
    return {'audit':'E14F_ARITHMETIC_PASS','tasks':len(rows),'strata':len(summary),
            'oracle_calls_recorded':816,'decision':expected,
            'target_opportunity':core,
            'scope':'Only internal JSON arithmetic; no oracle semantic or process security proof'}


def main():
    a=argparse.ArgumentParser();a.add_argument('json_file',type=Path);args=a.parse_args()
    print(json.dumps(audit(json.loads(args.json_file.read_text())),indent=2,sort_keys=True))

if __name__=='__main__':main()
