"""Unlabeled candidate-only pool curation for ACE E1.4f.

Never import evaluator, oracle, true hidden rule, or target probe outputs.
"""
from collections import Counter
from .cross_episode_candidate import predict, choose
from .e14d_policy import fit5, minimax_index


def partition_metrics(family, candidates, value):
    outputs = Counter(predict(family, word, value) for word in candidates)
    n = len(candidates)
    return (n*n-sum(v*v for v in outputs.values()), max(outputs.values()), len(outputs))


def curate_pool(family, candidates, reservoir, k=8):
    """Take highest predicted Gini diversity (no oracle) from fixed raw reservoir."""
    if len(reservoir) < k or not candidates:
        raise ValueError("insufficient unlabeled reservoir / hypotheses")
    metrics = [partition_metrics(family, candidates, value) for value in reservoir]
    selected = sorted(range(len(reservoir)), key=lambda i: (-metrics[i][0], i))[:k]
    return tuple(reservoir[i] for i in selected), tuple(selected)


def local_selectors(family, candidates, pool, seed):
    maxi = choose("max_partition", family, candidates, pool, seed=seed)[0]
    mini = minimax_index(family, candidates, pool)
    mixed = sum(partition_metrics(family, candidates, x)[2]>1 for x in pool)
    return {"max_gini":maxi, "minimax":mini, "disagreement_questions":mixed}
