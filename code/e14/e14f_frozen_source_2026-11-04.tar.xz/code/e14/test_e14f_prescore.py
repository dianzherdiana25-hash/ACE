"""Structural pre-scoring tests for E1.4f; do NOT compute target prediction scores."""
import unittest
from unittest.mock import patch
from e13.contract import canonical_json
from e13.evaluator.selection import input_key
from .e14f_bank import bank,bank_digest,preallocate,reserved_historical,select_words,grammar5,grammar6
from .e14d_policy import fit5
from .e14f_selector import curate_pool,local_selectors

class E14fPrescore(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.tasks=bank()

    def test_task_sizes_and_distinct_ids(self):
        self.assertEqual(len(self.tasks),24)
        self.assertEqual(len({t.task_id for t in self.tasks}),24)
        for t in self.tasks:
            self.assertEqual(len(t.demos),2)
            self.assertEqual(len(t.random_pool),8)
            self.assertEqual(len(t.curated_pool),8)
            self.assertEqual(len(t.reservoir),48)
            self.assertEqual(tuple(t.reservoir[i] for i in t.curated_indices),t.curated_pool)
            self.assertEqual({len(x) for x in t.probes.values()},{8})

    def test_words_disjoint_and_fixed_basis(self):
        words=select_words();self.assertEqual(len(words),4)
        for (fam,cls),values in words.items():
            self.assertEqual(len(values),6);self.assertEqual(len(set(values)),6)
            if cls=='in_basis':self.assertTrue(all(v in grammar5(fam) for v in values))
            else:self.assertTrue(all(v in grammar6(fam) and v not in grammar5(fam) for v in values))

    def test_preallocation_does_not_read_oracle(self):
        prior,_=reserved_historical()
        with patch('e14.e14f_bank.oracle',side_effect=AssertionError('oracle called')):
            out=preallocate({f:set(s) for f,s in prior.items()})
        self.assertEqual(len(out),24)

    def test_no_overlap_with_any_prior_or_new_case(self):
        prior,_=reserved_historical();seen={f:set(s) for f,s in prior.items()}
        for t in self.tasks:
            items=[*(d['input'] for d in t.demos),*t.random_pool,*t.reservoir,
                   *(e['input'] for seq in t.probes.values() for e in seq)]
            for x in items:
                k=input_key(t.family,x)
                self.assertNotIn(k,seen[t.family]);seen[t.family].add(k)

    def test_candidate_selector_avoids_evaluator(self):
        t=self.tasks[0]
        with patch('e14.e14f_bank.oracle',side_effect=AssertionError('oracle called')):
            c=fit5(t.family,t.demos)
            p,idx=curate_pool(t.family,c,t.reservoir)
            selectors=local_selectors(t.family,c,p,142004)
            self.assertEqual((p,idx),(t.curated_pool,t.curated_indices))
            self.assertIn(selectors['max_gini'],range(8))

    def test_reproducible_bank_hash(self):
        self.assertEqual(bank_digest(self.tasks),bank_digest(bank()))
        self.assertEqual(canonical_json([t.task_id for t in self.tasks]),
                         canonical_json([t.task_id for t in bank()]))

    def test_probes_disjoint_from_pools(self):
        for t in self.tasks:
            qs={input_key(t.family,x) for x in (*t.random_pool,*t.reservoir)}
            self.assertTrue(all(input_key(t.family,p['input']) not in qs
                                for seq in t.probes.values() for p in seq))

    def test_no_candidate_oracle_access_through_imports(self):
        import e14.e14f_selector as s
        self.assertNotIn('oracle',s.__dict__)
        self.assertNotIn('true_word',s.__dict__)

if __name__=='__main__':unittest.main()
