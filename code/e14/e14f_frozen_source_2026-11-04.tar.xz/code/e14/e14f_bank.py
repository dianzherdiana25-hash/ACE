"""New E1.4f identifiability bank, fixed independently of task scores.

Two true-rule classes (represented five-event / unrepresented six-event),
two unlabeled query pools (8 natural vs 8 candidate-curated out of a separate
48-input reservoir), and two evaluation probe prevalence regimes per task.
"""
from __future__ import annotations
import hashlib
import random
from dataclasses import dataclass
from functools import lru_cache
from itertools import product
from e13.contract import canonical_json
from e13.evaluator.selection import input_key
from .e14e_bank import bank as historical_bank, prior_inputs as historical_prior
from .e14d_bank import _raw, _random_events, positive_events, negative_events
from .e14d_policy import fit5, grammar5
from .e14f_selector import curate_pool
from .query_bank import oracle

MOTIF_SEED=142001
QUERY_SEED=142002
DATA_SEED=142003
FAMILIES=("S","G")
CLASSES=("in_basis","out_of_basis")
SLOTS=6
POOL_N=8
RESERVOIR_N=48

@dataclass(frozen=True)
class Task:
    family: str
    rule_class: str
    slot: int
    demo_regime: str
    true_word: tuple[int,...]        # evaluator custody: never passed to candidate
    task_id: str
    demos: tuple[dict,...]
    random_pool: tuple
    curated_pool: tuple
    curated_indices: tuple[int,...]
    reservoir: tuple
    probes: dict[str,tuple[dict,...]]


def grammar6(family):
    if family=="S":
        return tuple(product(range(3),repeat=6))
    if family=="G":
        return tuple((0,*tail) for tail in product((1,2),repeat=5))+tuple(product((1,2),repeat=6))
    raise ValueError("bad family")

@lru_cache(maxsize=1)
def reserved_historical():
    seen=historical_prior()
    history=historical_bank()
    used_words={"S":set(),"G":set()}
    for group in history:
        for t in group:
            used_words[t.family].add(t.word)
            for x in [*(d["input"] for d in t.demos),*t.pool,*(p["input"] for p in t.probes)]:
                seen[t.family].add(input_key(t.family,x))
    return {f:frozenset(x) for f,x in seen.items()}, {f:frozenset(x) for f,x in used_words.items()}


def select_words():
    _,prev=reserved_historical()
    words={}
    for family in FAMILIES:
        for rule_class in CLASSES:
            inv=grammar5(family) if rule_class=="in_basis" else grammar6(family)
            candidates=[w for w in inv if w not in prev[family]]
            rng=random.Random(MOTIF_SEED+100*(family=="G")+int(rule_class=="out_of_basis"))
            rng.shuffle(candidates)
            if len(candidates)<SLOTS:raise ValueError("exhausted new rule motifs")
            words[(family,rule_class)]=tuple(candidates[:SLOTS])
    return words


def preallocate(used):
    """All query inputs allocated from role coordinates, before rules or labels."""
    result={}
    for family in FAMILIES:
        for rule_class in CLASSES:
            for slot in range(SLOTS):
                rng=random.Random(QUERY_SEED+1000*(family=="G")+100*(rule_class=="out_of_basis")+slot)
                random_pool=tuple(_raw(family,_random_events(family,rng,rng.randint(9,14)),rng,used[family]) for _ in range(POOL_N))
                reservoir=tuple(_raw(family,_random_events(family,rng,rng.randint(9,14)),rng,used[family]) for _ in range(RESERVOIR_N))
                result[(family,rule_class,slot)]=(random_pool,reservoir)
    return result


def _one_task(family,rule_class,slot,word,random_pool,reservoir,used):
    rng=random.Random(DATA_SEED+1000*(family=="G")+100*(rule_class=="out_of_basis")+slot)
    regime="mixed" if slot%2 else "weak_negative"
    demos=[]
    for kind in (("negative","positive") if regime=="mixed" else ("negative","negative")):
        events=positive_events(family,word,rng) if kind=="positive" else negative_events(family,word,rng)
        x=_raw(family,events,rng,used[family]);demos.append({"input":x,"output":oracle(family,word,x)})
    candidates=fit5(family,demos)
    curated,indices=curate_pool(family,candidates,reservoir)
    probes={}
    # FIXED. Natural-heavy: six random + one positive and one negative.
    # Diagnostic-heavy: two random + four positive and two negative.
    for prevalence,pattern in (
        ("natural_heavy", ("natural",)*6+("positive","negative")),
        ("diagnostic_heavy",("natural",)*2+("positive",)*4+("negative",)*2)
    ):
        examples=[]
        for label in pattern:
            if label=="natural":events=_random_events(family,rng,rng.randint(9,14))
            else:events=positive_events(family,word,rng) if label=="positive" else negative_events(family,word,rng)
            x=_raw(family,events,rng,used[family]);examples.append({"input":x,"output":oracle(family,word,x),"probe_type":label})
        probes[prevalence]=tuple(examples)
    taskid=hashlib.sha256(canonical_json([family,rule_class,slot,word])).hexdigest()[:32]
    return Task(family,rule_class,slot,regime,word,taskid,tuple(demos),random_pool,curated,indices,reservoir,probes)

@lru_cache(maxsize=1)
def bank():
    prior,_=reserved_historical();used={f:set(s) for f,s in prior.items()}
    reserved_queries=preallocate(used)
    words=select_words()
    tasks=[]
    for family in FAMILIES:
        for rule_class in CLASSES:
            for slot,word in enumerate(words[family,rule_class]):
                pool,reservoir=reserved_queries[family,rule_class,slot]
                tasks.append(_one_task(family,rule_class,slot,word,pool,reservoir,used))
    return tuple(tasks)


def bank_digest(tasks):
    return hashlib.sha256(canonical_json([{
        "family":t.family,"class":t.rule_class,"slot":t.slot,"word":t.true_word,
        "task":t.task_id,"regime":t.demo_regime,"demos":t.demos,
        "random_pool":t.random_pool,"reservoir":t.reservoir,"curated_indices":t.curated_indices,
        "probes":t.probes} for t in tasks])).hexdigest()
