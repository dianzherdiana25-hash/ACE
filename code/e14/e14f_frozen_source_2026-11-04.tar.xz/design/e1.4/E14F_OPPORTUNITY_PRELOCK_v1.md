# ACE E1.4f — Query value-of-information / benchmark identifiability PRELOCK v1

**PRE-SCORE public-development registration, 4 November 2026.** Register code, seeds, SHA-256, structural tests and this protocol in a verified GitHub branch commit **before scoring**. No post-score edits to candidate inventory, probes, thresholds, seeds, or bank. A quality bug requires a new version; preserve the original score.

## Why this gate exists

Post-hoc E1.4e analysis found positive one-label opportunity in only 1/12 targets and its strict four-stratum GO impossible on 3/4 strata even for hindsight best query. E1.4f therefore tests **whether the benchmark itself is informative** before continuing autonomous policy-transfer experiments. The objective is *not* to improve a previously evaluated policy, and E1.4c/d/e scored targets are not used to tune a candidate or threshold. This pilot does **not** establish open-ended autonomous intelligence, novel method invention, or AGI.

## Frozen generation and fair comparisons

- Fixed human-engineered **five-event hypothesis inventory**: S 243, G 48. True rules have either **five events (in basis)** or **six (out of basis)**, with six novel tasks per family/basis cell: **24 independent tasks**. All five-event rules differ from E1.4d/E1.4e; six-event words are unrepresented by the five-event inventory.
- Fixed seeds: rule motifs **142001**, unlabeled pools **142002**, demonstrations/probes **142003**, selector ties **142004**. New inputs are globally deduplicated within family and exclude all public E1.4c/d/e and earlier fixtures. Before *any* word-conditioned examples are built, preallocate per-task **eight natural/random queries plus 48 independent unlabeled candidate queries**; none accesses oracle, hidden rule, or target probe results.
- Each task receives two demos with slot-fixed regime (even slot = two negative examples, odd slot = negative + positive). A candidate-only curator ranks the 48 available unlabeled queries by output-partition Gini from the fitted, visible-demo hypothesis set, and selects the top eight; it is never given true word, oracle labels, or probe scores. It performs more unlabeled computation than the eight-query natural pool: **CPU parity is not established**. Both query treatments have exactly eight candidate questions and all eight counterfactual one-label arms evaluated.
- Each task receives *two separate* eight-probe evaluation sets. **Natural-heavy**: six random/natural, one guaranteed true-word-positive and one true-word-negative. **Diagnostic-heavy**: two natural/random, four rule-positive and two rule-negative. This controlled prevalence manipulation is **not natural task prevalence** and may alter model ranking. Both probe sets use identical members for all query strategies within a given task.
- Primary opportunity metric: among the eight legal one-label queries, the retrospective **hindsight best** improvement vs no additional label on the **same** probe set, measured as count of tasks with strict gain (>0). Hindsight reads final probe scores and is **not deployable**. Secondary feasible selectors use only demo-fitted candidate predictions: **max-Gini partition** and **minimax worst-case partition**, alongside exact uniform-one-label expectation and no-label. Distinguish both-wrong, no-disagreement, strong-context, out-of-basis and negative-value query cases.

## Predeclared diagnostic benchmark decision

Eight strata: S/G × in/out-of-basis × natural/diagnostic-heavy, each with six tasks. Evaluate **both random and curated** query pools separately, 16 table rows in total. Each stratum comprises 48 probe decisions (6×8). The primary acceptance reference is only **in-basis + diagnostic-heavy + curated pool** for *each* family, requiring:

1. At least **3/6 target tasks** with strict positive hindsight one-label gain; AND
2. At least **2/6 tasks** with strict positive gain from *deployable unlabeled max-Gini selector*; AND
3. Max-Gini sum of paired improvements over no-label **strictly positive**.

If all three hold separately for S and G, report `OPPORTUNITY_BENCHMARK_FEASIBLE_DEVELOPMENT_ONLY`, otherwise report **`BENCHMARK_HOLD_REDESIGN`**. This threshold was chosen as an exploratory *measurement feasibility* gate, **not** an inferential hypothesis test. Never posthoc pool across families or treatments to overturn the gate. Out-of-basis results are mandatory adversarial controls, not a GO condition.

## Resource and verification limits

Per task: two demo oracle calls + 16 counterfactual query labels (8 each pool) + 16 final-probe labels = **34** unique designed oracle labels; for 24 tasks: **816** newly measured labels. The 48 unlabeled reservoir examples/task do **not** receive oracle labels unless included among the selected eight. Historical fixture generation can perform additional oracle calls; track separately if instrumented. Actual CPU and wall time are measured externally; this benchmark does not include comparable costs for creating the curated pool or broader source-policy transfer.

Pre-score structural checks must verify: 24 task IDs, true rule basis segregation, no past-input overlap, no evaluator access in curation, preallocation oracle independence, no probe/pool overlap, fixed seeds, deterministic bank hash. Freeze exact code and bank SHA in GitHub. Use a bounded subprocess, capture stdout/stderr/exit code, and run exact deterministic replay plus independent saved-JSON arithmetic corruption tests. A failed run is `FAILED` or `TIMEOUT`, never a silent pass. Broad earlier E1.4 regression requires complete traceback and fresh fixture restoration; it is a separate engineering gate.

**Isolation:** this public test uses candidate and oracle in one trusted Python process, not genuine sandbox custody. Official Bubblewrap/verified equivalent, sealed data and independent semantic confirmation remain unverified. No additional spending, no modifications to Tod or `main`, no sealed E1.3 data.
