"""ACE F3.3: compositional-program synthesis and reusable learned macros.

A restricted, trusted DSL is used; the searcher sees only input/output probes,
not the target program. The source contains a generator for synthetic hidden
target programs; this is NOT a cryptographically sealed external benchmark.
No API, model training, arbitrary candidate code execution, or F4 data.
"""
from __future__ import annotations
import argparse, hashlib, json, os, random, sys
from dataclasses import dataclass
from pathlib import Path

STUDY='ACE-F3.3-COMPOSITION-20261104'
ARMS=('GUIDED_MACRO','GUIDED_NO_MACRO','BLIND_MACRO','BLIND_NO_MACRO')
FAMILIES=('S','G')
DEV_SEEDS=tuple(2026001+1009*i for i in range(12))
QA_SEEDS=(77011,77021)
CONFIRM_SEEDS=tuple(3000017+2017*i for i in range(24))
TASKS_PER_SEED=6
CANDIDATES_PER_TASK=48
PROBES_PER_CANDIDATE=5
FINAL_CASES=20
MAX_PRIMITIVE_LENGTH=4
MAX_MACROS=12
OPS=('r','l','q','a','m','s')  # S: reverse, left, right, +1, *2, swap endpoints
GOPS=('r','h','v','u','c','a') # G: rotate90, flips, row roll, col roll, +1


def canon(x):return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False)
def sha(x):return hashlib.sha256((x if isinstance(x,str) else canon(x)).encode()).hexdigest()
def file_sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def rng(*parts):return random.Random(int(sha(parts)[:16],16))

def primitives(fam):return OPS if fam=='S' else GOPS

def apply_op(fam,x,op):
    if fam=='S':
        if op=='r':return x[::-1]
        if op=='l':return x[1:]+x[:1]
        if op=='q':return x[-1:]+x[:-1]
        if op=='a':return tuple((v+1)%7 for v in x)
        if op=='m':return tuple((v*2)%7 for v in x)
        if op=='s':return (x[-1],)+x[1:-1]+(x[0],)
    else:
        g=[list(x[i*3:i*3+3]) for i in range(3)]
        if op=='r':g=[[g[2-j][i] for j in range(3)] for i in range(3)]
        elif op=='h':g=[row[::-1] for row in g]
        elif op=='v':g=g[::-1]
        elif op=='u':g=g[1:]+g[:1]
        elif op=='c':g=[row[1:]+row[:1] for row in g]
        elif op=='a':g=[[(v+1)%7 for v in row] for row in g]
        else:raise ValueError(f'unknown G op {op}')
        return tuple(v for row in g for v in row)
    raise ValueError(f'unknown S op {op}')

def exec_program(fam,x,expanded):
    if len(expanded)>MAX_PRIMITIVE_LENGTH or any(o not in primitives(fam) for o in expanded):
        raise ValueError('program out of DSL bounds')
    for op in expanded:x=apply_op(fam,x,op)
    return x

def make_input(seed,fam,task_id,kind,i):
    r=rng('input',seed,fam,task_id,kind,i)
    return tuple(r.randrange(7) for _ in range(7 if fam=='S' else 9))

def make_target(seed,fam,task_id):
    r=rng('latent_motif',seed,fam)
    base=primitives(fam)
    motif=(r.choice(base),r.choice(base))
    rt=rng('target_suffix',seed,fam,task_id)
    n=1 if task_id<2 else 2
    return motif+tuple(rt.choice(base) for _ in range(n))

def examples(seed,fam,task_id,kind,n):
    target=make_target(seed,fam,task_id)
    return [(make_input(seed,fam,task_id,kind,i),
             exec_program(fam,make_input(seed,fam,task_id,kind,i),target)) for i in range(n)]

def expand(tokens,library):
    out=[]
    for op in tokens:
        out.extend(library[op] if op.startswith('M') else (op,))
    return tuple(out)

def valid(fam,tokens,library):
    try:p=expand(tokens,library)
    except KeyError:return False
    return len(p)<=MAX_PRIMITIVE_LENGTH and all(o in primitives(fam) for o in p)

def grade(fam,expanded,probes):
    if not expanded:return 0.0
    hits=0;total=0
    for x,expected in probes:
        got=exec_program(fam,x,expanded)
        hits+=sum(a==b for a,b in zip(got,expected));total+=len(expected)
    return hits/total

def make_program(fam,rand,library,allow_macro):
    pool=list(primitives(fam)) + (list(sorted(library)) if allow_macro else [])
    for _ in range(40):
        n=rand.randint(1,4);cand=tuple(rand.choice(pool) for _ in range(n))
        if valid(fam,cand,library):return cand
    return (rand.choice(primitives(fam)),)

def perturb(fam,parent,rand,library,allow_macro):
    pool=list(primitives(fam))+(list(sorted(library)) if allow_macro else [])
    for _ in range(35):
        p=list(parent)
        kind=rand.choice(('sub','insert','delete','swap'))
        if kind=='sub' and p:p[rand.randrange(len(p))]=rand.choice(pool)
        elif kind=='insert':p.insert(rand.randrange(len(p)+1),rand.choice(pool))
        elif kind=='delete' and len(p)>1:p.pop(rand.randrange(len(p)))
        elif kind=='swap' and len(p)>1:
            i=rand.randrange(len(p));j=rand.randrange(len(p));p[i],p[j]=p[j],p[i]
        if p and tuple(p)!=parent and valid(fam,p,library):return tuple(p)
    return make_program(fam,rand,library,allow_macro)

def macros_from_best(best,library):
    # Transfer ONLY information from past training probes (never the final set).
    updated=dict(library)
    if best['score']<0.98:return updated,[]
    seq=tuple(best['expanded']);added=[]
    for i in range(len(seq)-1):
        pair=tuple(seq[i:i+2])
        if pair in updated.values():continue
        if len(updated)>=MAX_MACROS:break
        key=f'M{len(updated):02d}';updated[key]=pair;added.append({'name':key,'expansion':pair})
    return updated,added

def search_task(seed,fam,task_id,arm,library):
    if arm not in ARMS:raise ValueError('arm')
    guide=arm.startswith('GUIDED');macro=arm.endswith('MACRO') and not arm.endswith('NO_MACRO')
    pr=examples(seed,fam,task_id,'probe',PROBES_PER_CANDIDATE)
    # Separate random streams for two shared initial proposals vs arm-specific changes.
    init=rng('shared_initial',seed,fam,task_id)
    search=rng('search',seed,fam,task_id,arm)
    history=[];seen=set()
    for j in range(CANDIDATES_PER_TASK):
        if j<2:
            tokens=make_program(fam,init,{},False)
        elif guide and j%7!=0:
            top=sorted(history,key=lambda c:(-c['score'],len(c['expanded']),c['index']))[:6]
            parent=search.choice(top)
            tokens=perturb(fam,tuple(parent['tokens']),search,library,macro)
        else:
            parent=None
            tokens=make_program(fam,search,library,macro)
        if not valid(fam,tokens,library):raise AssertionError('invalid candidate')
        ex=expand(tokens,library)
        score=round(grade(fam,ex,pr),8)
        row={'index':j,'tokens':tokens,'expanded':ex,'score':score,'uses_macro':any(t.startswith('M') for t in tokens),
             'parent_index':parent['index'] if (j>=2 and guide and j%7!=0) else None}
        history.append(row);seen.add(ex)
    best=max(history,key=lambda c:(c['score'],-len(c['expanded']),-c['index']))
    final=examples(seed,fam,task_id,'final',FINAL_CASES)
    exact=sum(exec_program(fam,x,best['expanded'])==y for x,y in final)
    cell=round(grade(fam,best['expanded'],final),8)
    # Selection from training-probe scores only. Never use final scores to update library.
    next_lib,add=macros_from_best(best,library) if macro else (dict(library),[])
    return {'task_id':task_id,'arm':arm,'fam':fam,'seed':seed,'probe_count':len(pr),
            'candidate_count':len(history),'candidate_trace':history,'best_index':best['index'],
            'best_program':best['expanded'],'best_probe_score':best['score'],
            'final_exact':exact,'final_total':len(final),'final_cell_score':cell,
            'macro_before':library,'macros_added':add,'macro_after':next_lib,
            'target_audit_only':make_target(seed,fam,task_id),
            'final_manifest_sha256':sha([{'input':x,'output':y} for x,y in final])},next_lib

def run_condition(seed,fam,arm):
    lib={};tasks=[]
    for task in range(TASKS_PER_SEED):
        rec,lib=search_task(seed,fam,task,arm,lib)
        tasks.append(rec)
    return json.loads(canon({'seed':seed,'fam':fam,'arm':arm,'tasks':tasks,
            'exact':sum(x['final_exact'] for x in tasks),
            'total':sum(x['final_total'] for x in tasks),
            'macro_count':len(lib),
            'macro_used_candidates':sum(sum(c['uses_macro'] for c in x['candidate_trace']) for x in tasks),
            'library_final':lib,
            'first_two':[[c['expanded'] for c in x['candidate_trace'][:2]] for x in tasks]}))

def phase_seeds(phase):return {'dev':DEV_SEEDS,'qa':QA_SEEDS,'confirm':CONFIRM_SEEDS}[phase]

def atomic_json(path,obj):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_name('.'+path.name+'.tmp')
    with tmp.open('w',encoding='utf8') as f:
        f.write(canon(obj)+'\n');f.flush();os.fsync(f.fileno())
    os.replace(tmp,path)

def get_config(phase,manifest_sha=None):
    return json.loads(canon({'study':STUDY,'phase':phase,'seeds':phase_seeds(phase),'families':FAMILIES,
            'arms':ARMS,'tasks_per_seed':TASKS_PER_SEED,'candidates_per_task':CANDIDATES_PER_TASK,
            'probes_per_candidate':PROBES_PER_CANDIDATE,'final_cases_per_task':FINAL_CASES,
            'max_dsl_length':MAX_PRIMITIVE_LENGTH,'api_calls':0,'f4_heldout':'NOT_ACCESSED',
            'source_sha256':file_sha(__file__),'prereg_sha256':manifest_sha}))

def run_experiment(root,phase,manifest_sha=None,stop_after=None):
    root=Path(root);root.mkdir(parents=True,exist_ok=True)
    conf=get_config(phase,manifest_sha)
    cf=root/'config.json'
    if cf.exists() and json.loads(cf.read_text())!=conf:raise ValueError('config mismatch')
    if not cf.exists():atomic_json(cf,conf)
    log=root/'records.jsonl'
    records=[];prev='0'*64
    if log.exists():
        for line in log.read_text().splitlines():
            ev=json.loads(line)
            if ev['i']!=len(records) or ev['prev']!=prev or ev['hash']!=sha({k:v for k,v in ev.items() if k!='hash'}):
                raise ValueError('broken hash chain')
            records.append(ev);prev=ev['hash']
    ordered=[(seed,fam,arm) for seed in phase_seeds(phase) for fam in FAMILIES for arm in ARMS]
    if len(records)>len(ordered):raise ValueError('extra records')
    for idx,ev in enumerate(records):
        if (ev['record']['seed'],ev['record']['fam'],ev['record']['arm'])!=ordered[idx]:raise ValueError('order changed')
        # Full deterministic semantic verification of completed records.
        if ev['record']!=run_condition(*ordered[idx]):raise ValueError('record was altered')
    appended=0
    for i in range(len(records),len(ordered)):
        if stop_after is not None and appended>=stop_after:break
        record=run_condition(*ordered[i])
        ev={'i':i,'prev':prev,'record':record,'config_hash':sha(conf)}
        ev['hash']=sha(ev)
        with log.open('a',encoding='utf8') as f:
            f.write(canon(ev)+'\n');f.flush();os.fsync(f.fileno())
        prev=ev['hash'];records.append(ev);appended+=1
        atomic_json(root/'checkpoint.json',{'last_i':i,'head':prev,
                'status':'COMPLETED' if len(records)==len(ordered) else 'CHECKPOINTED'})
    return summarise(records,phase,len(ordered))

def summarise(events,phase,expected):
    d={arm:{'exact':0,'total':0,'macro_used_candidates':0,'macro_count':0,'runs':0} for arm in ARMS}
    by_pair=[]
    for e in events:
        r=e['record'];s=d[r['arm']];s['exact']+=r['exact'];s['total']+=r['total']
        s['macro_used_candidates']+=r['macro_used_candidates'];s['macro_count']+=r['macro_count'];s['runs']+=1
        by_pair.append({'seed':r['seed'],'family':r['fam'],'arm':r['arm'],'exact':r['exact'],'total':r['total']})
    return {'phase':phase,'completed_runs':len(events),'expected_runs':expected,'complete':len(events)==expected,
            'aggregates':d,'pairs':by_pair,'event_head':events[-1]['hash'] if events else '0'*64}

def audit(root,phase,manifest_sha=None):
    # No execution of existing candidates, and no network. Semantic replay of all runs.
    root=Path(root);cfg=get_config(phase,manifest_sha)
    if json.loads((root/'config.json').read_text())!=cfg:raise ValueError('config mismatch')
    lines=(root/'records.jsonl').read_text().splitlines();events=[];head='0'*64
    order=[(seed,fam,arm) for seed in phase_seeds(phase) for fam in FAMILIES for arm in ARMS]
    for i,line in enumerate(lines):
        ev=json.loads(line)
        if ev['i']!=i or ev['prev']!=head or ev['hash']!=sha({k:v for k,v in ev.items() if k!='hash'}):
            raise ValueError('hash chain error')
        if ev['config_hash']!=sha(cfg):raise ValueError('config digest')
        if ev['record']!=run_condition(*order[i]):raise ValueError('semantic replay mismatch')
        head=ev['hash'];events.append(ev)
    cp=json.loads((root/'checkpoint.json').read_text())
    if cp['head']!=head or cp['last_i']!=len(events)-1:raise ValueError('checkpoint mismatch')
    return summarise(events,phase,len(order))

def main():
    p=argparse.ArgumentParser();p.add_argument('action',choices=('run','audit'));p.add_argument('--phase',choices=('dev','qa','confirm'),required=True);p.add_argument('--out',required=True);p.add_argument('--prereg',default=None);p.add_argument('--stop-after',type=int)
    a=p.parse_args()
    prereg_sha=file_sha(a.prereg) if a.prereg else None
    if a.phase=='confirm' and not a.prereg:raise ValueError('confirmation requires frozen preregistration')
    if a.action=='run':result=run_experiment(a.out,a.phase,prereg_sha,a.stop_after)
    else:result=audit(a.out,a.phase,prereg_sha)
    print(canon({'phase':a.phase,'complete':result['complete'],'runs':result['completed_runs'],'aggregates':result['aggregates']}))
if __name__=='__main__':main()
