"""F3.3 unit/contract tests; separate from confirm seed study results."""
import json, tempfile, unittest
from pathlib import Path
from unittest.mock import patch
import ace_f33 as a

class TestF33(unittest.TestCase):
    def test_seed_disjoint(self):
        self.assertFalse(set(a.DEV_SEEDS)&set(a.CONFIRM_SEEDS))
        self.assertFalse(set(a.QA_SEEDS)&set(a.CONFIRM_SEEDS))
    def test_families_are_distinct(self):
        self.assertNotEqual(a.OPS,a.GOPS)
    def test_s_operators(self):
        x=(0,1,2,3,4,5,6)
        self.assertEqual(a.apply_op('S',x,'r'),x[::-1])
        self.assertEqual(a.apply_op('S',x,'l'),x[1:]+x[:1])
        self.assertEqual(a.apply_op('S',x,'q'),x[-1:]+x[:-1])
        self.assertEqual(a.apply_op('S',x,'a'),(1,2,3,4,5,6,0))
        self.assertEqual(a.apply_op('S',x,'m'),(0,2,4,6,1,3,5))
        self.assertEqual(a.apply_op('S',x,'s'),(6,1,2,3,4,5,0))
    def test_g_operators(self):
        x=(0,1,2,3,4,5,6,0,1)
        self.assertEqual(a.apply_op('G',x,'v'),(6,0,1,3,4,5,0,1,2))
        self.assertEqual(a.apply_op('G',x,'h'),(2,1,0,5,4,3,1,0,6))
        self.assertEqual(a.apply_op('G',x,'r'),(6,3,0,0,4,1,1,5,2))
        self.assertEqual(a.apply_op('G',x,'u'),(3,4,5,6,0,1,0,1,2))
        self.assertEqual(a.apply_op('G',x,'c'),(1,2,0,4,5,3,0,1,6))
    def test_dsl_rejects_invalid(self):
        with self.assertRaises(ValueError):a.exec_program('S',tuple(range(7)),('Q',))
        with self.assertRaises(ValueError):a.exec_program('G',tuple(range(9)),('r',)*5)
    def test_examples_are_deterministic_and_separated(self):
        p=a.examples(300,'S',3,'probe',5);f=a.examples(300,'S',3,'final',20)
        self.assertEqual(p,a.examples(300,'S',3,'probe',5))
        self.assertFalse({x for x,y in p}&{x for x,y in f})
    def test_target_has_reused_pair(self):
        for fam in a.FAMILIES:
            t=[a.make_target(340,fam,i) for i in range(6)]
            self.assertEqual(len({x[:2] for x in t}),1)
            self.assertEqual([len(x) for x in t],[3,3,4,4,4,4])
    def test_macro_is_real_composition(self):
        x=(0,1,2,3,4,5,6)
        seq=('r','a')
        y=a.exec_program('S',x,seq)
        self.assertTrue(all(y!=a.exec_program('S',x,(o,)) for o in a.OPS))
    def test_macro_expansion(self):
        lib={'M00':('r','a')}
        self.assertEqual(a.expand(('M00','m'),lib),('r','a','m'))
        self.assertFalse(a.valid('S',('M00','M00','m'),lib))
    def test_macros_derive_from_probe_winner(self):
        new,added=a.macros_from_best({'score':1.,'expanded':('r','a','m')},{})
        self.assertEqual(len(new),2);self.assertEqual(len(added),2)
        no,_=a.macros_from_best({'score':0.4,'expanded':('r','a')},{})
        self.assertEqual(no,{})
    def test_candidate_count_and_budget_equal(self):
        for arm in a.ARMS:
            rec,lib=a.search_task(77011,'S',2,arm,{})
            self.assertEqual(rec['candidate_count'],a.CANDIDATES_PER_TASK)
            self.assertEqual(rec['probe_count'],a.PROBES_PER_CANDIDATE)
            self.assertEqual(rec['final_total'],a.FINAL_CASES)
            self.assertTrue(all(len(c['expanded'])<=4 for c in rec['candidate_trace']))
    def test_initial_candidates_shared(self):
        allrec=[a.search_task(77021,'G',4,arm,{})[0] for arm in a.ARMS]
        first=[tuple(c['expanded'] for c in r['candidate_trace'][:2]) for r in allrec]
        self.assertEqual(len(set(first)),1)
    def test_guided_feedback_changes_proposals(self):
        original=a.grade
        baseline=a.search_task(77011,'S',2,'GUIDED_NO_MACRO',{})[0]
        def muted(fam,p,probes):
            if len(probes)==a.PROBES_PER_CANDIDATE:return 0.
            return original(fam,p,probes)
        with patch.object(a,'grade',muted):
            altered=a.search_task(77011,'S',2,'GUIDED_NO_MACRO',{})[0]
        self.assertNotEqual([c['expanded'] for c in baseline['candidate_trace']],
                            [c['expanded'] for c in altered['candidate_trace']])
    def test_blind_proposals_ignore_scores(self):
        original=a.grade
        baseline=a.search_task(77011,'S',2,'BLIND_NO_MACRO',{})[0]
        def muted(fam,p,probes):return 0. if len(probes)==5 else original(fam,p,probes)
        with patch.object(a,'grade',muted):
            altered=a.search_task(77011,'S',2,'BLIND_NO_MACRO',{})[0]
        self.assertEqual([c['expanded'] for c in baseline['candidate_trace']],
                         [c['expanded'] for c in altered['candidate_trace']])
    def test_no_macro_arm_no_library(self):
        for arm in ('BLIND_NO_MACRO','GUIDED_NO_MACRO'):
            x=a.run_condition(77011,'S',arm)
            self.assertEqual(x['macro_count'],0)
            self.assertFalse(x['macro_used_candidates'])
    def test_macro_arm_library_is_derived(self):
        for arm in ('BLIND_MACRO','GUIDED_MACRO'):
            x=a.run_condition(77011,'S',arm)
            self.assertLessEqual(x['macro_count'],a.MAX_MACROS)
            self.assertTrue(all(len(v)==2 for v in x['library_final'].values()))
    def test_deterministic_run(self):
        self.assertEqual(a.run_condition(77021,'G','GUIDED_MACRO'),a.run_condition(77021,'G','GUIDED_MACRO'))
    def test_task_probe_evaluation_separated(self):
        rc=a.search_task(77011,'S',0,'GUIDED_NO_MACRO',{})[0]
        self.assertEqual(rc['final_total'],20)
        self.assertTrue(all(c['score']<=1 for c in rc['candidate_trace']))
    def test_resume_and_audit(self):
        with tempfile.TemporaryDirectory() as t:
            r=a.run_experiment(t,'qa',stop_after=3)
            self.assertFalse(r['complete']);self.assertEqual(r['completed_runs'],3)
            r2=a.run_experiment(t,'qa');self.assertTrue(r2['complete'])
            r3=a.audit(t,'qa');self.assertEqual(r2,r3)
    def test_repeated_resume_idempotent(self):
        with tempfile.TemporaryDirectory() as t:
            a.run_experiment(t,'qa');p=Path(t)/'records.jsonl';before=p.read_bytes()
            a.run_experiment(t,'qa');self.assertEqual(before,p.read_bytes())
    def test_reject_tampered_log(self):
        with tempfile.TemporaryDirectory() as t:
            a.run_experiment(t,'qa',stop_after=1);p=Path(t)/'records.jsonl'
            x=json.loads(p.read_text());x['record']['exact']+=1;p.write_text(json.dumps(x)+'\n')
            with self.assertRaises(ValueError):a.audit(t,'qa')
    def test_confirm_requires_prereg_cli(self):
        self.assertNotIn('confirm',a.ARMS)
        self.assertEqual(a.get_config('qa')['f4_heldout'],'NOT_ACCESSED')

if __name__=='__main__':unittest.main(verbosity=2)
