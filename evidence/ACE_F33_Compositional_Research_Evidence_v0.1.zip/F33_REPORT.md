# ACE F3.3 — Laporan penelitian komposisi primitive dan transfer macro

**Tanggal:** 4 November 2026  
**Versi:** v0.1  
**Keputusan:** `ENGINEERING_PASS / MACRO_SYNTHESIS_OBSERVED / PRIMARY_PERFORMANCE_ADVANTAGE_INCONCLUSIVE / GENERAL_INTELLIGENCE_EVOLUTION_NOT_PROVEN / F4_HOLD`

## 1. Pertanyaan penelitian

Apakah pencarian program berbasis umpan balik dapat membentuk *macro* baru melalui komposisi operator primitif dan menggunakan macro tersebut pada tugas berikutnya, serta apakah kebijakan itu memiliki keunggulan atas kebijakan yang identik tetapi **tanpa pustaka macro**?

Penelitian ini memakai bahasa program mini yang sengaja dibatasi: enam operasi elementer untuk vektor simbolik dan enam untuk grid 3×3. Kandidat berisi rangkaian operator sepanjang maksimal empat operasi primitif. *Macro* adalah rangkaian dua operator yang diambil dari kandidat terbaik pada **probe pelatihan**, kemudian diubah menjadi simbol baru di pustaka program. Tidak ada model AI baru, Python tak tepercaya, atau operasi fisik yang dijalankan.

## 2. Dua tahap konfirmasi dan koreksi metodologis

Pada studi awal **F3.3a**, peneliti menemukan setelah eksekusi bahwa tiap kebijakan mendapatkan *stream* RNG kandidat yang berbeda, sehingga selisih skor mencampur pengaruh kebijakan dengan fluktuasi pencarian acak. Hasil F3.3a **tidak dipakai sebagai bukti kausal primer**, meskipun log dan sumbernya dipertahankan.

Pada **F3.3b**, kebijakan dengan dan tanpa macro pada keluarga pencarian yang sama mendapatkan stream RNG yang disejajarkan, serta dua proposal awal identik. Studi kemudian dibekukan melalui berkas `F33B_PREREGISTRATION.json` sebelum seed konfirmasi baru dieksekusi.

- SHA-256 kode sumber F3.3b: `e7503e6d7512f1b6bbf69ac1e3afe14086b25e2801124d2bdb44caa0ffe50362`
- SHA-256 manifest praregistrasi internal: `4c5cae7e554b52b54e67533341d954540ee77879de10f60d79fbf9137e7dc7b7`
- Praregistrasi dilakukan dalam lingkungan kerja yang sama; **tidak** diberi timestamp atau disahkan oleh lembaga independen.
- Pengujian pada seed baru tetap perlu dibaca bersama fakta bahwa rancangan penelitian telah diiterasi berdasarkan hasil uji terdahulu.

## 3. Kontrak F3.3b

Empat kebijakan diuji:

| Kebijakan | Pencarian menggunakan skor sebelumnya | Macro dapat dipakai antartugas |
|---|---|---|
| `GUIDED_MACRO` | Ya | Ya |
| `GUIDED_NO_MACRO` | Ya | Tidak |
| `BLIND_MACRO` | Tidak untuk proposal, tetapi skor untuk seleksi akhir | Ya |
| `BLIND_NO_MACRO` | Tidak untuk proposal, tetapi skor untuk seleksi akhir | Tidak |

**24 seed konfirmasi baru × 2 keluarga × 4 kebijakan = 192 run.** Masing-masing run berisi enam tugas, dengan 48 kandidat per tugas, lima probe per kandidat dan 20 kasus evaluasi akhir untuk kandidat yang dibekukan. Total: **1.152 tugas, 55.296 kandidat, 276.480 evaluasi probe, dan 23.040 kasus evaluasi akhir**. Setiap kebijakan menggunakan 5.760 kasus evaluasi akhir yang *dipasangkan* berdasarkan seed, keluarga, tugas dan input.

Generasi target memakai *motif* dua operator yang berulang pada keenam tugas dalam suatu pasangan seed–keluarga; dua tugas awal memiliki satu operator tambahan dan empat tugas berikutnya memiliki dua operator tambahan. Ini adalah **benchmark sintetis yang memang memudahkan pemanfaatan ulang macro**. Semua evaluasi akhir merupakan instance input yang baru **dalam grammar sama**; ini **bukan** bank struktural *held-out* F4.

Skor probe dihitung dengan kecocokan elemen keluaran. Hanya skor probe yang boleh digunakan untuk memilih kandidat dan memutuskan pembentukan macro. Hasil akhir tidak digunakan untuk memperbarui pustaka. Setiap kandidat dijalankan melalui interpreter DSL tepercaya, tanpa mengeksekusi Python buatan agen.

## 4. Hasil konfirmatori

| Kebijakan | Tepat / 5.760 | Akurasi |
|---|---:|---:|
| Guided + macro | **2.294** | **39,83%** |
| Guided tanpa macro | 2.198 | 38,16% |
| Blind + macro | 2.197 | 38,14% |
| Blind tanpa macro | 2.097 | 36,41% |

Kontras primer yang dibekukan: **Guided + macro − Guided tanpa macro = +96/5.760 = +1,667 poin persentase**. Interval *cluster bootstrap* 95%, resampling pada 24 seed dan mempertahankan dua keluarga serta tugas dalam setiap cluster, adalah **[−2,795; +6,146] poin persentase**. Interval mencakup nol. Dengan demikian, **keunggulan konfirmatori primer belum terbukti**. Hasil berpasangan berdasarkan seed: 10 menang, 5 seri, 9 kalah.

Kontras sekunder:

- Blind + macro vs Blind tanpa macro: **+1,736 poin**; 95% CI **[−2,135; +5,747]**.
- Guided + macro vs Blind + macro: **+1,684 poin**; 95% CI **[−4,236; +7,569]**.
- Interaksi kebijakan berpemandu × keberadaan macro: **−0,069 poin**; 95% CI **[−6,962; +6,701]**.

Tidak ada kontras di atas yang dapat dibaca sebagai bukti kuat keunggulan menyeluruh.

### Per keluarga tugas

| Keluarga | Guided + macro | Guided tanpa macro | Selisih |
|---|---:|---:|---:|
| Simbolik / 2.880 | 1.134 | 1.036 | **+98** |
| Grid / 2.880 | 1.160 | 1.162 | **−2** |

Keuntungan utama terkonsentrasi pada tugas simbolik; **tidak ada keuntungan agregat pada grid**. Angka keluarga merupakan eksplorasi heterogenitas, bukan klaim konfirmasi terpisah.

## 5. Bukti penciptaan dan pewarisan komposisi

- **273 catatan macro** dibentuk di seluruh run kebijakan yang memperbolehkan macro: 134 pada Guided + macro dan 139 pada Blind + macro.
- Terdapat **71 pasangan ekspansi macro unik** dari ruang pasangan dua-operator tertutup yang seluruh primitive-nya dipilih manusia: 35 pada simbolik dan 36 pada grid.
- Ke-273 macro yang terbentuk memiliki transformasi yang berbeda dari setiap operator atom tunggal pada rangkaian input audit. Ini menunjukkan **komposisi non-atomik** dalam domain uji, bukan penemuan semantik yang tidak dapat dicapai sebelumnya.
- **4.289 proposal kandidat** menggunakan simbol macro dari pustaka hasil tugas sebelumnya. Sebanyak 113 tugas memilih kandidat akhir yang memuat macro.
- Mutasi, seleksi, penyimpanan hasil antartugas dan pemulihan/penilaian ulang dapat dijalankan otomatis dalam harness. Akan tetapi, seluruh ruang operator dan mekanisme pembentukannya masih ditentukan manusia.

**Batas makna:** penggunaan ulang macro terobservasi, tetapi perubahan skor ketika macro diaktifkan belum cukup presisi untuk menyimpulkan bahwa transfer menyebabkan keuntungan terukur yang konsisten pada populasi tugas sintetis ini.

## 6. Bukti rekayasa dan integritas

- **22/22 tes teknis** lulus. Tes mencakup keterulangan, batas DSL, operator simbolik/grid, pemisahan probe–final, empat anggaran setara, kesamaan dua proposal awal, efek feedback pada proposal, kontrol buta, pembangunan macro dari skor probe, checkpoint, kelanjutan setelah interupsi, serta penolakan log tamper.
- **192/192 run konfirmasi** lolos pemeriksaan ulang semantik melalui kode yang telah dibekukan.
- Rantai hash peristiwa, konfigurasi, checkpoint, dan SHA-256 sumber dibandingkan ulang.
- Berkas `F33B_ANALYSIS.json` mencakup tabel skor, pemisahan keluarga, interval bootstrap, audit macro, dan statistik berpasangan.
- Notebook Colab dibuat untuk menjalankan tes dan uji konfirmasi tanpa API key serta menghasilkan ZIP bukti. **Reproduksi notebook di akun Colab pengguna belum diuji saat laporan ini dibuat.**

## 7. Keterbatasan ilmiah

1. Macro berisi *komposisi operator yang sudah diketahui*. **Tidak ada bukti penemuan operator fundamental, paradigma belajar baru, AGI, atau kecerdasan yang berevolusi terbuka**.
2. Semua tugas dihasilkan dari grammar sintetis dengan pola berulang. Hasil tidak mewakili kemampuan lintas domain yang benar-benar berbeda.
3. Generator target dan evaluator berada pada harness penelitian yang sama dan belum disegel oleh penilai eksternal. Pada implementasi, pembentuk proposal menerima contoh input/output, tetapi sumber sistem mengandung generator target untuk keperluan audit.
4. Anggaran jumlah kandidat dan kasus probe disamakan, tetapi waktu CPU aktual tidak dipaksa identik.
5. Saat macro tersedia, distribusi panjang program efektif dan himpunan proposal berubah. Intervensi ini menguji **keseluruhan kebijakan transfer-macro**, bukan efek satu subkomponen terisolasi.
6. Perubahan dari F3.3a ke F3.3b dilakukan berdasarkan temuan metode, lalu memakai seed konfirmasi baru; hasil kedua tidak menghapus isu pengembangan berulang.
7. Bank F4 yang direncanakan untuk generalisasi struktural **tidak dipakai**.

## 8. Keputusan gerbang

| Gerbang | Status |
|---|---|
| Implementasi komposisi, library macro, dan penggunaan ulang | **PASS — dalam DSL terbatas** |
| Tes rekayasa, hash, replay, dan checkpoint | **PASS** |
| Keunggulan kausal Guided + macro atas Guided tanpa macro | **INCONCLUSIVE** |
| Keunggulan yang stabil di simbolik dan grid sekaligus | **NOT SHOWN** |
| Penemuan primitive fundamental secara otonom | **NOT PROVEN** |
| F4 — uji generalisasi struktural | **HOLD / NOT RUN** |

**Rekomendasi selanjutnya:** kembangkan eksperimen untuk grammar dan tugas yang tidak berbagi motif yang dirancang sebelumnya, dengan kontrol terkuat yang sama serta materi evaluasi struktural yang dibuat dan disegel sebelum penelitian. Jangan membuka bank F4 yang sudah direncanakan tanpa mengunci metode dan aturan klaim. Progres saat ini adalah bukti mekanisme **komposisi dan pewarisan program** yang bekerja, bukan bukti bahwa ACE sudah mencapai tujuan evolusi kecerdasan umum.
