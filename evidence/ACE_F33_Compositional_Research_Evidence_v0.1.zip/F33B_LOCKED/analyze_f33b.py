"""Post-run analysis of preregistered F3.3b confirmatory study.
This script does not modify the locked experiment module or its results.
"""
import json,random,hashlib,collections
from pathlib import Path

ARMS=('GUIDED_MACRO','GUIDED_NO_MACRO','BLIND_MACRO','BLIND_NO_MACRO')
SEED=33991;B=10000

def read_records(path):
    records=[];prev='0'*64
    for i,line in enumerate(Path(path).read_text().splitlines()):
        x=json.loads(line)
        if x['i']!=i or x['prev']!=prev:raise ValueError('bad chain')
        h=hashlib.sha256(json.dumps({k:v for k,v in x.items() if k!='hash'},sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()).hexdigest()
        if h!=x['hash']:raise ValueError('wrong chain SHA')
        prev=h;records.append(x['record'])
    return records

def diff_ci(d,policy_a,policy_b):
    seeds=sorted({seed for seed,fam,arm in d})
    denom=sum(d[s,f,'total'] for s in seeds for f in ('S','G') if (s,f,'total') in d)
    nrows=len(seeds)
    paired=[sum(d[s,f,policy_a]-d[s,f,policy_b] for f in ('S','G')) for s in seeds]
    total_den=sum(d[s,f,'total'] for s in seeds for f in ('S','G'))
    obs=100*sum(paired)/total_den
    r=random.Random(SEED)
    vals=[]
    for _ in range(B):
        draw=[r.randrange(nrows) for _ in range(nrows)]
        vals.append(100*sum(paired[i] for i in draw)/total_den)
    vals.sort()
    return {'difference_correct':sum(paired),'total':total_den,'difference_pp':round(obs,5),
        'ci95_pp':[round(vals[int(0.025*B)],5),round(vals[int(0.975*B)],5)],
        'seed_pair_wins':sum(v>0 for v in paired),'seed_pair_ties':sum(v==0 for v in paired),'seed_pair_losses':sum(v<0 for v in paired)}

def main():
    root=Path(__file__).parent
    records=read_records(root/'confirm_runs'/'records.jsonl')
    d={};families={};samples=collections.defaultdict(lambda:collections.Counter())
    outcomes=collections.Counter();all_macros=[];macro_winners=collections.Counter();macro_candidates=collections.Counter();training_cases=0
    target_comp=collections.Counter();early_equal=True;armsfirst=collections.defaultdict(dict)
    for r in records:
        s=r['seed'];fam=r['fam'];arm=r['arm'];d[(s,fam,arm)]=r['exact'];d[(s,fam,'total')]=r['total']
        for t in r['tasks']:
            idx=t['task_id'];samples[(arm,fam,'early' if idx<2 else 'late')]['exact']+=t['final_exact']
            samples[(arm,fam,'early' if idx<2 else 'late')]['total']+=t['final_total']
            samples[(arm,fam,idx)]['exact']+=t['final_exact'];samples[(arm,fam,idx)]['total']+=t['final_total']
            armsfirst[(s,fam,arm.startswith('GUIDED'),idx)][arm]=t
            if arm.endswith('MACRO') and not arm.endswith('NO_MACRO'):
                for item in t['macros_added']:
                    # A two-op macro's behavior is semantically new if it differs from every single
                    # primitive on a fixed suite of deterministic validation inputs.
                    all_macros.append({'fam':fam,'seq':tuple(item['expansion']),'seed':s,'arm':arm})
                if any(c['uses_macro'] for c in t['candidate_trace']):outcomes['tasks_with_macro_proposals']+=1
                if t['best_index']>=0 and t['candidate_trace'][t['best_index']]['uses_macro']:
                    outcomes['tasks_winner_macro']+=1
                    outcomes['winner_macro_exact']+=t['final_exact'];outcomes['winner_macro_total']+=t['final_total']
                if idx>0:outcomes['transfer_stage_tasks']+=1
            target_comp[(fam,tuple(t['target_audit_only']))]+=1
    # check no-macro and macro first task identical within guided/blind shared random streams
    for (s,f,g,idx),rec in armsfirst.items():
        names=['GUIDED_MACRO','GUIDED_NO_MACRO'] if g else ['BLIND_MACRO','BLIND_NO_MACRO']
        if idx==0:
            early_equal &= rec[names[0]]['best_program']==rec[names[1]]['best_program']
            early_equal &= rec[names[0]]['final_exact']==rec[names[1]]['final_exact']
    # primary and secondary intervals (note: prereg primary only for claiming supported)
    comparisons={
        'primary_guided_macro_vs_guided_no_macro':diff_ci(d,'GUIDED_MACRO','GUIDED_NO_MACRO'),
        'secondary_blind_macro_vs_blind_no_macro':diff_ci(d,'BLIND_MACRO','BLIND_NO_MACRO'),
        'secondary_guided_macro_vs_blind_macro':diff_ci(d,'GUIDED_MACRO','BLIND_MACRO')}
    # 2x2 interaction with matched clusters
    seeds=sorted({s for s,f,a in d if a in ARMS})
    interactions=[]
    for s in seeds:
        interactions.append(sum(d[s,f,'GUIDED_MACRO']-d[s,f,'GUIDED_NO_MACRO']-
                                d[s,f,'BLIND_MACRO']+d[s,f,'BLIND_NO_MACRO'] for f in ('S','G')))
    r=random.Random(SEED);v=[];den=24*2*6*20
    for _ in range(B):v.append(100*sum(interactions[r.randrange(len(seeds))] for _ in seeds)/den)
    v.sort()
    comparisons['secondary_interaction']={'difference_correct':sum(interactions),'difference_pp':round(100*sum(interactions)/den,5),
            'ci95_pp':[round(v[int(.025*B)],5),round(v[int(.975*B)],5)]}
    aggregates={}
    for arm in ARMS:
        c=sum(r['exact'] for r in records if r['arm']==arm)
        n=sum(r['total'] for r in records if r['arm']==arm)
        aggregates[arm]={'correct':c,'total':n,'accuracy_pct':round(100*c/n,4)}
    family_results={}
    for fam in ('S','G'):
        fam_res={}
        for arm in ARMS:
            c=sum(d[s,fam,arm] for s in seeds);n=24*6*20
            fam_res[arm]={'correct':c,'total':n,'accuracy_pct':round(100*c/n,4)}
        family_results[fam]=fam_res
    # mixed subset bias: macro semantic uniqueness not just labels
    import ace_f33 as a
    uniquely=collections.Counter();by_arm=collections.Counter();seen_by_family=collections.defaultdict(set)
    for m in all_macros:
        fam=m['fam'];seq=m['seq'];by_arm[m['arm']]+=1;seen_by_family[fam].add(seq)
        basis=[a.make_input(501,fam,i,'macro_audit',j) for i in (0,1) for j in range(10)]
        vals=tuple(a.exec_program(fam,x,seq) for x in basis)
        if all(vals!=tuple(a.exec_program(fam,x,(op,)) for x in basis) for op in a.primitives(fam)):
            uniquely[m['arm']]+=1
    out={'study':'ACE-F3.3B-PAIRED-RNG-20261104','records':len(records),'candidate_evaluations':len(records)*6*48,
         'probe_evaluations':len(records)*6*48*5,
         'final_evaluations':len(records)*6*20,
         'aggregates':aggregates,'family_results':family_results,'comparisons':comparisons,
         'samples':{'|'.join(str(v) for v in k):dict(v) for k,v in samples.items()},
         'macro_discovery':{'learned_macros_total':len(all_macros),'by_arm':dict(by_arm),'semantically_distinct_from_atomic_by_arm':dict(uniquely),
                            'unique_expansions_by_family':{k:len(v) for k,v in seen_by_family.items()},
                            'winner_uses_macro_task_count':outcomes['tasks_winner_macro'],
                            'winner_uses_macro_exact':outcomes['winner_macro_exact'],
                            'winner_uses_macro_total':outcomes['winner_macro_total'],
                            'tasks_with_macro_proposals':outcomes['tasks_with_macro_proposals'],
                            'eligible_later_tasks':outcomes['transfer_stage_tasks']},
         'first_task_control_equal':early_equal,'sha256_records':hashlib.sha256((root/'confirm_runs'/'records.jsonl').read_bytes()).hexdigest(),
         'f4_heldout':'NOT_ACCESSED'}
    (root/'F33B_ANALYSIS.json').write_text(json.dumps(out,indent=2,ensure_ascii=False,sort_keys=True)+'\n',encoding='utf8')
    print(json.dumps({'aggregates':aggregates,'comparisons':comparisons,'family_results':family_results,'macro_discovery':out['macro_discovery']},ensure_ascii=False,indent=2))
if __name__=='__main__':main()
