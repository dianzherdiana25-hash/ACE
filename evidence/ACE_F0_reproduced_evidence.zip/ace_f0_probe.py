#!/usr/bin/env python3
"""ACE F0 CPU-only feasibility probe. Pure Python; no external calls or credentials.

It validates small deterministic development fixtures and demonstrates an event-
ledger recovery boundary. It is NOT an ACE A/B/C agent experiment.
"""
from __future__ import annotations
import argparse, hashlib, heapq, json, os, platform, random, shutil, subprocess, sys, time
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
WORK = ROOT / 'runtime'
EVENTS = WORK / 'events.jsonl'
CHECKPOINT = WORK / 'checkpoint.json'
SEED = 1729

def utc_now():
    return datetime.now(timezone.utc).isoformat()

def canon(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False)

def sha(data):
    if not isinstance(data, bytes): data = data.encode('utf-8')
    return hashlib.sha256(data).hexdigest()

def atomic_json(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name + '.tmp')
    temp.write_text(json.dumps(obj, ensure_ascii=False, indent=2, sort_keys=True)+'\n', encoding='utf-8')
    os.replace(temp, path)

def load_events():
    if not EVENTS.exists(): return []
    return [json.loads(s) for s in EVENTS.read_text(encoding='utf-8').splitlines() if s.strip()]

def append_once(event_id, action, result):
    existing = load_events()
    if any(e['event_id'] == event_id for e in existing):
        return False
    prior = existing[-1]['entry_hash'] if existing else 'GENESIS'
    entry = {'event_id': event_id, 'action': action, 'outcome': result,
             'prior_hash': prior, 'timestamp_utc': utc_now()}
    entry['entry_hash'] = sha(canon(entry))
    with EVENTS.open('a', encoding='utf-8') as f:
        f.write(canon(entry)+'\n'); f.flush(); os.fsync(f.fileno())
    return True

def validate_chain(events):
    prior='GENESIS'; ids=set()
    for entry in events:
        if entry['event_id'] in ids or entry['prior_hash'] != prior:
            return False
        e=dict(entry); digest=e.pop('entry_hash', None)
        if digest != sha(canon(e)): return False
        prior=digest; ids.add(entry['event_id'])
    return True

def symbolic(tokens, operations):
    seq=list(tokens)
    for op in operations:
        if op['op']=='reverse': seq.reverse()
        elif op['op']=='rotate_left':
            steps=op['steps'] % len(seq) if seq else 0
            seq=seq[steps:]+seq[:steps]
        elif op['op']=='filter_value': seq=[x for x in seq if x != op['value']]
        else: raise ValueError('Unknown operation')
    return seq

def dijkstra(nodes, edges, start, goal):
    graph={n:[] for n in nodes}
    for a,b,w in edges:
        if w<0: raise ValueError('Negative weight')
        graph[a].append((b,w)); graph[b].append((a,w))
    queue=[(0,start)]; dist={start:0}
    while queue:
        cost,node=heapq.heappop(queue)
        if cost != dist[node]: continue
        if node==goal: return cost
        for other,w in graph[node]:
            nc=cost+w
            if nc<dist.get(other, float('inf')):
                dist[other]=nc; heapq.heappush(queue, (nc,other))
    return None

def valid_optimal_path(nodes, edges, start, goal, path, declared_cost):
    optimum=dijkstra(nodes,edges,start,goal)
    if optimum is None: return path is None and declared_cost is None
    if not path or path[0]!=start or path[-1]!=goal: return False
    pairweights={}
    for a,b,w in edges:
        pairweights[(a,b)]=min(pairweights.get((a,b),float('inf')),w)
        pairweights[(b,a)]=min(pairweights.get((b,a),float('inf')),w)
    if any((a,b) not in pairweights for a,b in zip(path,path[1:])): return False
    cost=sum(pairweights[(a,b)] for a,b in zip(path,path[1:]))
    return cost==optimum and cost==declared_cost

def test_cases():
    # Only DEV smoke fixtures. No sealed held-out tasks created or read.
    cases={
        'S01_reference': symbolic(['a','b','c','d'],[{'op':'reverse'}, {'op':'rotate_left','steps':1}]) == ['c','b','a','d'],
        'S02_empty': symbolic([], [{'op':'reverse'}, {'op':'rotate_left','steps':99}]) == [],
        'S03_duplicate_filter': symbolic(['x','y','x'], [{'op':'filter_value','value':'x'}]) == ['y'],
        'G01_weighted_optimal': valid_optimal_path(['A','B','C'], [('A','B',2),('B','C',3),('A','C',9)], 'A','C',['A','B','C'],5),
        'G02_reject_suboptimal': not valid_optimal_path(['A','B','C'], [('A','B',2),('B','C',3),('A','C',9)], 'A','C',['A','C'],9),
        'G03_accept_tie': valid_optimal_path(['A','B','C','D'], [('A','B',1),('B','D',1),('A','C',1),('C','D',1)],'A','D',['A','C','D'],2),
        'G04_unreachable': valid_optimal_path(['A','B','C'], [('A','B',1)], 'A','C',None,None),
        'G05_zero_weight': valid_optimal_path(['A','B'], [('A','B',0)],'A','B',['A','B'],0),
    }
    return cases

def deterministic_dataset_hash(seed):
    r=random.Random(seed)
    records=[]
    for i in range(32):
        n=r.randint(0,12)
        tokens=[r.choice(['a','b','c','d']) for _ in range(n)]
        steps=r.randint(0,20)
        records.append({'id':f'DEV-{i:03}', 'tokens':tokens,'steps':steps,
                        'target':symbolic(tokens,[{'op':'reverse'},{'op':'rotate_left','steps':steps}])})
    return sha(canon(records))

def first():
    WORK.mkdir(parents=True,exist_ok=True)
    result=test_cases()
    if not all(result.values()): raise RuntimeError('Task smoke fixture failed')
    appended=append_once('E0001','dev_fixture_smoke',{'checks':result,'passed':len(result)})
    if not appended: raise RuntimeError('Existing F0 E0001; use a clean working directory')
    # Deliberately leave checkpoint one event behind to simulate interruption.
    atomic_json(CHECKPOINT,{'run_id':'ACE-F0-20261104', 'last_event_id':None,
                            'phase':'INTERRUPTED_SIMULATED', 'updated_at_utc':utc_now()})
    print(canon({'phase':'first','fixture_checks':len(result),'passed':sum(result.values()),'simulated_interruption':True}))

def resume():
    before=load_events()
    if len(before)!=1 or not validate_chain(before): raise RuntimeError('Unexpected ledger at resume start')
    # Recover from ledger, not stale checkpoint, ensuring E0001 not rerun.
    already=append_once('E0001','dev_fixture_smoke',{'unexpected':'duplicate'})
    reproducible=deterministic_dataset_hash(SEED)==deterministic_dataset_hash(SEED)
    varied=deterministic_dataset_hash(SEED)!=deterministic_dataset_hash(SEED+1)
    append_once('E0002','repeatability',{'same_seed_equal':reproducible,'different_seed_distinct':varied,
                                         'dev_records':32, 'dataset_sha256':deterministic_dataset_hash(SEED)})
    timed_out=False
    try:
        subprocess.run([sys.executable,'-c','import time; time.sleep(2)'], timeout=0.08,
                       check=True, capture_output=True, text=True)
    except subprocess.TimeoutExpired:
        timed_out=True
    append_once('E0003','resource_timeout',{'bounded_subprocess_timeout':timed_out})
    ledger=load_events()
    tampered=[dict(e) for e in ledger]
    tampered[0]['outcome']={'altered':True}
    chain_untampered=validate_chain(ledger)
    tamper_detected=not validate_chain(tampered)
    append_once('E0004','ledger_integrity',{'original_chain_valid':chain_untampered,'tamper_detected':tamper_detected})
    events=load_events()
    atomic_json(CHECKPOINT, {'run_id':'ACE-F0-20261104','last_event_id':events[-1]['event_id'],
                             'last_event_sha256':events[-1]['entry_hash'],
                             'events_count':len(events), 'phase':'RECOVERED_COMPLETE',
                             'updated_at_utc':utc_now()})
    report={'schema_version':'ACE-F0-EVIDENCE-0.1',
            'probe_date_utc':utc_now(), 'run_id':'ACE-F0-20261104',
            'runtime':{'python':platform.python_version(),'platform':platform.system(),
                       'cpu_visible':os.cpu_count(),'disk_free_mb':round(shutil.disk_usage(WORK).free/1024**2,1),
                       'stdlib_only':True, 'execution_scope':'ChatGPT session container (not user-owned persistence)'},
            'checks':{
                 'small_task_oracles':{'status':'PASS','count':len(test_cases())},
                 'deterministic_generation':{'status':'PASS' if reproducible and varied else 'FAIL', 'count':32},
                 'atomic_checkpoint_write':{'status':'PASS' if CHECKPOINT.exists() else 'FAIL'},
                 'recover_after_interruption':{'status':'PASS' if not already and len(events)==4 else 'FAIL', 'event_count':len(events)},
                 'detect_history_tampering':{'status':'PASS' if chain_untampered and tamper_detected else 'FAIL'},
                 'subprocess_timeout':{'status':'PASS' if timed_out else 'FAIL'}},
            'outside_scope':{
                 'api_keys_or_provider_api':'NOT_CHECKED', 'cloud_quotas_on_user_accounts':'NOT_CHECKED',
                 'Colab_or_Kaggle_login':'NOT_CHECKED', 'GitHub_repo_execution':'NOT_CHECKED',
                 'untrusted_generated_code_sandbox':'NOT_PROVEN',
                 'permanent_background_execution':'NOT_AVAILABLE_IN_SESSION',
                 'ACE_A_B_C_real_agent_runs':'NOT_RUN',
                 'F1_acceptance_F1_T01_to_T12':'NOT_RUN'},
            'additional_user_spend_idr':0,
            'note':'Local test of F0 capabilities only. No proof of agent learning or evolution.'}
    if not all(c['status']=='PASS' for c in report['checks'].values()): raise AssertionError('A probe failed')
    atomic_json(ROOT/'evidence.json', report)
    print(canon({'phase':'resume','events':len(events),'checks':report['checks'],
                 'additional_spend_idr':0}))

def verify():
    evidence=json.loads((ROOT/'evidence.json').read_text(encoding='utf-8'))
    events=load_events()
    cp=json.loads(CHECKPOINT.read_text(encoding='utf-8'))
    assert len(events)==4 and validate_chain(events)
    assert cp['last_event_sha256']==events[-1]['entry_hash']
    assert cp['events_count']==len(events)
    assert all(c['status']=='PASS' for c in evidence['checks'].values())
    print(canon({'status':'PASS','event_count':len(events),'evidence_sha256':sha((ROOT/'evidence.json').read_bytes()),
                 'latest_event_hash':events[-1]['entry_hash']}))

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('phase',choices=['first','resume','verify'])
    ns=parser.parse_args()
    {'first':first,'resume':resume,'verify':verify}[ns.phase]()
