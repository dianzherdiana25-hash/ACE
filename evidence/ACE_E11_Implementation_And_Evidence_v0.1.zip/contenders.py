"""Four algorithms. No oracle import; consume only demos and a bounded executor."""
import random
from dataclasses import dataclass

ATOMS=('rev','rol','ror','swap','pairs','inc','dec','mul2','alt','neg','neighbor','spread')
SEARCH_BUDGET=256

@dataclass
class Result:
    policy: str
    selected: tuple
    demo_exact: int
    demo_element: int
    evaluations: int
    hit_training_exact: bool
    proposal_digest: str
    initial_digest: str
    first_perfect_at: int|None

def evaluate(p,demos,executor):
    exact=elements=0
    for x,y in demos:
        pred=executor(p,x)
        exact+=int(pred==y)
        elements+=sum(a==b for a,b in zip(pred,y))
    return (exact,elements)

def random_p(rng): return tuple(rng.choice(ATOMS) for _ in range(4))

def mutate(p,rng):
    q=list(p)
    for idx in rng.sample(range(4), 1 if rng.random()<0.8 else 2):
        options=[a for a in ATOMS if a!=q[idx]]
        q[idx]=rng.choice(options)
    return tuple(q)

def search(policy, demos, executor, rngseed, budget=SEARCH_BUDGET):
    import hashlib
    rng=random.Random(rngseed)
    rank_rng=random.Random(str(rngseed)+'-sham-ranks')
    seen=set(); history=[]; best=None; bestkey=(-1,-1); archive=[]; first_perfect=None
    probe_count=0
    for step in range(budget):
        if policy=='RANDOM': proposal=random_p(rng)
        elif policy=='SHAM_EVOLVE':
            proposal=random_p(rng) if step<24 or not archive else mutate(rng.choice(archive)[0],rng)
        elif policy=='EVOLVE':
            if step<24 or not archive or rng.random()<0.10: proposal=random_p(rng)
            else:
                base=rng.choice(archive[:min(6,len(archive))])[0]
                proposal=mutate(base,rng)
        elif policy=='BEAM':
            if step<24 or not archive or rng.random()<0.12: proposal=random_p(rng)
            else:
                base=archive[(step//13)%min(5,len(archive))][0]
                proposal=mutate(base,rng)
        else:raise ValueError(policy)
        # Repeat proposals are charged as attempts: no free retries.
        score=evaluate(proposal,demos,executor)
        probe_count+=1
        history.append(proposal)
        if score>bestkey: bestkey=score;best=proposal
        if first_perfect is None and score[0]==len(demos): first_perfect=step+1
        if policy=='SHAM_EVOLVE':
            rank=rank_rng.random() # no true feedback used in exploration
        else:
            rank=score[0]*1000+score[1]
        # Archive is a policy-private parent population, not final selection.
        archive.append((proposal,rank))
        archive.sort(key=lambda x: x[1],reverse=True)
        archive=archive[:10]
    assert probe_count==budget
    digest=hashlib.sha256(repr(history).encode()).hexdigest()
    return Result(policy,best,bestkey[0],bestkey[1],probe_count,bestkey[0]==len(demos),digest,hashlib.sha256(repr(history[:24]).encode()).hexdigest(),first_perfect)
