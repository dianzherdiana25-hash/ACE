"""Second, independently authored DSL interpreter for post-run audit."""
MOD=11

def interpret(program,source):
    d=list(source)
    for op in program:
        n=len(d)
        if op=='rev':
            d=list(reversed(d))
        elif op=='rol':
            d=[d[(i+1)%n] for i in range(n)]
        elif op=='ror':
            d=[d[(i-1)%n] for i in range(n)]
        elif op=='swap':
            nd=d.copy();nd[0]=d[-1];nd[-1]=d[0];d=nd
        elif op=='pairs':
            nd=d.copy()
            for i in range(n):nd[i]=d[i+1] if i%2==0 and i+1<n else (d[i-1] if i%2==1 else d[i])
            d=nd
        elif op=='inc':d=[(v+1)%MOD for v in d]
        elif op=='dec':d=[(v+MOD-1)%MOD for v in d]
        elif op=='mul2':d=[(v*2)%MOD for v in d]
        elif op=='alt':d=[(v+i%2)%MOD for i,v in enumerate(d)]
        elif op=='neg':d=[(MOD-v)%MOD for v in d]
        elif op=='neighbor':d=[(d[i]+d[(i-1)%n])%MOD for i in range(n)]
        elif op=='spread':d=[(v+i)%MOD for i,v in enumerate(d)]
        else:raise ValueError(op)
    return tuple(d)
