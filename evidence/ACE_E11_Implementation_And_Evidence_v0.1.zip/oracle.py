"""Evaluator only. Candidate policies must not import this module or inspect target programs."""
from __future__ import annotations
import hashlib, random
from dataclasses import dataclass
from itertools import product

ATOMS=('rev','rol','ror','swap','pairs','inc','dec','mul2','alt','neg','neighbor','spread')
MOD=11

def apply_atom(atom, data):
    x=list(data); n=len(x)
    if atom=='rev': y=x[::-1]
    elif atom=='rol': y=x[1:]+x[:1]
    elif atom=='ror': y=x[-1:]+x[:-1]
    elif atom=='swap':
        y=x[:]; y[0], y[-1]=y[-1], y[0]
    elif atom=='pairs':
        y=x[:]
        for k in range(0,n-1,2): y[k], y[k+1]=y[k+1], y[k]
    elif atom=='inc': y=[(z+1)%MOD for z in x]
    elif atom=='dec': y=[(z-1)%MOD for z in x]
    elif atom=='mul2': y=[2*z%MOD for z in x]
    elif atom=='alt': y=[(z+k%2)%MOD for k,z in enumerate(x)]
    elif atom=='neg': y=[-z%MOD for z in x]
    elif atom=='neighbor': y=[(x[k]+x[(k-1)%n])%MOD for k in range(n)]
    elif atom=='spread': y=[(z+k)%MOD for k,z in enumerate(x)]
    else: raise ValueError('Unknown operation')
    return tuple(y)

def apply_program(p,x):
    if len(p)!=4 or any(a not in ATOMS for a in p): raise ValueError('Only 4-token DSL programs accepted')
    for a in p: x=apply_atom(a,x)
    return tuple(x)

def deterministic_rng(*vals):
    v=hashlib.sha256('ACE-E1.1::'.join(map(str,vals)).encode()).digest()
    return random.Random(int.from_bytes(v[:16],'big'))

def cases(seed, variant, split, n, size):
    r=deterministic_rng(seed,variant,split,size)
    xs=set()
    while len(xs)<n: xs.add(tuple(r.randrange(MOD) for _ in range(size)))
    return tuple(sorted(xs))

REFERENCE=tuple(tuple((i*j+j*j)%MOD for j in range(1,9)) for i in range(1,9))
SHORT_SIGNATURES=None

def short_signatures():
    global SHORT_SIGNATURES
    if SHORT_SIGNATURES is None:
        seqs=((a,) for a in ATOMS)
        sigs=set()
        for p in list(seqs)+list(product(ATOMS,repeat=2)):
            sigs.add(tuple(_run_general(p,x) for x in REFERENCE))
        SHORT_SIGNATURES=sigs
    return SHORT_SIGNATURES

def _run_general(p,x):
    for a in p:x=apply_atom(a,x)
    return tuple(x)

@dataclass(frozen=True)
class Task:
    task_id: str
    demos: tuple
    hidden9: tuple
    hidden13: tuple
    truth: tuple
    source_motif: tuple

def make_task(seed,variant):
    r=deterministic_rng('truth',seed,variant)
    # All methods see same demonstrative I/O; target's 4-atom motif is not a source motif.
    source=tuple(r.choice(ATOMS) for _ in range(3))
    demos_inputs=cases(seed,variant,'demo',4,6)
    h9=cases(seed,variant,'hidden9',10,9)
    h13=cases(seed,variant,'hidden13',10,13)
    short=short_signatures()
    for attempt in range(12000):
        p=tuple(r.choice(ATOMS) for _ in range(4))
        if not any(a in p for a in ('neighbor','spread','alt')):continue
        if source in (p[:3],p[1:]):continue
        sig=tuple(_run_general(p,x) for x in REFERENCE)
        if sig in short: continue
        # Prevent trivial ambiguity: distinct demo outputs from identity and short ops
        demo_signature=tuple(_run_general(p,x) for x in demos_inputs)
        if all(y==x for x,y in zip(demos_inputs,demo_signature)):continue
        return Task(f'novel-{seed}-{variant}',tuple((x,apply_program(p,x)) for x in demos_inputs),
                    tuple((x,apply_program(p,x)) for x in h9),
                    tuple((x,apply_program(p,x)) for x in h13), p, source)
    raise RuntimeError('No task')
