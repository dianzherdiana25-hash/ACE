"""Independent post-hoc audit; never used to select candidate policies."""
import argparse,hashlib,json,collections
from pathlib import Path
from independent_eval import interpret
from oracle import make_task,apply_program
from contenders import search

def sha(o):return hashlib.sha256(json.dumps(o,sort_keys=True,separators=(',',':')).encode()).hexdigest()

def audit(folder,seed_start,num_seeds,lock=None):
    folder=Path(folder)
    if lock is not None:
        lockdata=json.loads(Path(lock).read_text())
        for name,h in lockdata['sha256'].items():
            actual=hashlib.sha256((Path(lock).parent/name).read_bytes()).hexdigest()
            assert actual==h,(name,'lock mismatch')
    rows=[json.loads(line) for line in (folder/'run_results.jsonl').read_text().splitlines() if line]
    assert len(rows)==num_seeds*2*4
    prev='0'*64
    family=collections.defaultdict(list)
    for row in rows:
        assert row['previous_hash']==prev
        actual=sha({k:v for k,v in row.items() if k!='hash'})
        assert actual==row['hash']
        prev=actual
        assert row['evaluations']==256 and row['primitive_calls']==4096
        task=make_task(row['seed'],row['variant'])
        assert task.task_id==row['task_id']
        assert tuple(row['task_truth_for_posthoc_audit_only'])==task.truth
        assert tuple(row['source_motif_for_posthoc_audit_only'])==task.source_motif
        rerun=search(row['policy'],task.demos,apply_program,f"{row['seed']}-{row['variant']}-shared-init")
        assert list(rerun.selected)==row['selected']
        assert rerun.proposal_digest==row['proposal_digest'] and rerun.initial_digest==row['initial_digest']
        assert rerun.demo_exact==row['demo_exact'] and rerun.demo_element==row['demo_element']
        for k,truth in [('len9',task.hidden9),('len13',task.hidden13)]:
            hits=[]
            for x,y in truth:
                assert interpret(task.truth,x)==y
                assert interpret(row['selected'],x)==apply_program(row['selected'],x)
                hits.append(int(interpret(row['selected'],x)==y))
            assert hits==row['reference_hidden'][k]
            assert sum(hits)==row['scores'][k]
        family[(row['seed'],row['variant'])].append(row)
    for taskid,rr in family.items():
        assert set(r['policy'] for r in rr)=={'RANDOM','SHAM_EVOLVE','EVOLVE','BEAM'}
        assert len(set(r['initial_digest'] for r in rr))==1
    summary=json.loads((folder/'summary.json').read_text())
    assert summary['rows']==len(rows) and summary['last_hash']==prev
    for policy,d in summary['by_policy'].items():
        rr=[r for r in rows if r['policy']==policy]
        assert d['len9']==sum(r['scores']['len9'] for r in rr)
        assert d['len13']==sum(r['scores']['len13'] for r in rr)
        assert d['demo_full_fit']==sum(r['hit_training_exact'] for r in rr)
        assert d['task_all_hidden_len9']==sum(r['scores']['len9']==10 for r in rr)
    result={'audit':'PASS','runs':len(rows),'tasks':len(family),'predictions_rechecked':len(rows)*20,'final_hash':prev,'same_initial_candidates_all_tasks':True}
    (folder/'audit_summary.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--folder',required=True);p.add_argument('--seed-start',type=int,required=True);p.add_argument('--num-seeds',type=int,required=True);p.add_argument('--lock');a=p.parse_args();audit(a.folder,a.seed_start,a.num_seeds,a.lock)
