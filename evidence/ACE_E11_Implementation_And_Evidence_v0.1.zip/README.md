# ACE E1.1 — Independent Method Discovery Challenge

Paket eksperimen lokal/Google Colab. Tidak menggunakan API, GPU, atau koneksi internet untuk menjalankan kode inti.

## Jalankan ulang

```bash
python -m unittest -q test_e11
python run_e11.py --out rerun_confirmation --seed-start 9301 --num-seeds 24
python audit_e11.py --folder rerun_confirmation --seed-start 9301 --num-seeds 24 --lock preconfirm_lock.json
```

Hasil `rerun_confirmation/summary.json` harus sama dengan `confirmation/summary.json`, dan hash akhir harus sama. `posthoc_analysis.py` menghitung interval ketidakpastian dari data tersimpan (tidak dipakai memilih kebijakan). Gunakan notebook `ACE_E11_Colab_Replication_v0.1.ipynb` untuk reproduksi via HP.

**Penting:** Sistem ini hanya menyintesis urutan operasi dari DSL terbatas menggunakan metode pencarian buatan peneliti. Tidak membuktikan penemuan primitive baru, kecerdasan umum, atau self-improvement terbuka. Evaluator kedua independen dalam implementasi kode, bukan penilai eksternal pihak ketiga.
