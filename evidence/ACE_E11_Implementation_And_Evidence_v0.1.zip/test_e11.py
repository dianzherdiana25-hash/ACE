import unittest
from oracle import apply_program,ATOMS,make_task,apply_atom
from contenders import evaluate,search
class TestE11(unittest.TestCase):
    def test_atom_is_nonempty(self):
        for a in ATOMS: self.assertEqual(len(apply_atom(a,(1,2,3,4,5,6))),6)
    def test_program_has_only_four_atoms(self):
        with self.assertRaises(ValueError):apply_program(('rev',),(1,2))
    def test_task_determinism(self): self.assertEqual(make_task(1201,0),make_task(1201,0))
    def test_task_distinct_seeds(self):self.assertNotEqual(make_task(1201,0).truth,make_task(1202,0).truth)
    def test_train_hidden_lengths(self):
        t=make_task(1201,0); self.assertEqual([len(x) for x,y in t.demos],[6]*4); self.assertEqual([len(x) for x,y in t.hidden9],[9]*10); self.assertEqual([len(x) for x,y in t.hidden13],[13]*10)
    def test_truth_fits_demos(self):
        t=make_task(1201,0);self.assertEqual(evaluate(t.truth,t.demos,apply_program),(4,24))
    def test_budget(self):
        t=make_task(1201,0)
        for p in ['RANDOM','SHAM_EVOLVE','EVOLVE','BEAM']:
            self.assertEqual(search(p,t.demos,apply_program,1,budget=32).evaluations,32)
    def test_deterministic_policy(self):
        t=make_task(1201,0)
        self.assertEqual(search('EVOLVE',t.demos,apply_program,2,budget=48),search('EVOLVE',t.demos,apply_program,2,budget=48))
    def test_second_interpreter(self):
        from independent_eval import interpret
        x=(3,1,4,1,5,9)
        for a in ATOMS:self.assertEqual(interpret((a,a,a,a),x),apply_program((a,a,a,a),x))
    def test_true_feedback_changes_trajectory(self):
        t=make_task(1201,0)
        r=search('EVOLVE',t.demos,apply_program,3,budget=64);s=search('SHAM_EVOLVE',t.demos,apply_program,3,budget=64)
        self.assertNotEqual(r.proposal_digest,s.proposal_digest)
    def test_same_initial_candidates(self):
        t=make_task(1201,0)
        hashes=[search(p,t.demos,apply_program,'shared',budget=48).initial_digest for p in ('RANDOM','SHAM_EVOLVE','EVOLVE','BEAM')]
        self.assertEqual(len(set(hashes)),1)
    def test_no_target_truth_in_contender_api(self):
        t=make_task(1201,0); self.assertFalse(hasattr(t.demos,'truth'))
if __name__=='__main__':unittest.main()
