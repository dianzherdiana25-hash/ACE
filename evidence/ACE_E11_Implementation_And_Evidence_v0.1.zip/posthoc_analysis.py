"""Post-confirmation statistical analysis. Not used to select or tune policies."""
import json,random,statistics
from pathlib import Path
from collections import defaultdict

folder=Path('confirmation')
rows=[json.loads(x) for x in (folder/'run_results.jsonl').read_text().splitlines() if x]
policies=['RANDOM','SHAM_EVOLVE','EVOLVE','BEAM']
byseed=defaultdict(lambda:defaultdict(lambda:{'len9':0,'len13':0}))
byvar=defaultdict(lambda:defaultdict(lambda:{'len9':0,'len13':0}))
for r in rows:
    for k in ('len9','len13'):
        byseed[r['seed']][r['policy']][k]+=r['scores'][k]
        byvar[r['variant']][r['policy']][k]+=r['scores'][k]
seeds=sorted(byseed)
assert len(seeds)==24
r=random.Random(54321)
results={}
for other in ['RANDOM','SHAM_EVOLVE','BEAM']:
    diffs=[byseed[s]['EVOLVE']['len9']-byseed[s][other]['len9'] for s in seeds]
    observed=sum(diffs)/(24*2*10)
    bootstrap=[]
    for _ in range(12000):
        sampled=[r.choice(diffs) for _ in seeds]
        bootstrap.append(sum(sampled)/(24*2*10))
    bootstrap.sort()
    ci=[bootstrap[round(.025*(len(bootstrap)-1))],bootstrap[round(.975*(len(bootstrap)-1))]]
    results[f'EVOLVE_minus_{other}']={'percentage_point_difference':100*observed,'bootstrap_95_CI_pp':[100*c for c in ci],
        'seed_cluster_positive':sum(x>0 for x in diffs),'zero':sum(x==0 for x in diffs),'negative':sum(x<0 for x in diffs)}

overall={'n_seed_clusters':len(seeds),'n_tasks':len(seeds)*2,'n_predictions_per_policy_split':len(seeds)*2*10,
         'policies':{p:{k:sum(byseed[s][p][k] for s in seeds) for k in ['len9','len13']} for p in policies},
         'paired_effects':results,'variant_totals':{str(v):{p:dict(stats) for p,stats in d.items()} for v,d in byvar.items()},
         'analysis_description':'Cluster bootstrap 12,000 replicates, resampling 24 seed clusters (2 tasks each), predefined metric len9; exploratory CI.'}
Path('confirmation/posthoc_analysis.json').write_text(json.dumps(overall,indent=2)+'\n')
print(json.dumps(overall,indent=2))
