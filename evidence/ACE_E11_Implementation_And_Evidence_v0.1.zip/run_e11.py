import argparse,hashlib,json,time,os
from pathlib import Path
from dataclasses import asdict
from oracle import make_task,apply_program
from contenders import search,SEARCH_BUDGET

POLICIES=('RANDOM','SHAM_EVOLVE','EVOLVE','BEAM')

def sha(obj):return hashlib.sha256(json.dumps(obj,sort_keys=True,separators=(',',':')).encode()).hexdigest()

def run(out,seed_start,num_seeds):
    out=Path(out); out.mkdir(parents=True,exist_ok=True)
    prior='0'*64
    rows=[]
    with (out/'run_results.jsonl').open('w') as outstream:
        for seed in range(seed_start,seed_start+num_seeds):
            for variant in range(2):
                task=make_task(seed,variant)
                for policy in POLICIES:
                    r=search(policy,task.demos,apply_program,f'{seed}-{variant}-shared-init')
                    h9=[int(apply_program(r.selected,x)==y) for x,y in task.hidden9]
                    h13=[int(apply_program(r.selected,x)==y) for x,y in task.hidden13]
                    row={'seed':seed,'variant':variant,'policy':policy,'task_id':task.task_id,
                         'selected':r.selected,'demo_exact':r.demo_exact,'demo_element':r.demo_element,
                         'scores':{'len9':sum(h9),'len13':sum(h13)},'n_hidden':{'len9':10,'len13':10},
                         'hit_training_exact':r.hit_training_exact,'first_perfect_at':r.first_perfect_at,
                         'proposal_digest':r.proposal_digest,'initial_digest':r.initial_digest,'evaluations':r.evaluations,
                         'primitive_calls':r.evaluations*4*4,
                         'reference_hidden':{'len9':h9,'len13':h13},
                         'task_truth_for_posthoc_audit_only':task.truth,
                         'source_motif_for_posthoc_audit_only':task.source_motif}
                    row['previous_hash']=prior
                    row['hash']=sha(row)
                    prior=row['hash'];rows.append(row);outstream.write(json.dumps(row,sort_keys=True)+'\n')
    summary={'rows':len(rows),'tasks':num_seeds*2,'primitive_calls_per_policy_task':4096,
             'by_policy':{p:{'len9':sum(r['scores']['len9'] for r in rows if r['policy']==p),
                            'len13':sum(r['scores']['len13'] for r in rows if r['policy']==p),
                            'demo_full_fit':sum(r['hit_training_exact'] for r in rows if r['policy']==p),
                            'task_all_hidden_len9':sum(r['scores']['len9']==10 for r in rows if r['policy']==p)} for p in POLICIES},
             'last_hash':prior}
    (out/'summary.json').write_text(json.dumps(summary,indent=2))
    print(json.dumps(summary,indent=2))

if __name__=='__main__':
    a=argparse.ArgumentParser(); a.add_argument('--out',required=True);a.add_argument('--seed-start',type=int,default=1201);a.add_argument('--num-seeds',type=int,default=8);args=a.parse_args();run(args.out,args.seed_start,args.num_seeds)
