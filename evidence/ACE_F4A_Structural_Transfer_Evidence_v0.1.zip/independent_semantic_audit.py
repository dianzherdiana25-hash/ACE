"""Independent post-freeze JSON-normalized semantic audit of F4a results.
Preserves the frozen runner (which compares tuples to JSON lists directly).
"""
from pathlib import Path
import sys,json,hashlib
P=Path(__file__).resolve().parent
sys.path.insert(0,str(P/'source'))
import f4_runner as f
import ace_f33_frozen as a
manifest=json.loads((P/'F4A_PRE_REGISTRATION.json').read_text())
assert f.filehash(P/'F4A_PRE_REGISTRATION.json')==(P/'F4A_PRE_REGISTRATION_SHA256.txt').read_text().strip()
assert f.filehash(P/'source/ace_f33_frozen.py')==manifest['frozen_f33_policy_sha256']
assert f.filehash(P/'source/f4_runner.py')==manifest['f4_runner_sha256']
assert f.filehash(P/'source/test_f4.py')==manifest['f4_qa_tests_sha256']
events=[json.loads(x) for x in (P/'results/events.jsonl').read_text().splitlines()]
order=[(seed,shift,fam,arm) for seed in manifest['seeds'] for shift in manifest['shifts'] for fam in manifest['families'] for arm in manifest['policies']]
assert len(events)==len(order)
head='0'*64; total=0;macros=0
for i, ((seed,shift,fam,arm), ev) in enumerate(zip(order,events)):
    assert ev['i']==i and ev['prev']==head and ev['hash']==a.sha({k:v for k,v in ev.items() if k!='hash'})
    rec=ev['record']
    calculated=json.loads(f.canonical(f.experiment(seed,fam,shift,arm)))
    assert calculated==rec, f'Semantic mismatch at {i}'
    assert rec['total']==120
    total+=rec['total'];macros+=rec['macro_count']
    head=ev['hash']
assert head==json.loads((P/'results/summary.json').read_text())['hash_head']
status={'full_semantic_replay':'PASS','runs':len(events),'evaluated_instances_across_all_arms':total,'macro_library_items_across_macro_arms':macros,'event_head':head,'frozen_runner_known_bug':'Built-in --semantic compares native Python tuple against JSON list; independent audit round-trips to canonical JSON before equality. Research source unchanged.','pre_reg_sha256':f.filehash(P/'F4A_PRE_REGISTRATION.json')}
(P/'results/F4A_INDEPENDENT_SEMANTIC_AUDIT.json').write_text(json.dumps(status,indent=2,ensure_ascii=False)+'\n')
print(json.dumps(status,ensure_ascii=False))
