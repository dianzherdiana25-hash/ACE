import pathlib,tempfile,unittest
from unittest.mock import patch
import f4_runner as f
import ace_f33_frozen as a

class F4Tests(unittest.TestCase):
 def test_target_independent(self):
  self.assertNotEqual(f.target(301,'S',0,'INDEPENDENT'),f.target(301,'S',1,'INDEPENDENT'))
 def test_target_alternating(self):
  self.assertEqual(f.target(301,'G',0,'ALTERNATING')[:2],f.target(301,'G',2,'ALTERNATING')[:2])
 def test_target_suffix(self):
  self.assertEqual(f.target(301,'S',1,'SUFFIX_MOTIF')[-2:],f.target(301,'S',4,'SUFFIX_MOTIF')[-2:])
 def test_length(self):
  for shift in f.SHIFTS:
   for fam in f.FAMILIES:
    self.assertEqual([len(f.target(71,fam,i,shift)) for i in range(6)],[3,3,4,4,4,4])
 def test_frozen_search_reused(self):
  self.assertEqual(a.search_task.__module__,'ace_f33_frozen')
 def test_target_reset(self):
  orig=a.make_target
  with f.shifted_target('INDEPENDENT'):
   self.assertNotEqual(a.make_target,orig)
  self.assertEqual(a.make_target,orig)
 def test_final_score_cannot_change_candidate_search(self):
  original=a.grade
  baseline=f.experiment(71,'S','INDEPENDENT','GUIDED_MACRO')
  def tamper_final_only(fam,cand,probes):
   return 0.0 if len(probes)==20 else original(fam,cand,probes)
  with patch.object(a,'grade',tamper_final_only):
   changed=f.experiment(71,'S','INDEPENDENT','GUIDED_MACRO')
  self.assertEqual([(t['best_program'],t['candidate_trace_hash'],t['macros_added']) for t in baseline['tasks']],
                   [(t['best_program'],t['candidate_trace_hash'],t['macros_added']) for t in changed['tasks']])
 def test_seed_separation(self):
  self.assertFalse(set(f.SEEDS)&set(a.CONFIRM_SEEDS))
  self.assertFalse(set(f.SEEDS)&set(a.DEV_SEEDS))
 def test_paired_task_and_first_proposals(self):
  a1=f.experiment(71,'G','ALTERNATING','GUIDED_MACRO')
  a2=f.experiment(71,'G','ALTERNATING','GUIDED_NO_MACRO')
  self.assertEqual([t['target_hash'] for t in a1['tasks']],[t['target_hash'] for t in a2['tasks']])
  self.assertEqual([t['first_two'] for t in a1['tasks']],[t['first_two'] for t in a2['tasks']])
 def test_run_is_deterministic(self):
  self.assertEqual(f.experiment(71,'S','SUFFIX_MOTIF','BLIND_MACRO'),f.experiment(71,'S','SUFFIX_MOTIF','BLIND_MACRO'))
if __name__=='__main__':unittest.main(verbosity=2)
