"""ACE F4a structural transfer test.
Frozen F3.3b policy, external target grammar intervention; no target outputs
passed to candidate proposer beyond a fixed five-example training probe.
This is not an independently administered or cryptographically isolated test.
"""
from __future__ import annotations
import contextlib, hashlib, json, random, sys
from pathlib import Path

import ace_f33_frozen as a

SHIFTS=('INDEPENDENT','ALTERNATING','SUFFIX_MOTIF')
ARMS=a.ARMS
FAMILIES=a.FAMILIES
SEEDS=tuple(4800011+4243*i for i in range(16))


def target(seed:int, fam:str, task:int, shift:str):
    ops=a.primitives(fam)
    if shift=='INDEPENDENT':
        r=a.rng('ACEF4',shift,seed,fam,task,'independent')
        return tuple(r.choice(ops) for _ in range(3 if task<2 else 4))
    if shift=='ALTERNATING':
        r=a.rng('ACEF4',shift,seed,fam,'motif',task%2)
        motif=tuple(r.choice(ops) for _ in range(2))
        s=a.rng('ACEF4',shift,seed,fam,task,'suffix')
        return motif+tuple(s.choice(ops) for _ in range(1 if task<2 else 2))
    if shift=='SUFFIX_MOTIF':
        r=a.rng('ACEF4',shift,seed,fam,'motif')
        motif=tuple(r.choice(ops) for _ in range(2))
        s=a.rng('ACEF4',shift,seed,fam,task,'prefix')
        return tuple(s.choice(ops) for _ in range(1 if task<2 else 2))+motif
    raise ValueError('Unknown shift')


@contextlib.contextmanager
def shifted_target(shift):
    # Patch only the benchmark's hidden target producer, not the F3.3b search policy.
    old=a.make_target
    def replacement(seed,fam,task):
        return target(seed,fam,task,shift)
    a.make_target=replacement
    try:
        yield
    finally:
        a.make_target=old


def experiment(seed,fam,shift,arm):
    library={};records=[]
    with shifted_target(shift):
        for task in range(a.TASKS_PER_SEED):
            r,library=a.search_task(seed,fam,task,arm,library)
            # Store a bounded audit trace; final predictions are computed by
            # a frozen solver and never used for updating its candidate library.
            records.append({
                'task':task,'target_hash':a.sha(r['target_audit_only']),
                'best_program':r['best_program'],
                'best_probe_score':r['best_probe_score'],
                'best_index':r['best_index'],
                'final_exact':r['final_exact'],'final_total':r['final_total'],
                'candidate_count':r['candidate_count'],
                'macros_before':len(r['macro_before']),
                'macros_added':r['macros_added'],
                'macros_after':len(r['macro_after']),
                'macro_used_candidates':sum(c['uses_macro'] for c in r['candidate_trace']),
                'first_two':tuple(c['expanded'] for c in r['candidate_trace'][:2]),
                'candidate_trace_hash':a.sha(r['candidate_trace']),
                'final_manifest_sha256':r['final_manifest_sha256'],
            })
    return {
        'seed':seed,'family':fam,'shift':shift,'policy':arm,
        'exact':sum(t['final_exact'] for t in records),
        'total':sum(t['final_total'] for t in records),
        'macro_count':len(library),
        'macro_usage':sum(t['macro_used_candidates'] for t in records),
        'tasks':records,
    }


def canonical(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False)

def filehash(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def produce(root, prereg_path):
    root=Path(root);root.mkdir(parents=True,exist_ok=True)
    prereg=json.loads(Path(prereg_path).read_text())
    assert tuple(prereg['shifts'])==SHIFTS and tuple(prereg['seeds'])==SEEDS
    assert tuple(prereg['policies'])==ARMS and tuple(prereg['families'])==FAMILIES
    assert prereg['frozen_f33_policy_sha256']==filehash(Path(__file__).with_name('ace_f33_frozen.py'))
    assert prereg['f4_runner_sha256']==filehash(__file__)
    paths=[(seed,shift,fam,arm) for seed in SEEDS for shift in SHIFTS for fam in FAMILIES for arm in ARMS]
    output=root/'events.jsonl';head='0'*64
    if output.exists():
        raise ValueError('Evaluation already exists; refusing second look')
    aggregates={arm:{shift:{fam:{'exact':0,'total':0,'macros':0,'macro_usage':0,'runs':0} for fam in FAMILIES} for shift in SHIFTS} for arm in ARMS}
    with output.open('w',encoding='utf-8') as f:
        for index,(seed,shift,fam,arm) in enumerate(paths):
            rec=experiment(seed,fam,shift,arm)
            event={'i':index,'prev':head,'record':rec}
            event['hash']=a.sha(event)
            head=event['hash']
            f.write(canonical(event)+'\n')
            s=aggregates[arm][shift][fam];s['exact']+=rec['exact'];s['total']+=rec['total'];s['macros']+=rec['macro_count'];s['macro_usage']+=rec['macro_usage'];s['runs']+=1
            if index%48==47:
                print('F4_PROGRESS',index+1,'/',len(paths),flush=True)
    summary={'runs':len(paths),'hash_head':head,'aggregates':aggregates,'prereg_sha256':filehash(prereg_path),'frozen_f33_policy_sha256':prereg['frozen_f33_policy_sha256'],'f4_runner_sha256':prereg['f4_runner_sha256']}
    (root/'summary.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False)+'\n')
    return summary


def audit(root,prereg_path,semantic=False):
    root=Path(root)
    prereg=json.loads(Path(prereg_path).read_text())
    assert prereg['frozen_f33_policy_sha256']==filehash(Path(__file__).with_name('ace_f33_frozen.py'))
    assert prereg['f4_runner_sha256']==filehash(__file__)
    events=[json.loads(x) for x in (root/'events.jsonl').read_text().splitlines()]
    paths=[(seed,shift,fam,arm) for seed in SEEDS for shift in SHIFTS for fam in FAMILIES for arm in ARMS]
    assert len(paths)==len(events)
    head='0'*64
    summary=json.loads((root/'summary.json').read_text())
    recompute={arm:{shift:{fam:{'exact':0,'total':0,'macros':0,'macro_usage':0,'runs':0} for fam in FAMILIES} for shift in SHIFTS} for arm in ARMS}
    for i,ev in enumerate(events):
        seed,shift,fam,arm=paths[i];r=ev['record']
        assert ev['i']==i and ev['prev']==head and ev['hash']==a.sha({k:v for k,v in ev.items() if k!='hash'})
        assert (r['seed'],r['shift'],r['family'],r['policy'])==(seed,shift,fam,arm)
        assert len(r['tasks'])==a.TASKS_PER_SEED
        assert r['exact']==sum(x['final_exact'] for x in r['tasks'])
        assert r['total']==sum(x['final_total'] for x in r['tasks'])
        assert all(x['candidate_count']==a.CANDIDATES_PER_TASK and x['final_total']==a.FINAL_CASES for x in r['tasks'])
        if semantic:
            assert r==experiment(seed,fam,shift,arm)
        s=recompute[arm][shift][fam];s['exact']+=r['exact'];s['total']+=r['total'];s['macros']+=r['macro_count'];s['macro_usage']+=r['macro_usage'];s['runs']+=1
        head=ev['hash']
    assert summary['hash_head']==head and summary['runs']==len(paths) and summary['aggregates']==recompute
    assert summary['prereg_sha256']==filehash(prereg_path)
    return {'valid':True,'semantic_replay':semantic,'runs':len(paths),'head':head}


if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser()
    p.add_argument('action',choices=('run','audit'));p.add_argument('--root',required=True);p.add_argument('--prereg',required=True);p.add_argument('--semantic',action='store_true')
    x=p.parse_args(); print(json.dumps(produce(x.root,x.prereg) if x.action=='run' else audit(x.root,x.prereg,x.semantic),ensure_ascii=False))
