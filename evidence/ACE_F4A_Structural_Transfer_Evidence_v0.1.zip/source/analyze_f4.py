"""Posthoc analysis of preregistered primary contrast and descriptive shifts."""
from pathlib import Path
import json, collections, random, hashlib
import numpy as np

ROOT=Path(__file__).resolve().parents[1]
prereg=json.loads((ROOT/'F4A_PRE_REGISTRATION.json').read_text())
events=[json.loads(x)['record'] for x in (ROOT/'results/events.jsonl').read_text().splitlines()]
seeds=prereg['seeds'];shifts=prereg['shifts'];families=prereg['families'];arms=prereg['policies'];N=len(seeds)
by={(r['seed'],r['shift'],r['family'],r['policy']):r for r in events}
assert len(by)==len(events)==N*len(shifts)*len(families)*len(arms)

def tally(arm,shift=None,family=None):
 v=[r for r in events if r['policy']==arm and (shift is None or r['shift']==shift) and (family is None or r['family']==family)]
 return {'correct':sum(r['exact'] for r in v),'total':sum(r['total'] for r in v),'accuracy':sum(r['exact'] for r in v)/sum(r['total'] for r in v),'runs':len(v),'macro_used_candidate_proposals':sum(r['macro_usage'] for r in v),'macro_stored':sum(r['macro_count'] for r in v)}

def paired(a,b,shift=None,family=None):
 rows=[]
 for seed in seeds:
  z=sum(by[(seed,s,f,a)]['exact']-by[(seed,s,f,b)]['exact'] for s in shifts if shift is None or s==shift for f in families if family is None or f==family)
  tot=sum(by[(seed,s,f,a)]['total'] for s in shifts if shift is None or s==shift for f in families if family is None or f==family)
  rows.append((z,tot))
 r=np.random.default_rng(prereg['bootstrap_seed'])
 idx=r.integers(0,N,size=(prereg['bootstrap_reps'],N))
 d=np.array([z for z,n in rows]);t=np.array([n for z,n in rows]);values=d[idx].sum(axis=1)/t[idx].sum(axis=1)
 dif=d.sum()/t.sum();lo,hi=np.percentile(values,[2.5,97.5]);
 return {'correct_difference':int(d.sum()),'total_per_policy':int(t.sum()),'difference_percentage_points':round(100*float(dif),5),
 'cluster_bootstrap_95ci_percentage_points':[round(100*float(lo),5),round(100*float(hi),5)],'seed_win_tie_loss':[int(sum(d>0)),int(sum(d==0)),int(sum(d<0))],
 'decision':('SUPPORTED_ON_THIS_SYNTHETIC_BENCHMARK' if lo>0 else ('NEGATIVE_ON_THIS_SYNTHETIC_BENCHMARK' if hi<0 else 'INCONCLUSIVE'))}

# Paired labels are identical across arms, and first two candidate proposals are identical
# across the arms (test-time adaptation is allowed by frozen policy).
for seed in seeds:
 for shift in shifts:
  for family in families:
   recs=[by[(seed,shift,family,arm)] for arm in arms]
   for t in range(6):
    assert len({r['tasks'][t]['target_hash'] for r in recs})==1
    assert len({r['tasks'][t]['final_manifest_sha256'] for r in recs})==1
    assert len({json.dumps(r['tasks'][t]['first_two']) for r in recs})==1

out={
 'study':prereg['identifier'],'prereg_sha256':hashlib.sha256((ROOT/'F4A_PRE_REGISTRATION.json').read_bytes()).hexdigest(),
 'n_seeds':N,'n_runs':len(events),
 'arms':{arm:tally(arm) for arm in arms},
 'by_shift':{s:{arm:tally(arm,shift=s) for arm in arms} for s in shifts},
 'by_family':{fam:{arm:tally(arm,family=fam) for arm in arms} for fam in families},
 'primary':paired('GUIDED_MACRO','GUIDED_NO_MACRO'),
 'secondary':{
  'blind_macro_vs_blind_nomacro':paired('BLIND_MACRO','BLIND_NO_MACRO'),
  'guided_macro_vs_blind_macro':paired('GUIDED_MACRO','BLIND_MACRO')},
 'heterogeneity_exploratory':{s:paired('GUIDED_MACRO','GUIDED_NO_MACRO',shift=s) for s in shifts},
 'by_family_difference_exploratory':{fam:paired('GUIDED_MACRO','GUIDED_NO_MACRO',family=fam) for fam in families},
 'correctness_check':{'paired_target_and_final_manifest_equal':True,'first_two_proposals_identical_all_arms':True},
 'limitations':['Synthetic DSL, same operators; no topology change or cross-domain task',
 'Heldout source and evaluator share the same environment; not externally isolated',
 'Agent may use 5 labeled probes of each evaluation task to select candidates; only final instances are hidden',
 'This evaluates frozen search policies, not independently frozen final candidate programs',
 'Search budgets equal per run but time CPU not constrained to equality',
 'No claim of causal macro gain without a positive preregistered primary contrast',
 'Exploratory heterogeneity comparisons are not multiplicity adjusted']}
(ROOT/'results/F4A_ANALYSIS.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'primary':out['primary'],'secondary':out['secondary'],'heterogeneity':out['heterogeneity_exploratory'],'families':out['by_family_difference_exploratory']},ensure_ascii=False,indent=2))
