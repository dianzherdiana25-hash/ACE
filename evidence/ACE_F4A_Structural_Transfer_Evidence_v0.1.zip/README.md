# ACE F4a — Structural transfer (frozen F3.3b policies)

1. `cd source && python -m unittest test_f4 -q` (QA tests)
2. `cd source && python f4_runner.py audit --root ../results --prereg ../F4A_PRE_REGISTRATION.json` (hash + structural audit)
3. `python independent_semantic_audit.py` from project root (full semantic replay with JSON canonicalization).
4. `cd source && python analyze_f4.py` (reproduce summary statistics, regenerates results/F4A_ANALYSIS.json)

For a clean run, make a copy of project source + prereg without results, then:

`cd source && python f4_runner.py run --root ../results --prereg ../F4A_PRE_REGISTRATION.json`

The runner refuses to overwrite existing `events.jsonl`. No dependencies beyond Python 3 + NumPy for bootstrap analysis. No network/API calls. For Colab, use the provided notebook.

Known issue: the frozen `f4_runner.py audit --semantic` compares native tuple representations against lists loaded from JSON, and therefore fails despite semantically equal records. `independent_semantic_audit.py` is the designated full semantic auditor; its output and the original failed attempt are both retained.

This is **F4a internal structural transfer**, not formal F4 or proof of autonomous discovery.
