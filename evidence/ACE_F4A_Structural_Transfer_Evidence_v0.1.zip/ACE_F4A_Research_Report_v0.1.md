# ACE F4a — Pengujian Transfer Struktural Internal v0.1

**Tanggal:** 4 November 2026  
**Status:** `ENGINEERING_PASS / SEMANTIC_REPLAY_PASS / PRIMARY_TRANSFER_ADVANTAGE_INCONCLUSIVE / FULL_F4_NOT_COMPLETE / GENERAL_INTELLIGENCE_NOT_PROVEN`

## 1. Mengapa pengujian ini dilakukan

Studi F3.3b membuktikan pembentukan macro komposisional dan pemakaiannya dalam sistem program kecil, tetapi keunggulan akurasi atas kontrol tanpa macro belum konklusif. F4a menguji *kebijakan pencarian yang sama dan telah dibekukan* pada perubahan **struktur tata bahasa target** yang tidak digunakan untuk memilih kebijakan F3.3b. Pengujian ini dibuat dan dijalankan dalam sesi yang sama, sehingga bukan benchmark pihak ketiga dan bukan bank soal eksternal yang disegel secara kriptografis.

## 2. Metode yang dibekukan sebelum eksekusi

Empat kebijakan F3.3b tanpa perubahan: `GUIDED_MACRO`, `GUIDED_NO_MACRO`, `BLIND_MACRO`, `BLIND_NO_MACRO`. Algoritma pencarian berada di berkas `source/ace_f33_frozen.py` dengan SHA-256 `e7503e6d7512f1b6bbf69ac1e3afe14086b25e2801124d2bdb44caa0ffe50362`; berkas ini identik dengan sumber F3.3b sebelumnya.

Tiga *shift* pada generator target:

- **INDEPENDENT:** keenam tugas tidak mempunyai motif dua-operator yang sengaja diulang.
- **ALTERNATING:** dua motif prefix berbeda bergantian antartugas.
- **SUFFIX_MOTIF:** motif dua-operator berulang di akhir program, bukan awal seperti F3.3b.

Masih digunakan enam operator simbolik dan enam operator grid 3×3 yang sama, panjang program maksimal empat operator, serta enam tugas berurutan per kombinasi seed–keluarga–shift. Dengan demikian, ini menguji **perubahan struktur distribusi program** dan *transfer macro* di dalam domain tertutup, bukan perubahan ukuran grid, topologi graf, atau domain ilmiah baru.

**Anggaran dan pengelompokan:** 16 seed baru × 3 shift × 2 keluarga × 4 kebijakan = **384 run**, masing-masing **6 tugas × 48 kandidat × 5 probe per kandidat × 20 evaluasi akhir**. Setiap kebijakan mendapat 11.520 instans evaluasi akhir, dengan total 46.080 instans di empat kebijakan. Jumlah proposal dan probe setara; waktu CPU tidak dipaksa identik. Semua kebijakan mendapat target, input akhir, dan dua proposal pertama yang identik pada pasangan yang sesuai.

**Analisis primer yang didaftarkan sebelumnya:** perbedaan akurasi tepat `GUIDED_MACRO − GUIDED_NO_MACRO`, interval bootstrap persentil 95% dengan resampling 16 klaster seed (10.000 resampling, seed 445908). Kriteria dukungan: batas bawah interval > 0; bukti negatif: batas atas < 0; selain itu *inconclusive*.

Berkas `F4A_PRE_REGISTRATION.json` dikunci **sebelum hasil konfirmasi pertama dihitung**. SHA-256 pra-registrasi: `4e378bda38f6cd1b292940d15092d18fdb7cc323308701e37dad5ad0a56c7055`. Penguncian dilakukan secara lokal, bukan stempel waktu pihak ketiga.

## 3. Hasil utama

| Kebijakan | Benar / 11.520 | Akurasi |
|---|---:|---:|
| Guided + macro | 4.226 | 36,68% |
| Guided tanpa macro | 4.309 | 37,40% |
| Blind + macro | 4.300 | 37,33% |
| Blind tanpa macro | 4.127 | 35,82% |

Selisih primer teramati adalah **−83/11.520 = −0,7205 poin persentase** untuk Guided + macro dibanding Guided tanpa macro. **95% CI = [−3,611; +1,910] poin persentase**, dengan 9 seed berpihak pada macro dan 7 tidak.

**Keputusan primer: INCONCLUSIVE.** Tidak ada bukti keunggulan yang stabil; sebaliknya, interval juga tidak mendukung klaim bahwa macro pasti merugikan.

Kontras sekunder:

- Blind + macro vs Blind tanpa macro: **+1,502 poin**, CI **[−1,302; +4,332]**.
- Guided + macro vs Blind + macro: **−0,642 poin**, CI **[−4,236; +3,039]**.

Keduanya tidak konklusif.

## 4. Heterogenitas eksploratori (bukan klaim konfirmatori baru)

| Struktur baru | Guided + macro | Guided tanpa macro | Selisih poin |
|---|---:|---:|---:|
| Independent | 1.182/3.840 | 1.395/3.840 | **−5,55** |
| Alternating | 1.454/3.840 | 1.432/3.840 | **+0,57** |
| Suffix motif | 1.590/3.840 | 1.482/3.840 | **+2,81** |

Interval per strata tetap memotong nol, sehingga perbedaan tersebut adalah pola **eksploratori**, bukan bukti konklusif. Berdasarkan keluarga tugas, perbedaan guided macro vs no-macro adalah **+1,63 poin pada simbolik** dan **−3,07 poin pada grid**; keduanya juga memiliki interval yang mencakup nol.

Interpretasi yang masuk akal tetapi belum terbukti secara kausal: perpustakaan macro mungkin memperburuk prioritas proposal ketika struktur target tidak berulang, dan menjadi lebih relevan ketika ada suburutan yang bisa dipakai kembali. Penelitian lanjutan perlu dirancang sebelum melihat hasil berikutnya, bukan memilih hanya strata yang positif.

## 5. Audit dan kualitas bukti

- **10/10 tes pra-penguncian** dan **10/10 tes setelah konfirmasi** lulus. Termasuk pemisahan seed, kesetaraan dua proposal awal, dan uji bahwa perubahan skor final tidak mengubah program/macro yang dipilih.
- **384/384 rekaman log**, rantai SHA-256, dan keseluruhan **46.080 hasil evaluasi** konsisten.
- **384/384 replay semantik penuh** lulus setelah menormalisasi objek tuple Python ke representasi list JSON.
- **Bug verifikator yang ditemukan dan dipertahankan:** opsi bawaan `f4_runner.py audit --semantic` semula gagal karena membandingkan tuple di RAM dengan list dari JSON. `independent_semantic_audit.py` melakukan konversi ke representasi JSON kanonis sebelum perbandingan dan membuktikan kecocokan seluruh run. Kode eksperimen yang dibekukan **tidak diubah**, dan kegagalan verifikator asli disimpan di `semantic_audit_console.txt`.
- Operator dan metode dibatasi DSL; tidak ada Python hasil generasi model yang dijalankan, tidak ada API berbayar atau pembelian layanan.

## 6. Batas yang wajib dipertahankan

1. **F4a bukan F4 lengkap.** Di sini diuji empat kebijakan F3.3b, bukan perbandingan final A/B/C pada satu bank eksternal yang sama. Bank F4 historis yang benar-benar tersegel tidak tersedia dalam arsip yang diperiksa.
2. Algoritma pencarian dibekukan, **bukan kandidat program akhirnya**. Setiap tugas baru memperbolehkan 5 contoh probe berlabel untuk mengadaptasi kandidat (ditetapkan sebelum evaluasi), sedangkan 20 evaluasi akhir per tugas tidak digunakan untuk seleksi.
3. Sumber generator target dan interpreter berada dalam lingkungan yang sama. Pemisahan ini prosedural dan dapat diaudit, bukan isolasi keamanan yang tahan terhadap agen dengan akses filesystem.
4. Seluruh variasi masih berasal dari grammar tugas yang dikodekan manusia. Tidak ada bukti penemuan primitive fundamental, transfer lintas domain terbuka, AGI, atau peningkatan intelegensi tanpa batas.
5. Interval bootstrap 16 seed memiliki ketidakpastian; subkelompok dinilai secara eksploratori tanpa koreksi multipel.
6. Batas biaya sama untuk kandidat/probe, bukan kuota waktu CPU yang persis identik.

## 7. Keputusan dan jalur berikutnya

- `ENGINEERING_GATE=PASS` untuk pengujian reproduksi internal F4a.
- `PRIMARY_HYPOTHESIS=INCONCLUSIVE` untuk keunggulan transfer macro pada perubahan grammar.
- `FULL_F4=OPEN` karena benchmark berbeda struktur/topologi dan pembanding A/B/C terpadu belum dilakukan.
- `AUTONOMOUS_CAPABILITY_DISCOVERY=NOT_PROVEN`.

Langkah berikutnya bukan men-tuning algoritma untuk seed F4a yang sudah dibuka. Pengujian baru memerlukan desain beku dan **benchmark berbeda domain/topologi yang benar-benar belum digunakan untuk pengembangan**, dengan mekanisme seleksi dan evaluator terpisah. Data F4a kini dianggap terpakai dan tidak boleh diulang sebagai held-out konfirmatori setelah perubahan kebijakan.
