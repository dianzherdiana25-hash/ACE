"""Separate semantic implementation for E1 predictions; after-the-fact verification only.
Same research team, NOT external review.
"""
import json,sys
from pathlib import Path


def run_independent(program, input_values):
    v=tuple(input_values); m=11
    assert len(program)<=7
    for opcode in program:
        n=len(v)
        if opcode=='rev':w=tuple(v[n-1-i] for i in range(n))
        elif opcode=='rol':w=tuple(v[(i+1)%n] for i in range(n))
        elif opcode=='ror':w=tuple(v[(i-1)%n] for i in range(n))
        elif opcode=='swap':w=(v[-1],)+v[1:-1]+(v[0],)
        elif opcode=='pairs':w=tuple(v[i+1] if i%2==0 and i+1<n else (v[i-1] if i%2==1 else v[i]) for i in range(n))
        elif opcode=='inc':w=tuple((t+1)%m for t in v)
        elif opcode=='dec':w=tuple((t+m-1)%m for t in v)
        elif opcode=='mul2':w=tuple((t*2)%m for t in v)
        elif opcode=='alt':w=tuple((t+i%2)%m for i,t in enumerate(v))
        elif opcode=='neg':w=tuple((m-t)%m for t in v)
        elif opcode=='neighbor':w=tuple((v[i]+v[(i-1)%n])%m for i in range(n))
        elif opcode=='spread':w=tuple((t+i)%m for i,t in enumerate(v))
        else:raise ValueError(opcode)
        v=w
    return v

def audit(directory):
    d=Path(directory)
    rows=[json.loads(line) for line in (d/'run_results.jsonl').open()]
    key={(r['seed'],r['task_id'],r['policy']):r for r in rows}
    count=0
    for line in (d/'hidden_case_results.jsonl').open():
        c=json.loads(line);r=key[(c['seed'],c['task_id'],c['policy'])]
        out=run_independent(r['selected'],c['input'])
        assert out==tuple(c['predicted']), ('predict',c['seed'],c['task_id'],c['policy'],c['case'])
        assert (out==tuple(c['expected']))==c['correct'],('accuracy',count)
        count+=1
    assert count==len(rows)*20
    print('INDEPENDENT IMPLEMENTATION PASS:',count,'predictions')

if __name__=='__main__': audit(sys.argv[1])
