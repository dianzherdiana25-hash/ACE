"""Postrun structural checks: source/target examples do not overlap with heldout inputs."""
import json
from pathlib import Path
from collections import defaultdict
import evaluator

def audit(root):
    root=Path(root); lineage=[json.loads(s) for s in (root/'candidate_lineage.jsonl').read_text().splitlines()]
    actual={x['seed']:x for x in lineage}
    distinct=0;source_hidden_full=0
    for seed,item in actual.items():
        source,tasks=evaluator.make_episode(seed)
        assert item['source_examples']==[[list(x),list(y)] for x,y in source.demos]
        assert set(tuple(x) for x,_ in source.demos).isdisjoint({x for x,_ in source.heldout})
        assert item['source_hidden_correct']==sum(evaluator.run_atoms(item['learnt_macro'],x)==y for x,y in source.heldout)
        assert item['source_probe_exact']==sum(evaluator.run_atoms(item['learnt_macro'],x)==y for x,y in source.demos)
        distinct+=item['novel_vs_atoms_len_le2'];source_hidden_full+=(item['source_hidden_correct']==20)
        for task in tasks:
            assert set(tuple(x) for x,_ in task.demos).isdisjoint({x for x,_ in task.heldout})
    print('SPLIT/LINEAGE AUDIT PASS',len(lineage),'episodes',distinct,'nontrivial signatures',source_hidden_full,'full source heldout')

if __name__=='__main__':
 import sys;audit(sys.argv[1])
