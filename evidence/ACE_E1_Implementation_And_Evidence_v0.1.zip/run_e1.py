"""Locked E1 execution. No user-account actions, arbitrary generated code, or network."""
import hashlib,json,statistics,time
from pathlib import Path
from collections import defaultdict
import evaluator,policy
BASE=Path(__file__).resolve().parent
P=json.loads((BASE/'protocol.json').read_text())

def canon(x):return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False)
def sha(x):return hashlib.sha256(x.encode()).hexdigest()
def fit_stats(prog,examples):
    return sum(evaluator.run_atoms(prog,x)==y for x,y in examples)
def compute_bootstrap(rows, group='shared-new-composition'):
    import random
    seeds=sorted(set(row['seed'] for row in rows if row['family']==group))
    diffs={}
    for s in seeds:
        rr=[r for r in rows if r['seed']==s and r['family']==group]
        scores=defaultdict(list)
        for r in rr:scores[r['policy']].append(r['correct']/r['total'])
        diffs[s]={k:statistics.mean(v) for k,v in scores.items()}
    def contrast(a,b):
        d=[diffs[s][a]-diffs[s][b] for s in seeds]
        rng=random.Random(P['bootstrap']['rng_seed'])
        vals=[]
        for _ in range(P['bootstrap']['replicates']):
            vals.append(statistics.mean(d[rng.randrange(len(d))] for _ in d))
        vals.sort()
        return {'n_episodes':len(d),'mean':statistics.mean(d),'ci95':[vals[int(.025*len(vals))],vals[int(.975*len(vals))-1]],
                'paired_differences':d}
    return {f'{a}_minus_{b}':contrast(a,b) for a,b in [('C-learned-macro','B-base'),('C-learned-macro','D-shuffled-macro'),('C-learned-macro','E-no-feedback-macro')]}

def execute(confirmatory=False,out=None):
    if confirmatory:
        # The SHA256 lock file was created before the confirmatory seeds were touched.
        check=json.loads((BASE/'pre_run_lock.json').read_text())
        for f, expected in check['sha256'].items():
            got=hashlib.sha256((BASE/f).read_bytes()).hexdigest()
            if got != expected:raise RuntimeError(f'pre-run lock mismatch: {f}')
        seeds=range(P['confirmatory_seeds']['start'], P['confirmatory_seeds']['stop_inclusive']+1)
    else:seeds=P['development_seeds']
    out=Path(out or BASE / ('confirmatory' if confirmatory else 'development'))
    out.mkdir(parents=True,exist_ok=True)
    t0=time.perf_counter()
    episodes=[]
    for seed in seeds:
        src,tasks=evaluator.make_episode(seed)
        discovered,score,probes=policy.discover_macro(src.demos,evaluator.run_atoms,limit=P['source_candidate_budget'])
        src_correct=fit_stats(discovered,src.heldout)
        episodes.append({'seed':seed,'source_demos':src.demos,'source_hidden':src.heldout,'discovered':discovered,'teacher':src.reference,
                         'source_probe_exact':score[0],'source_hidden_correct':src_correct,'source_budget':probes,
                         'tasks':tasks})
    control_previous=evaluator.pick_macro(7001,'source')
    rows=[];case_rows=[];lineage=[]
    controls=['A-atomic','B-base','C-learned-macro','D-shuffled-macro','E-no-feedback-macro']
    for epi in episodes:
        seed=epi['seed']; learned=tuple(epi['discovered']);teacher=epi['teacher']
        from random import Random
        nofb=tuple(evaluator.ATOMS[i] for i in [Random(seed*13).randrange(12),Random(seed*13+1).randrange(12),Random(seed*13+2).randrange(12)])
        methods={'C-learned-macro':learned,'D-shuffled-macro':control_previous,'E-no-feedback-macro':nofb}
        lineage.append({'seed':seed,'source_examples':epi['source_demos'],'teacher_program_after_run':teacher,'learnt_macro':learned,
                        'source_probe_exact':epi['source_probe_exact'],'source_hidden_correct':epi['source_hidden_correct'],
                        'shuffled_macro':control_previous,'no_feedback_macro':nofb,
                        'novel_vs_atoms_len_le2':evaluator.signature(learned) not in {evaluator.signature(p) for n in (1,2) for p in __import__('itertools').product(evaluator.ATOMS,repeat=n)}})
        for task_id,task in enumerate(epi['tasks']):
            for name in controls:
                if name=='A-atomic':
                    candidates=[(a,) for a in evaluator.ATOMS]
                    p=max(candidates,key=lambda c:policy.score(c,task.demos,evaluator.run_atoms))
                    probe_count=len(candidates)
                    training=policy.score(p,task.demos,evaluator.run_atoms)
                else:
                    mode={'B-base':'base','C-learned-macro':'transfer','D-shuffled-macro':'shuffled','E-no-feedback-macro':'random_macro'}[name]
                    p,training,probe_count=policy.solve(mode,task.demos,evaluator.run_atoms,
                         macro=methods.get(name),limit=P['target_candidate_budget'])
                correct=0
                for j,(x,y) in enumerate(task.heldout):
                    z=evaluator.run_atoms(p,x)
                    ok=z==y;correct+=ok
                    case_rows.append({'seed':seed,'task_id':task_id,'family':task.family,'policy':name,'case':j,
                         'input':x,'expected':y,'predicted':z,'correct':ok})
                rows.append({'seed':seed,'task_id':task_id,'family':task.family,'policy':name,'selected':p,
                             'training_exact':training[0], 'training_elements':training[1], 'probe_candidates':probe_count,
                             'correct':correct,'total':len(task.heldout),'oracle_after_run':task.reference})
        control_previous=learned
    # Hash-chain persisted events; results can be independently rechecked against evaluator.
    prev='0'*64
    for event in rows:
        prev=sha(prev+canon(event));event['chain_sha256']=prev
    def write_jsonl(name, seq):
        (out/name).write_text(''.join(canon(r)+'\n' for r in seq))
    write_jsonl('run_results.jsonl',rows);write_jsonl('hidden_case_results.jsonl',case_rows)
    write_jsonl('candidate_lineage.jsonl',lineage)
    summary={'version':'E1v0.1','confirmatory':confirmatory,'protocol_sha256':sha((BASE/'protocol.json').read_text()),
             'rows':len(rows),'case_rows':len(case_rows),'episodes':len(episodes),'seconds':time.perf_counter()-t0,
             'last_chain_sha256':prev,'by_family':{},'source_macro':{'mean_hidden_correct':statistics.mean(l['source_hidden_correct'] for l in lineage),
                  'full_hidden_count':sum(l['source_hidden_correct']==20 for l in lineage),
                  'semantically_novel_count':sum(l['novel_vs_atoms_len_le2'] for l in lineage)},
             'bootstrap':compute_bootstrap(rows)}
    for family in sorted(set(r['family'] for r in rows)):
        summary['by_family'][family]={}
        for pol in controls:
            relevant=[r for r in rows if r['policy']==pol and r['family']==family]
            num=sum(r['correct'] for r in relevant);den=sum(r['total'] for r in relevant)
            summary['by_family'][family][pol]={'correct':num,'total':den,'accuracy':num/den}
    (out/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2,sort_keys=True))
    print('RUN',out,'episodes',len(episodes),'cases',len(case_rows),'seconds',round(summary['seconds'],2))
    for family,ps in summary['by_family'].items():
        print(family,' '.join(f'{k}:{v["correct"]}/{v["total"]}' for k,v in ps.items()))
    print('PRIMARY',summary['bootstrap']['C-learned-macro_minus_B-base'])
    return summary

if __name__=='__main__':
    import sys
    execute(confirmatory='--confirm' in sys.argv)
