import hashlib,json,sys
from pathlib import Path
import evaluator

def canon(x): return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False)

def audit(dirname):
    root=Path(dirname)
    rows=[json.loads(s) for s in (root/'run_results.jsonl').read_text().splitlines()]
    cases=[json.loads(s) for s in (root/'hidden_case_results.jsonl').read_text().splitlines()]
    summary=json.loads((root/'summary.json').read_text())
    prev='0'*64
    for i, event in enumerate(rows):
        assert event['chain_sha256']==hashlib.sha256((prev+canon({k:v for k,v in event.items() if k!='chain_sha256'})).encode()).hexdigest(), ('chain',i)
        prev=event['chain_sha256']
    assert prev==summary['last_chain_sha256']
    idx={(r['seed'],r['task_id'],r['policy']):r for r in rows}
    counts={}
    for c in cases:
        k=(c['seed'],c['task_id'],c['policy']);r=idx[k]
        assert tuple(evaluator.run_atoms(r['selected'],c['input']))==tuple(c['predicted']), ('eval',k)
        assert c['correct']==(c['predicted']==c['expected']),('score',k)
        counts[k]=counts.get(k,0)+bool(c['correct'])
    for k,r in idx.items():
        assert counts[k]==r['correct'] and r['total']==20, ('accuracy',k)
    for family,policies in summary['by_family'].items():
        for p,s in policies.items():
            sub=[r for r in rows if r['family']==family and r['policy']==p]
            assert sum(x['correct'] for x in sub)==s['correct'] and sum(x['total'] for x in sub)==s['total']
    assert len(cases)==summary['case_rows'] and len(rows)==summary['rows']
    print('AUDIT PASS',len(rows),'runs',len(cases),'hidden case predictions, SHA-256 chain PASS')
    return True

if __name__=='__main__': audit(sys.argv[1])
