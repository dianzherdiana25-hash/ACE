# ACE E1 — Prospective Capability Invention Challenge v0.1

Tanggal: 4 November 2026

Tujuan: menguji apakah pencarian simbolik terbatas dapat **menciptakan prosedur komposit berdasarkan contoh**, menyimpannya sebagai metode baru, lalu memanfaatkannya untuk menyelesaikan tugas komposisi baru. Eksperimen memakai program transformasi vektor bilangan dalam DSL tepercaya. Tidak ada LLM, API, internet, kode eksekusi arbitrer, atau biaya tambahan.

## Isi paket

- `protocol.json`, `pre_run_lock.json` — desain dan hash kode yang dibuat sebelum konfirmasi.
- `evaluator.py` — generator tugas dan oracle yang terpisah dari kode kebijakan.
- `policy.py` — sintesis contoh-ke-program dan pemilihan kandidat.
- `run_e1.py` — runner deterministik; memuat pemisahan development vs confirmatory.
- `test_e1.py` — 10 tes unit.
- `audit_e1.py` — audit hash-chain, prediksi dan skor.
- `audit_independent.py` — implementasi evaluasi kedua untuk verifikasi 7.200 prediksi.
- `audit_separation.py` — verifikasi pemisahan contoh dan data tersembunyi.
- `development/`, `confirmatory/` — hasil asli dan data mentah masing-masing.
- `E1_Research_Report_v0.1.md` — interpretasi dan keputusan penelitian.

## Reproduksi (Python 3.9+)

```bash
python -m unittest -v test_e1.py
python run_e1.py --confirm
python audit_e1.py confirmatory
python audit_independent.py confirmatory
python audit_separation.py confirmatory
```

**Catatan:** `run_e1.py --confirm` akan menulis ulang `confirmatory/`. Simpan terlebih dahulu data yang ingin dipertahankan (atau jalankan pada salinan paket), lalu bandingkan hash hasil JSONL dengan yang asli. Waktu eksekusi aktual akan berbeda antarmesin.

## Klaim dan keterbatasan

- Mesin menyintesis prosedur komposit dari contoh yang baru dilihat; prosedur tersebut tidak tersedia sebagai primitive tunggal.
- Ruang komposisi, operasi dasar dan keluarga tugas **dibuat manusia**.
- Sumber dan pengujian diciptakan oleh tim/kode yang sama walaupun dipisah menjadi modul: ini **bukan evaluator eksternal independen**, hanya pemisahan rekayasa.
- Tugas uji memuat kembali motif sumber dengan pembungkus baru: keunggulan C tidak membuktikan generalisasi ke motif baru.
- Anggaran **400 kandidat target** sama untuk B/C/D/E; biaya total pelatihan sumber dan panjang eksekusi setiap kandidat tidak disejajarkan secara ketat. B memang dibatasi agar tidak mewariskan macro.
- Hash lock lokal tidak punya timestamp tepercaya dari pihak ketiga.

## Status

E1 prototipe rekayasa: **PASS**. Bukti transfer komposisi dalam DSL: **SUPPORTED in this constructed benchmark**. Penemuan primitive fundamental, kecerdasan umum, evolusi AI mandiri: **NOT DEMONSTRATED**.
