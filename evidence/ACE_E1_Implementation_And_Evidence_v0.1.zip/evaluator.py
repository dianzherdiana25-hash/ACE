"""Independent-in-code evaluator: never imported by contender policy modules.
This is not third-party or cryptographically secret evaluation.
"""
import hashlib, random
from dataclasses import dataclass

ATOMS=('rev','rol','ror','swap','pairs','inc','dec','mul2','alt','neg','neighbor','spread')
MOD=11

def apply_atom(a, xs):
    x=list(xs); n=len(x)
    if a=='rev': y=x[::-1]
    elif a=='rol': y=x[1:]+x[:1]
    elif a=='ror': y=x[-1:]+x[:-1]
    elif a=='swap':
        y=x[:]; y[0],y[-1]=y[-1],y[0]
    elif a=='pairs':
        y=x[:]
        for i in range(0,n-1,2): y[i],y[i+1]=y[i+1],y[i]
    elif a=='inc': y=[(v+1)%MOD for v in x]
    elif a=='dec': y=[(v-1)%MOD for v in x]
    elif a=='mul2': y=[(2*v)%MOD for v in x]
    elif a=='alt': y=[(v+(i%2))%MOD for i,v in enumerate(x)]
    elif a=='neg': y=[(-v)%MOD for v in x]
    elif a=='neighbor': y=[(x[i]+x[(i-1)%n])%MOD for i in range(n)]
    elif a=='spread': y=[(x[i]+i)%MOD for i in range(n)]
    else: raise ValueError('unknown atom')
    return tuple(y)

def run_atoms(seq, xs, max_ops=7):
    if len(seq)>max_ops: raise ValueError('program op limit')
    for a in seq: xs=apply_atom(a, xs)
    return tuple(xs)

def rng_for(*items):
    s='::'.join(map(str,items)); digest=hashlib.sha256(s.encode()).digest()
    return random.Random(int.from_bytes(digest[:8],'big'))

def samples(seed, split, n, length):
    r=rng_for('ACE-E1-v0.1',seed,split,n,length)
    result=[]; used=set()
    while len(result)<n:
        x=tuple(r.randrange(MOD) for _ in range(length))
        if x not in used: result.append(x); used.add(x)
    return result

REFERENCE=[tuple(i*j%MOD for j in range(1,9)) for i in range(1,9)]
def signature(seq): return tuple(run_atoms(seq,x) for x in REFERENCE)

def pick_macro(seed, suffix='source'):
    r=rng_for('teacher-macro',seed,suffix)
    from itertools import product
    # Teacher excludes trivial reductions to <=2 atoms on a fixed set of independent inputs.
    basic={signature((a,)) for a in ATOMS}
    basic |= {signature((a,b)) for a,b in product(ATOMS,repeat=2)}
    candidates=list(product(ATOMS,repeat=3));r.shuffle(candidates)
    for seq in candidates:
        if ('neighbor' not in seq and 'spread' not in seq and 'alt' not in seq): continue
        if signature(seq) not in basic: return seq
    raise RuntimeError('No macro')

@dataclass(frozen=True)
class Task:
    family: str
    demos: tuple
    heldout: tuple
    # Ground truth stays inside evaluator/orchestrator; policy only gets demos.
    reference: tuple


def make_episode(seed):
    macro=pick_macro(seed,'source')
    rr=rng_for('teacher-wrappers',seed)
    pool=tuple(a for a in ATOMS if a not in ('rol','ror','inc','dec'))
    source=Task('source', tuple((x,run_atoms(macro,x)) for x in samples(seed,'source-demo',4,6)),
                tuple((x,run_atoms(macro,x)) for x in samples(seed,'source-hidden',20,9)),macro)
    tasks=[]
    for t in range(2):
        l=rr.choice(pool);r=rr.choice(pool)
        ref=(l,)+macro+(r,)
        tasks.append(Task('shared-new-composition',tuple((x,run_atoms(ref,x)) for x in samples(seed,f'shared{t}-demo',4,6)),
                          tuple((x,run_atoms(ref,x)) for x in samples(seed,f'shared{t}-hidden',20,9)),ref))
    novel=pick_macro(seed,'independent-novel')
    while signature(novel)==signature(macro):
        novel=pick_macro(seed+101,'independent-novel')
    l=rr.choice(pool);r=rr.choice(pool)
    ref=(l,)+novel+(r,)
    tasks.append(Task('unseen-motif',tuple((x,run_atoms(ref,x)) for x in samples(seed,'novel-demo',4,6)),
                 tuple((x,run_atoms(ref,x)) for x in samples(seed,'novel-hidden',20,9)),ref))
    return source,tuple(tasks)
