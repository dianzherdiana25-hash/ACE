"""Contender policy. No evaluator imported; accepts only demonstrations and primitive executor."""
from itertools import product
ATOMS=('rev','rol','ror','swap','pairs','inc','dec','mul2','alt','neg','neighbor','spread')

def score(seq, demos, apply):
    exact=0; elem=0
    for x,y in demos:
        z=apply(seq,x); exact+=(z==y);elem+=sum(a==b for a,b in zip(z,y))
    return (exact,elem)

def base_source_programs():
    for n in (1,2,3):
        for p in product(ATOMS,repeat=n): yield p

def discover_macro(demos, apply, limit=1884):
    best=None; bestkey=(-1,-1)
    inspected=0
    for seq in base_source_programs():
        if inspected>=limit: break
        s=score(seq,demos,apply);inspected+=1
        if s>bestkey: bestkey=s;best=seq
        # Don't stop on a simple program; search full depth-3 for robust comparison.
    return best, bestkey, inspected

def target_proposals(kind,macro=None):
    seen=set()
    def push(p):
        if p not in seen: seen.add(p);return p
        return None
    # The same atomic candidates are offered to every policy first.
    for a in ATOMS:
        p=push((a,));
        if p: yield p
    if kind in ('transfer','shuffled','random_macro') and macro is not None:
        # The candidate *function* is synthesized from examples, not hardcoded into target evaluator.
        for p in [macro]:
            q=push(p)
            if q: yield q
        for a in ATOMS:
            for p in [macro+(a,),(a,)+macro]:
                q=push(p)
                if q: yield q
        # C can combine a learned function and two existing operations.
        for a,b in product(ATOMS,repeat=2):
            for p in ((a,)+macro+(b,),macro+(a,b),(a,b)+macro):
                q=push(p)
                if q: yield q
    # Strong fixed grammar baseline; all policies also have access to it.
    for n in (2,3,4,5):
        for p in product(ATOMS,repeat=n):
            q=push(p)
            if q: yield q

def solve(kind, demos, apply, macro=None, limit=400):
    best=None; key=(-1,-1); inspected=0
    for program in target_proposals(kind,macro):
        if inspected>=limit:break
        s=score(program,demos,apply);inspected+=1
        if s>key:
            best=program;key=s
    return best,key,inspected
