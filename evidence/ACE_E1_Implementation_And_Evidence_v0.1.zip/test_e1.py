import unittest
from itertools import product
import evaluator,policy

class E1Tests(unittest.TestCase):
 def test_atom_types(self):
  for a in evaluator.ATOMS:
   v=evaluator.apply_atom(a,(1,3,7,9,2,4));self.assertEqual(len(v),6);self.assertTrue(all(0<=k<11 for k in v))
 def test_bound(self):
  with self.assertRaises(ValueError): evaluator.run_atoms(('inc',)*8,(1,2,3))
 def test_source_novelty(self):
  seq=evaluator.pick_macro(8801)
  small={evaluator.signature(p) for n in (1,2) for p in product(evaluator.ATOMS,repeat=n)}
  self.assertNotIn(evaluator.signature(seq),small)
 def test_determinism(self):
  self.assertEqual(evaluator.make_episode(8801),evaluator.make_episode(8801))
 def test_split_disjoint(self):
  src,tasks=evaluator.make_episode(8802)
  self.assertTrue(all({x for x,_ in task.demos}.isdisjoint({x for x,_ in task.heldout}) for task in (src,)+tasks))
 def test_policy_no_evaluator_import(self):
  import inspect;self.assertNotIn('import evaluator',inspect.getsource(policy))
 def test_search_budget(self):
  src,tasks=evaluator.make_episode(8803)
  for kind in ['base','transfer']:
   _,_,n=policy.solve(kind,tasks[0].demos,evaluator.run_atoms,macro=src.reference,limit=400)
   self.assertEqual(n,400)
 def test_source_budget(self):
  src,_=evaluator.make_episode(8804)
  _,_,n=policy.discover_macro(src.demos,evaluator.run_atoms)
  self.assertEqual(n,1884)
 def test_macro_from_examples(self):
  src,_=evaluator.make_episode(8805)
  p,k,n=policy.discover_macro(src.demos,evaluator.run_atoms)
  self.assertGreaterEqual(k[0],0);self.assertEqual(n,1884)
 def test_reference_kept_separate(self):
  src,ts=evaluator.make_episode(8806)
  self.assertEqual(len(ts),3)
  self.assertEqual([t.family for t in ts],['shared-new-composition']*2+['unseen-motif'])

if __name__=='__main__':unittest.main()
