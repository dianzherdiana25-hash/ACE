"""F2 pilot acceptance checks; independent from the F1 suite."""
import copy
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
import ace_f1 as f1
import ace_f2 as f2

class F2Tests(unittest.TestCase):
    def setUp(self):
        self.t=tempfile.TemporaryDirectory()
        self.root=Path(self.t.name)
    def tearDown(self):self.t.cleanup()

    def test_01_f1_code_is_identical_to_verified_baseline(self):
        self.assertEqual(f2.frozen_files()['f1_sha256'],
                         '4ef8a5c06b75a9df00367ce74226443f1c394b29d253d3f977183f8a9df3a46b')

    def test_02_seed_manifest_disjoint_and_no_heldout(self):
        for s in f2.SEEDS:
            probe,final=f2.make_manifest(s)
            self.assertEqual((len(probe),len(final)),(4,32))
            self.assertEqual(set(t['task_id'] for t in probe)&set(t['task_id'] for t in final),set())
            self.assertTrue(all(t['split']!='held-out' for t in probe+final))
            self.assertEqual(sum(t['split']=='validation' for t in final),8)

    def test_03_full_handcrafted_symbolic_module(self):
        for s in f2.SEEDS:
            for t in f1.generate(s):
                if t['family']=='S':
                    self.assertEqual(f1.evaluate(t,f2.solve(f1.public_task(t),'S_EXTENDED'))['score'],1)

    def test_04_graph_solver_independent_correctness(self):
        for s in f2.SEEDS:
            for t in f1.generate(s):
                if t['family']=='G':
                    self.assertEqual(f1.evaluate(t,f2.solve(f1.public_task(t),'G_CONSTRAINED'))['score'],1)

    def test_05_begins_with_frozen_a(self):
        for s in f2.SEEDS:
            for t in f1.generate(s):
                if t['family']=='S': arm='S_BASIC'
                else:arm='G_BASIC'
                self.assertEqual(f2.solve(f1.public_task(t),arm),f1.a_fixed_solve(f1.public_task(t)))

    def test_06_catalogue_and_strategy_slots(self):
        for mode in ('A_CONTROL','B_ADAPT'):
            _,_,trials=f2.plan(f2.SEEDS[0],mode)
            self.assertEqual(len(trials),12)
            if mode=='A_CONTROL':
                self.assertTrue(all(arm.endswith('BASIC') for _,arm,_ in trials))
            self.assertEqual(len(set(t['task_id'] for t,_,_ in trials)),4)

    def test_07_budget_refusal(self):
        with self.assertRaises(f2.F2BudgetError):
            f2.run(self.root,'B_ADAPT',f2.SEEDS[0],max_cost_idr=1)
        self.assertFalse((self.root/'runs').exists())

    def test_08_invalid_model_seed_and_public_only(self):
        with self.assertRaises(ValueError):f2.conf('B_ADAPT',999)
        with self.assertRaises(ValueError):f2.conf('C_EVOLVE',f2.SEEDS[0])
        task=f1.public_task(f1.generate(f2.SEEDS[0])[0]);task['split']='held-out'
        with self.assertRaises(ValueError):f2.solve(task,'S_EXTENDED')

    def test_09_crash_resume_no_duplicate(self):
        s=f2.SEEDS[0]
        with self.assertRaises(InterruptedError):
            f2.run(self.root,'B_ADAPT',s,simulate_interrupt=True)
        e=self.root/'runs'/f2.run_id('B_ADAPT',s)/'events.jsonl'
        self.assertEqual(len(f2.read_events(e)),1)
        result=f2.run(self.root,'B_ADAPT',s)
        self.assertEqual(result['probe_count'],12)
        self.assertEqual(result['final_count'],32)
        before=e.read_bytes();f2.run(self.root,'B_ADAPT',s)
        self.assertEqual(e.read_bytes(),before)
        self.assertEqual(len(f2.read_events(e)),45)

    def test_10_cut_after_some_final_and_resume(self):
        s=f2.SEEDS[0];mode='B_ADAPT'
        part=f2.run(self.root,mode,s,stop_after_events=17)
        self.assertFalse(part['complete']);self.assertEqual(part['final_count'],4)
        done=f2.run(self.root,mode,s)
        self.assertTrue(done['complete']);self.assertEqual(done['final_count'],32)

    def test_11_tamper_hash_detected(self):
        s=f2.SEEDS[0];mode='B_ADAPT'
        f2.run(self.root,mode,s)
        d=self.root/'runs'/f2.run_id(mode,s);p=d/'events.jsonl'
        orig=p.read_bytes();p.write_bytes(orig.replace(b'B_ADAPT',b'C_ADAPT',1))
        with self.assertRaises(f2.F2IntegrityError):f2.verify_run(self.root,mode,s)

    def test_12_tamper_valid_chain_but_bad_score_detected(self):
        s=f2.SEEDS[0];mode='B_ADAPT'
        f2.run(self.root,mode,s)
        d=self.root/'runs'/f2.run_id(mode,s);p=d/'events.jsonl'
        ev=f2.read_events(p)
        ev[0]['score']=1-ev[0]['score']
        prev='0'*64
        for e in ev:
            e['previous_hash']=prev;e['event_hash']=f2.sha({k:v for k,v in e.items() if k!='event_hash'});prev=e['event_hash']
        p.write_text('\n'.join(f1.canonical(x) for x in ev)+'\n')
        with self.assertRaises(f2.F2IntegrityError):f2.verify_run(self.root,mode,s)

    def test_13_selected_strategy_only_from_probes(self):
        s=f2.SEEDS[0];mode='B_ADAPT';f2.run(self.root,mode,s)
        d=self.root/'runs'/f2.run_id(mode,s)
        ev=f2.read_events(d/'events.jsonl');freeze=next(x for x in ev if x['action']=='FREEZE')
        self.assertEqual(freeze['selected'],f2.select([x for x in ev if x['action']=='PROBE'],mode))
        self.assertEqual(freeze['event_id'],13)
        self.assertTrue(all(e['event_id']>13 for e in ev if e['action']=='FINAL'))

    def test_14_full_parallel_comparison(self):
        for mode in ('A_CONTROL','B_ADAPT'):
            for s in f2.SEEDS:f2.run(self.root,mode,s)
        report=f2.summary(self.root)
        self.assertEqual(len(report['runs']),6)
        self.assertEqual(report['heldout_attempts'],0)
        self.assertEqual(report['additional_cost_idr'],0)
        self.assertEqual(sum(v['total'] for v in report['metrics'].values()),192)
        self.assertEqual(sum(v['pass'] for k,v in report['metrics'].items() if k.startswith('A_CONTROL')),79)
        self.assertEqual(sum(v['pass'] for k,v in report['metrics'].items() if k.startswith('B_ADAPT')),94)

    def test_15_checkpoint_corruption_detected(self):
        s=f2.SEEDS[0];mode='A_CONTROL';f2.run(self.root,mode,s)
        p=self.root/'runs'/f2.run_id(mode,s)/'checkpoint.json'
        obj=f2.read_json(p);obj['ledger_sha256']='f'*64;f2.write_json(p,obj)
        with self.assertRaises(f2.F2IntegrityError):f2.verify_run(self.root,mode,s)

    def test_16_time_budget_enforced(self):
        with patch.object(f2,'TIME_CAP_SECONDS',-1):
            with self.assertRaises(f2.F2BudgetError):
                f2.run(self.root,'B_ADAPT',f2.SEEDS[0])
        d=self.root/'runs'/f2.run_id('B_ADAPT',f2.SEEDS[0])
        self.assertFalse((d/'events.jsonl').exists())

if __name__=='__main__':unittest.main(verbosity=2)
