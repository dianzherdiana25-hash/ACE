"""ACE F2: bounded, deterministic strategy adaptation (stdlib only).

No model training, no generative AI, no code execution from candidates. The
portfolio is hand-coded, and adaptation selects a strategy from probe rewards.
Never accesses F4 sealed held-out tests. F1 is copied byte-for-byte.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import sys
import time
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

import ace_f1 as f1

STUDY = 'ACE-F2-20261104'
VERSION = 'B-adaptive-catalog-0.1.0'
SEEDS = f1.SEEDS
TRIAL_CAP = 12
FINAL_CAP = 32
TIME_CAP_SECONDS = 1800
MAX_COST_IDR = 0
ARMS = {'S': ('S_BASIC', 'S_DEDUPE_ONLY', 'S_EXTENDED'),
        'G': ('G_BASIC', 'G_MUST_ONLY', 'G_CONSTRAINED')}

class F2IntegrityError(Exception):
    pass

class F2BudgetError(Exception):
    pass


def sha(obj):
    return f1.digest(obj)


def write_json(path, obj):
    f1.atomic_json(Path(path), obj)


def read_json(path):
    return f1.read_json(Path(path))


def frozen_files():
    return {'f1_sha256': f1.file_hash(Path(f1.__file__)),
            'f2_sha256': f1.file_hash(Path(__file__))}


def make_manifest(seed):
    tasks = f1.generate(seed)
    # One of three validation examples per template is a probe; two are
    # reserved for post-freeze validation of the selected catalogue.
    probes = [t for t in tasks if t['split']=='validation'
              and int(t['task_id'][-4:]) in (1, 4)]
    finals = [t for t in tasks if t['split']=='development' or
              (t['split']=='validation' and t not in probes)]
    assert len(probes)==4 and len(finals)==32
    assert len(set(t['task_id'] for t in probes+finals))==36
    assert not any(t['split']=='held-out' for t in probes+finals)
    return probes, finals


def symbol_extended(problem, arm):
    tokens=list(problem['tokens'])
    for op in problem['operations']:
        name=op['op']
        if name == 'reverse': tokens.reverse()
        elif name == 'rotate_left':
            n=(op['steps'] % len(tokens)) if tokens else 0
            tokens=tokens[n:]+tokens[:n]
        elif name == 'filter_eq': tokens=[x for x in tokens if x==op['value']]
        elif name == 'dedupe' and arm in ('S_DEDUPE_ONLY','S_EXTENDED'):
            seen=set();out=[]
            for x in tokens:
                if x not in seen:seen.add(x);out.append(x)
            tokens=out
        elif name == 'swap_pairs' and arm == 'S_EXTENDED':
            for i in range(0,len(tokens)-1,2):
                tokens[i],tokens[i+1] = tokens[i+1],tokens[i]
        else:return None
    return tokens


def graph_constrained(problem, arm):
    if arm=='G_BASIC':
        return f1.baseline_shortest(problem)
    if arm=='G_MUST_ONLY' and 'max_hops' in problem:
        return f1.baseline_shortest(problem)
    # Independent constrained exhaustive search; never call F1 oracle_graph.
    graph,start,goal=f1.neighbors(problem)
    must=problem.get('must_visit')
    max_hops=problem.get('max_hops') if arm=='G_CONSTRAINED' else None
    best_cost=None;best_path=None
    stack=[(start,[start],0)]
    while stack:
        node,path,cost=stack.pop()
        if best_cost is not None and cost>best_cost: continue
        if node==goal:
            if (must is None or must in path) and (max_hops is None or len(path)-1<=max_hops):
                if best_cost is None or (cost,tuple(map(str,path)))<(best_cost,tuple(map(str,best_path))):
                    best_cost,best_path=cost,path
            continue
        if max_hops is not None and len(path)-1>=max_hops: continue
        for nxt,weight in graph[node]:
            if nxt not in path:stack.append((nxt,path+[nxt],cost+weight))
    if best_path is None:return {'path':[],'cost':None,'reachable':False}
    return {'path':[list(x) if isinstance(x,tuple) else x for x in best_path],
            'cost':best_cost,'reachable':True}


def solve(task, arm):
    if set(task.keys())!={'task_id','family','problem','answer_format','limits'}:
        raise ValueError('only public task may be used')
    if task['family']=='S':
        if arm not in ARMS['S']:raise ValueError('invalid symbolic arm')
        out=symbol_extended(task['problem'],arm)
        if out is None:return {'task_id':task['task_id'],'answer':None,'declared_status':'UNSUPPORTED'}
        return {'task_id':task['task_id'],'answer':{'tokens':out}}
    if task['family']=='G':
        if arm not in ARMS['G']:raise ValueError('invalid graph arm')
        return {'task_id':task['task_id'],'answer':graph_constrained(task['problem'],arm)}
    raise ValueError('unknown family')


def plan(seed,mode):
    probes,finals=make_manifest(seed)
    trials=[]
    for fam in ('S','G'):
        for task in (t for t in probes if t['family']==fam):
            for arm in ARMS[fam]:
                # Control A has same 12 probe-scorer evaluations, but no tuning.
                trial_arm = arm if mode=='B_ADAPT' else ARMS[fam][0]
                trials.append((task,trial_arm,arm))
    assert len(trials)==TRIAL_CAP
    return probes,finals,trials


def select(evs,mode):
    if mode=='A_CONTROL':return {'S':'S_BASIC','G':'G_BASIC'}
    scores={fam:{arm:0 for arm in ARMS[fam]} for fam in ARMS}
    for ev in evs:
        if ev['action']!='PROBE':continue
        scores[ev['family']][ev['arm']]+=ev['score']
    # Preserve baseline on a tie. Catalogue order is a simplicity prior.
    chosen={fam:max(ARMS[fam],key=lambda arm: scores[fam][arm]) for fam in ARMS}
    return chosen


def run_id(mode,seed):
    return f'{mode}_{seed}'


def conf(mode,seed):
    if mode not in ('A_CONTROL','B_ADAPT'):raise ValueError('unknown mode')
    if seed not in SEEDS:raise ValueError('unregistered seed')
    return json.loads(f1.canonical({'study':STUDY,'version':VERSION,'mode':mode,'seed':seed,'code':frozen_files(),
            'trial_cap':TRIAL_CAP,'final_cap':FINAL_CAP,'cost_idr':0,'model_calls':0,
            'evaluation_policy':'4 validation probe instances (1/template), then 32 final instances; no F4 held-out',
            'selection_policy':'best observed probe score per family, preserve baseline on tie',
            'catalog':ARMS}))


def read_events(path):
    path=Path(path)
    evs=[]; prior='0'*64
    if not path.exists():return evs
    for i,line in enumerate(path.read_text(encoding='utf8').splitlines(),1):
        if not line.strip():continue
        try:e=json.loads(line)
        except ValueError as exc: raise F2IntegrityError('corrupt JSON') from exc
        if e.get('event_id')!=len(evs)+1 or e.get('previous_hash')!=prior:
            raise F2IntegrityError('invalid chain order')
        actual=e.get('event_hash')
        if actual!=sha({k:v for k,v in e.items() if k!='event_hash'}):
            raise F2IntegrityError('ledger hash mismatch')
        evs.append(e);prior=actual
    return evs


def append_event(path, event):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('a',encoding='utf8') as f:
        f.write(f1.canonical(event)+'\n');f.flush();os.fsync(f.fileno())


def push_event(path,events,conf_sha,mode,seed,action,**data):
    event={'event_id':len(events)+1,'previous_hash':events[-1]['event_hash'] if events else '0'*64,
           'utc':datetime.now(timezone.utc).isoformat(),'study':STUDY,'phase':'F2',
           'mode':mode,'seed':seed,'config_sha256':conf_sha,'action':action,
           'additional_cost_idr':0,'model_calls':0, **data}
    event['event_hash']=sha(event)
    append_event(path,event);events.append(event)


def save_checkpoint(directory,events,mode,seed):
    last=events[-1]['event_hash'] if events else '0'*64
    write_json(directory/'checkpoint.json',{'run_id':run_id(mode,seed),'last_event_id':len(events),
            'ledger_sha256':last,'status':'COMPLETED' if len([e for e in events if e['action']=='FINAL'])==FINAL_CAP else 'CHECKPOINTED'})


def verify_run(root,mode,seed,require_complete=False):
    d=Path(root)/'runs'/run_id(mode,seed)
    cfg=read_json(d/'config.snapshot.json')
    if cfg!=conf(mode,seed):raise F2IntegrityError('config / source mismatch')
    events=read_events(d/'events.jsonl')
    probes,finals,trials=plan(seed,mode)
    observed_probes=[e for e in events if e['action']=='PROBE']
    observed_final=[e for e in events if e['action']=='FINAL']
    freezes=[e for e in events if e['action']=='FREEZE']
    if len(observed_probes)>TRIAL_CAP or len(observed_final)>FINAL_CAP or len(freezes)>1:
        raise F2IntegrityError('too many events')
    # Require one contiguous sequence of trials, a freeze, then all final results.
    expected_actions=['PROBE']*len(observed_probes)
    if freezes:expected_actions+=['FREEZE']+['FINAL']*len(observed_final)
    if [e['action'] for e in events]!=expected_actions:
        raise F2IntegrityError('illegal state transition')
    if freezes and len(observed_probes)!=TRIAL_CAP:
        raise F2IntegrityError('freeze before probes complete')
    cfg_sha=sha(cfg)
    for idx,e in enumerate(observed_probes):
        task,arm,slot=trials[idx]
        resp=solve(f1.public_task(task),arm)
        grade=f1.evaluate(task,resp)
        fields={'task_id':task['task_id'],'task_sha256':sha(task), 'family':task['family'],
                'arm':arm,'trial_slot':slot, 'response_sha256':sha(resp),
                'score':grade['score'],'status':grade['status']}
        if any(e.get(k)!=v for k,v in fields.items()) or e.get('config_sha256')!=cfg_sha:
            raise F2IntegrityError('probe replay mismatches')
    if freezes:
        chosen=select(observed_probes,mode)
        if freezes[0].get('selected')!=chosen or freezes[0].get('policy_sha256')!=sha(chosen):
            raise F2IntegrityError('freeze winner mismatch')
        for i,e in enumerate(observed_final):
            task=finals[i]
            arm=chosen[task['family']]
            resp=solve(f1.public_task(task),arm)
            grade=f1.evaluate(task,resp)
            fields={'task_id':task['task_id'],'task_sha256':sha(task),'family':task['family'],
                    'split':task['split'],'arm':arm,'score':grade['score'],
                    'status':grade['status'],'response_sha256':sha(resp)}
            if any(e.get(k)!=v for k,v in fields.items()) or e.get('config_sha256')!=cfg_sha:
                raise F2IntegrityError('final replay mismatch')
    chk=read_json(d/'checkpoint.json') if (d/'checkpoint.json').exists() else None
    if chk:
        n=chk['last_event_id']
        if n>len(events) or (n>0 and chk['ledger_sha256']!=events[n-1]['event_hash']):
            raise F2IntegrityError('stale checkpoint not a ledger prefix')
    is_complete=len(observed_probes)==TRIAL_CAP and len(freezes)==1 and len(observed_final)==FINAL_CAP
    if require_complete and not is_complete:raise F2IntegrityError('run incomplete')
    if is_complete and (not chk or chk['status']!='COMPLETED'):
        raise F2IntegrityError('final checkpoint missing')
    if any(e['additional_cost_idr']!=0 or e['model_calls']!=0 for e in events):
        raise F2IntegrityError('nonzero external budget')
    if any(not isinstance(e.get('cpu_seconds'),(int,float)) or e['cpu_seconds']<0 for e in events):
        raise F2IntegrityError('invalid CPU accounting')
    return {'mode':mode,'seed':seed,'probe_count':len(observed_probes),
            'final_count':len(observed_final),'complete':is_complete,
            'ledger_head':events[-1]['event_hash'] if events else '0'*64,
            'selected':freezes[0]['selected'] if freezes else None,
            'final_pass':sum(e['score'] for e in observed_final)}


def run(root,mode,seed,stop_after_events=None,simulate_interrupt=False,max_cost_idr=0):
    if max_cost_idr!=0:raise F2BudgetError('additional monetary cost must be 0')
    d=Path(root)/'runs'/run_id(mode,seed)
    d.mkdir(parents=True,exist_ok=True)
    cfg=conf(mode,seed);cfg_path=d/'config.snapshot.json'
    if cfg_path.exists() and read_json(cfg_path)!=cfg:raise F2IntegrityError('source changed')
    if not cfg_path.exists():write_json(cfg_path,cfg)
    events=read_events(d/'events.jsonl')
    if (d/'checkpoint.json').exists():verify_run(root,mode,seed)
    probes,finals,trials=plan(seed,mode)
    num=len(events);new=0;start=time.monotonic()

    def commit(action, **data):
        nonlocal new
        if time.monotonic()-start>TIME_CAP_SECONDS:raise F2BudgetError('time cap')
        push_event(d/'events.jsonl',events,sha(cfg),mode,seed,action,**data)
        new+=1
        if simulate_interrupt and new==1:raise InterruptedError('injected after durable event, before checkpoint')
        save_checkpoint(d,events,mode,seed)

    for i in range(len([e for e in events if e['action']=='PROBE']),TRIAL_CAP):
        if stop_after_events is not None and new>=stop_after_events:return verify_run(root,mode,seed)
        task,arm,slot=trials[i]
        cpu_start=time.process_time()
        response=solve(f1.public_task(task),arm)
        verdict=f1.evaluate(task,response)
        cpu_seconds=round(time.process_time()-cpu_start,9)
        commit('PROBE',task_id=task['task_id'],family=task['family'],task_sha256=sha(task),
               arm=arm,trial_slot=slot,response_sha256=sha(response),
               score=verdict['score'],status=verdict['status'],cpu_seconds=cpu_seconds)
    if not any(e['action']=='FREEZE' for e in events):
        if stop_after_events is not None and new>=stop_after_events:return verify_run(root,mode,seed)
        winner=select(events,mode)
        commit('FREEZE',selected=winner,policy_sha256=sha(winner),cpu_seconds=0.0)
    chosen=next(e['selected'] for e in events if e['action']=='FREEZE')
    for i in range(len([e for e in events if e['action']=='FINAL']),FINAL_CAP):
        if stop_after_events is not None and new>=stop_after_events:return verify_run(root,mode,seed)
        task=finals[i]
        arm=chosen[task['family']]
        cpu_start=time.process_time()
        response=solve(f1.public_task(task),arm)
        verdict=f1.evaluate(task,response)
        cpu_seconds=round(time.process_time()-cpu_start,9)
        commit('FINAL',task_id=task['task_id'],family=task['family'],split=task['split'],
               task_sha256=sha(task),arm=arm,response_sha256=sha(response),
               score=verdict['score'],status=verdict['status'],cpu_seconds=cpu_seconds)
    return verify_run(root,mode,seed,require_complete=True)


def summary(root):
    root=Path(root);result=[];metrics={};subsets={}
    for mode in ('A_CONTROL','B_ADAPT'):
        for seed in SEEDS:
            v=verify_run(root,mode,seed,require_complete=True)
            result.append(v)
            d=root/'runs'/run_id(mode,seed)
            events=read_events(d/'events.jsonl')
            for e in (e for e in events if e['action']=='FINAL'):
                key=f"{mode}_{e['family']}_{e['split']}"
                if key not in metrics:metrics[key]={'pass':0,'total':0}
                metrics[key]['total']+=1;metrics[key]['pass']+=e['score']
                # Display post-freeze validation separately from development.
            subsets[run_id(mode,seed)]={'selected':v['selected'],'probe_success':sum(e['score'] for e in events if e['action']=='PROBE'),
                                        'probe_cpu_seconds':round(sum(e['cpu_seconds'] for e in events if e['action']=='PROBE'),6),
                                        'final_cpu_seconds':round(sum(e['cpu_seconds'] for e in events if e['action']=='FINAL'),6),
                                        'postfreeze_pass':v['final_pass']}
    for v in metrics.values():v['rate']=v['pass']/v['total']
    p={'study':STUDY,'version':VERSION,'hypothesis':'adaptive catalogue selection only, not autonomous invention',
       'heldout_attempts':0,'model_calls':0,'additional_cost_idr':0,'seeds':list(SEEDS),
       'trial_evaluations_per_condition_seed':TRIAL_CAP,'postfreeze_tasks_per_condition_seed':FINAL_CAP,
       'metrics':metrics,'per_run':subsets,'runs':result,'f1_source_sha256':frozen_files()['f1_sha256'],
       'limitations':[
         'The four probe problems per seed are drawn from F1 validation and are used for selection; they are NOT unbiased final test cases.',
         'The remaining F1 validation tasks share templates with probes; post-freeze scores do not establish unseen-template transfer.',
         'Catalog modules are handwritten; B does not generate code, self-train an LLM, or invent algorithms.',
         'Equal 12 scorer queries does not equalize CPU time, algorithm design effort, or prior knowledge; compare resource usage separately.',
         'F4 sealed held-out is absent and NOT_RUN.',
         'Colab persistent storage and execution isolation of untrusted generated code remain unverified.'
       ]}
    (root/'reports').mkdir(parents=True,exist_ok=True)
    write_json(root/'reports'/'metrics.json',p)
    lines=['# ACE F2 — Local adaptive-catalog experiment','',
           '**Research inference:** strategy-selection pilot only; not autonomous AI evolution.','',
           f"- {len(result)} complete run ledgers; 12 scorer probes + 32 frozen final evaluations per seed and condition.",
           '- F4 held-out tasks never generated; no paid APIs; no dynamically generated source execution.','',
           '| Mode / family / split | Correct | Total | Rate |','|---|---:|---:|---:|']
    for k,v in metrics.items():lines.append(f"| {k} | {v['pass']} | {v['total']} | {v['rate']:.1%} |")
    lines.extend(['','**Design caution:** each seed reuses 1 validation example/template as adaptation probe, with 2 remaining examples/template as post-freeze tests. They are not unseen templates.','',
                  'B selects between fixed handwritten profiles based only on probe `score` and never sees reference solutions. No claims about intelligence generalization or successor agents.'])
    (root/'reports'/'summary.id.md').write_text('\n'.join(lines)+'\n',encoding='utf8')
    return p


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('command',choices=('run','verify','summary'))
    parser.add_argument('--root',default='f2_evidence')
    parser.add_argument('--mode',choices=('A_CONTROL','B_ADAPT'),default=None)
    parser.add_argument('--seed',type=int,choices=SEEDS)
    parser.add_argument('--stop-after-events',type=int)
    parser.add_argument('--max-cost-idr',type=int,default=0)
    a=parser.parse_args()
    modes=[a.mode] if a.mode else ['A_CONTROL','B_ADAPT']
    seeds=[a.seed] if a.seed else SEEDS
    if a.command=='run':
        for m in modes:
            for s in seeds:print(f1.canonical(run(a.root,m,s,stop_after_events=a.stop_after_events,max_cost_idr=a.max_cost_idr)))
    elif a.command=='verify':
        for m in modes:
            for s in seeds:print(f1.canonical(verify_run(a.root,m,s,require_complete=True)))
    elif a.command=='summary':
        print(f1.canonical(summary(a.root)))

if __name__=='__main__':main()
