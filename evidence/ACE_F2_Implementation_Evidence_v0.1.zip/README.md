# ACE — F2 Adaptive Catalog Pilot v0.1

**F2 local result**: `A_CONTROL` 79/96, `B_ADAPT` 94/96 on the 32 post-freeze tasks x 3 seeds; 30/30 unit/acceptance tests passed. No external API, paid service or F4 held-out data.

## Requirements

- Python 3.10+; standard library only.
- Folder includes the exact verified ACE F1 baseline source `ace_f1.py` (sha256: `4ef8a5c06b75a9df00367ce74226443f1c394b29d253d3f977183f8a9df3a46b`).
- No notebook execution of untrusted code. All strategy profiles are fixed, hand-coded.

## Reproduce locally

```bash
python -m unittest -v test_f1 test_f2
python ace_f2.py run --root evidence
python ace_f2.py verify --root evidence
python ace_f2.py summary --root evidence
```

Notebook `ACE_F2_Adaptive_Colab_v0.1.ipynb` embeds these source files and runs the same commands without internet/API dependencies. It exports `ACE_F2_reproduced_evidence.zip` containing experiment evidence and tests for independent inspection.

## Security and research boundaries

- The four probe instances/seed are deliberately used for selection, so they are not untouched validation. Remaining validation instances share templates with probe tasks.
- The F4 held-out benchmark is not present. This pilot does NOT prove generalizable self-learning, autonomous capability invention or AGI.
- Additional API/service cost cap Rp0, model calls 0, 12 scorer queries for both conditions, 32 post-freeze task evaluations for both. Human development effort is not budget-matched.
- Persist Colab evidence ZIP yourself; ephemeral Colab filesystem is not long-term archival storage.

See `F2_Execution_Report_v0.1.md` for analysis and limitations.
