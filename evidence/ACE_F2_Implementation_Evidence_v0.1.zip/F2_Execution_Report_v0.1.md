# ACE F2 — Laporan Implementasi dan Pengujian Lokal v0.1

**Tanggal:** 4 November 2026  
**Status:** `LOCAL_VERIFIED`; reproduksi pada Google Colab pengguna `NOT_RUN`.  
**Klaim maksimum:** pemilihan strategi secara adaptif dari katalog algoritma buatan manusia bekerja pada pilot F2; bukan AI yang menemukan metode baru atau meningkatkan kecerdasan umum.

## Lingkup yang diimplementasikan

- Sumber `ace_f1.py` **disalin byte-per-byte** dari baseline F1 yang telah diverifikasi; SHA-256 `4ef8a5c06b75a9df00367ce74226443f1c394b29d253d3f977183f8a9df3a46b`.
- `A_CONTROL`: solver tetap, dievaluasi 12 kali pada empat kasus *probe* per seed tanpa pembelajaran. Ini adalah kontrol F2 dengan jumlah evaluasi pencarian yang sama.
- `B_ADAPT`: mencoba tiga profil strategi tertulis tangan untuk masing-masing keluarga S dan G; memilih profil yang mengumpulkan skor *probe* terbanyak. Pada skor imbang, profil lebih sederhana dipilih terlebih dahulu.
- Setiap seed memakai **4 kasus probe** (satu contoh validasi untuk masing-masing empat template validasi); kasus-kasus ini **tidak** masuk evaluasi pasca-pembekuan.
- Setiap kondisi kemudian dinilai pada **32 tugas akhir per seed**: 24 development (uji regresi) dan 8 validasi lain yang belum dipakai untuk memilih strategi. Tugas-tugas akhir validasi memakai **template yang sama** dengan probe: bukan bukti transfer lintas-template.
- Sistem menggunakan modul Python statis tepercaya, tidak menjalankan kode yang ditulis AI, tidak membuat panggilan API, dan tidak membuat dataset *held-out* F4.

## Hasil yang diukur

| Ukuran | A — Fixed | B — Adaptive |
|---|---:|---:|
| Pengujian otomatis F1 + F2 (bersama) | \- | 30/30 PASS |
| Seed/ledger lengkap | 3 | 3 |
| Evaluasi probe per seed | 12 | 12 |
| Evaluasi pasca-pembekuan per seed | 32 | 32 |
| Development, benar | 72/72 | 72/72 |
| Validasi tidak dipakai untuk memilih strategi, benar | 7/24 | 22/24 |
| **Seluruh tugas pasca-pembekuan, benar** | **79/96 (82,3%)** | **94/96 (97,9%)** |
| API/model calls | 0 | 0 |
| Biaya layanan tambahan terukur | Rp0 | Rp0 |
| Held-out F4 | **NOT RUN** | **NOT RUN** |

**Selisih:** +15 jawaban benar dari 96 evaluasi akhir (+15,6 poin persentase). Ini merupakan perbandingan pada distribusi contoh F1, bukan uji *open-ended intelligence evolution*. Statistik hanya deskriptif untuk sampel kecil yang telah dirancang, tanpa signifikansi inferensial.

### Pilihan strategi menurut seed

| Seed | Profil S terpilih | Profil G terpilih | A benar | B benar |
|---|---|---|---:|---:|
| 1729 | S_EXTENDED | G_MUST_ONLY | 27/32 | 32/32 |
| 2027 | S_EXTENDED | G_BASIC | 26/32 | 30/32 |
| 4093 | S_EXTENDED | G_MUST_ONLY | 26/32 | 32/32 |

Untuk seed 2027, probe graf tidak memberikan alasan skor yang cukup untuk meninggalkan `G_BASIC`, sehingga B masih kehilangan dua soal akhir. Contoh ini menunjukkan keterbatasan *probe selection*, bukan kesuksesan universal.

## Reproduksi, pencatatan dan kontrol

- Hasil **30/30 tes** dari dua suite, yaitu 14 tes F1 dan 16 tes F2.
- Enam ledger lengkap, masing-masing 12 event `PROBE`, satu event `FREEZE`, dan 32 event `FINAL`: total 270 event yang tercatat dalam enam run.
- Event menggunakan hash berantai SHA-256, berisi ID eksperimen, seed, strategi, skor, hash input/output, panggilan model, biaya, dan estimasi waktu CPU eksekusi tugas.
- Verifikator memutar ulang respons dan skor terhadap generator deterministik; perubahan skor walaupun dengan hash yang dihitung ulang akan ditolak.
- Pengujian interupsi setelah event ditulis, sebelum checkpoint, dan pengujian *resume* tanpa duplikasi lulus.
- Batas biaya `max_cost_idr != 0` ditolak; waktu per run dibatasi 1800 detik; keterbatasan kontrol CPU/RAM host Colab dan penyimpanan lintas sesi tidak teruji.

## Batas-batas klaim

1. **Tidak ada AI model yang melatih diri atau menciptakan algoritma.** Program B memilih profil yang seluruh kodenya telah ditulis manusia sebelum eksperimen.
2. Soal probe merupakan bagian dari validasi F1 dan digunakan secara eksplisit untuk seleksi F2. Sisa validasi memakai template yang sama; jangan menganggap kenaikan skor ini sebagai peningkatan generalisasi struktural.
3. Kesamaan **12 pemanggilan evaluator** per kondisi tidak menyamakan total usaha manusia saat merancang katalog, prior pengetahuan, atau semua biaya komputasi. Pengukuran CPU tersedia di ledger dan bukan batas keadilan kausal yang lengkap.
4. Sumber F1 menampung oracle sebagai evaluasi; implementasi kandidat B tidak memanggil oracle tersebut. Runner memanggil evaluator hanya sesudah menghasilkan jawaban, dan loop adaptasi hanya menerima nilai skor.
5. *Held-out* F4 tidak dibuat ataupun diakses di pilot F2. Pengujian Colab milik pengguna dan penyimpanan lintas restart masih `NOT_RUN`.
6. Penelitian F3 mengenai pembuatan kandidat dan pewarisan antargenerasi masih `NOT_RUN`.

## Keputusan gerbang

**F2-Lokal: PASS** untuk pengujian rekayasa, seleksi strategi, evaluasi pasca-pembekuan, pencatatan, dan pemulihan.  
**F2-Colab pengguna: HOLD** sampai paket hasil reproduksi diterima dan diperiksa.  
**F3: HOLD**; dibutuhkan penelitian terpisah tentang pembuatan kandidat dengan kontrol isolasi yang memadai.
