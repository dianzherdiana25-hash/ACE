"""Twelve acceptance scenarios from ACE F1 Blueprint §10 + strict supplemental checks."""
import copy
import json
import shutil
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
import ace_f1 as h

class AcceptanceTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.root=Path(self.tmp.name)
    def tearDown(self): self.tmp.cleanup()

    def test_F1_T01_symbolic_reference_empty_duplicate(self):
        for tokens in ([],['a'],['a','a','b','a']):
            for operation in [{'op':'reverse'},{'op':'rotate_left','steps':12},
                              {'op':'filter_eq','value':'a'},{'op':'dedupe'},{'op':'swap_pairs'}]:
                result=h.interpret_s({'tokens':tokens,'operations':[operation]})
                self.assertIsInstance(result,list)
                self.assertEqual(result,h.interpret_s({'tokens':tokens,'operations':[operation]}))
        tasks=h.generate(h.SEEDS[0]); self.assertEqual(len(tasks),36)
        t=tasks[0];self.assertEqual(h.evaluate(t,h.a_fixed_solve(h.public_task(t)))['score'],1)

    def test_F1_T02_graph_oracle_ties_unreachable_zero(self):
        t=next(x for x in h.generate(h.SEEDS[0]) if x['family']=='G')
        t=copy.deepcopy(t)
        p={'kind':'graph','nodes':['A','B','C','D'],
           'edges':[['A','B',0],['A','C',0],['B','D',2],['C','D',2]],
           'directed':False,'start':'A','goal':'D'}
        t['problem']=p
        for candidate in [['A','B','D'],['A','C','D']]:
            o={'task_id':t['task_id'],'answer':{'path':candidate,'cost':2,'reachable':True}}
            self.assertEqual(h.evaluate(t,o)['status'],'PASS')
        p['edges']=[]
        o={'task_id':t['task_id'],'answer':{'path':[],'cost':None,'reachable':False}}
        self.assertEqual(h.evaluate(t,o)['status'],'PASS')
        self.assertFalse(h.oracle_graph(p)['reachable'])

    def test_F1_T03_invalid_output_schemas(self):
        t=h.generate(h.SEEDS[0])[0]
        for o in ({'answer':{'tokens':[]}}, {'task_id':t['task_id']},
                  {'task_id':t['task_id'],'answer':{'tokens':'a'}},
                  {'task_id':t['task_id'],'answer':{'tokens':[1]}},
                  {'task_id':t['task_id'],'answer':{'tokens':[],'extra':1}}):
            self.assertEqual(h.evaluate(t,o)['status'],'INVALID_OUTPUT')

    def test_F1_T04_repeatability_versions_seeds(self):
        for seed in h.SEEDS:
            t1=h.generate(seed);t2=h.generate(seed)
            self.assertEqual(h.digest(t1),h.digest(t2))
            x1=[h.a_fixed_solve(h.public_task(t)) for t in t1]
            x2=[h.a_fixed_solve(h.public_task(t)) for t in t2]
            self.assertEqual(h.digest(x1),h.digest(x2))
        self.assertNotEqual(h.digest(h.generate(h.SEEDS[0])),h.digest(h.generate(h.SEEDS[1])))

    def test_F1_T05_baseline_frozen_and_no_learn(self):
        before=h.provenance()['code_sha256']
        tasks=h.generate(h.SEEDS[0]);t=next(x for x in tasks if x['family']=='S')
        a=h.a_fixed_solve(h.public_task(t))
        for other in tasks:
            h.a_fixed_solve(h.public_task(other))
        self.assertEqual(a,h.a_fixed_solve(h.public_task(t)))
        self.assertEqual(before,h.provenance()['code_sha256'])
        self.assertFalse(any(k in h.public_task(t) for k in ('split','seed','template_id')))

    def test_F1_T06_heldout_api_denial_no_material(self):
        with self.assertRaises(h.AccessDenied):h.get_task('held-out',h.generate(h.SEEDS[0]))
        self.assertTrue(all(t['split']!='held-out' for t in h.generate(h.SEEDS[0])))
        with self.assertRaises(h.AccessDenied):
            h.validate_task_manifest([{'task_id':'G-HO-01','family':'G','split':'held-out','problem':{}}])

    def test_F1_T07_crash_after_event_before_checkpoint_idempotent_resume(self):
        with self.assertRaises(InterruptedError):
            h.run(h.SEEDS[0],self.root,simulate_stale_checkpoint=True)
        run_dir=self.root/'runs'/f'A_FIXED_{h.SEEDS[0]}'
        self.assertEqual(len(h.read_ledger(run_dir/'events.jsonl')),1)
        state=h.run(h.SEEDS[0],self.root)
        self.assertEqual(state['task_results'],36)
        rows=h.event_results(h.read_ledger(run_dir/'events.jsonl'))
        self.assertEqual(len(rows),len({r['task_id'] for r in rows}))
        before=(run_dir/'events.jsonl').read_bytes()
        h.run(h.SEEDS[0],self.root)
        self.assertEqual(before,(run_dir/'events.jsonl').read_bytes())

    def test_F1_T08_budget_and_wall_limits(self):
        with self.assertRaises(h.BudgetError):h.run(h.SEEDS[0],self.root,max_cost_idr=1)
        self.assertFalse((self.root/'runs').exists())
        with patch.object(h,'RUN_TIMEOUT_SECONDS',-1):
            with self.assertRaises(h.BudgetError):h.run(h.SEEDS[0],self.root)
        out=self.root/'runs'/f'A_FIXED_{h.SEEDS[0]}'
        self.assertFalse((out/'events.jsonl').exists())

    def test_F1_T09_invalid_manifest_and_evaluator_errors_fail_closed(self):
        tasks=h.generate(h.SEEDS[0])
        bad=copy.deepcopy(tasks);bad[0]['task_id']=bad[1]['task_id']
        with self.assertRaises(ValueError):h.validate_task_manifest(bad)
        bad=copy.deepcopy(tasks);bad[0]['template_id']=bad[12]['template_id']
        with self.assertRaises(ValueError):h.validate_task_manifest(bad)
        bad=copy.deepcopy(tasks[0]);bad['problem']['operations']=[{'op':'UNRECOGNIZED'}]
        with self.assertRaises(ValueError):h.evaluate(bad,{'task_id':bad['task_id'],'answer':{'tokens':[]}})

    def test_F1_T10_event_and_result_tampering_detected(self):
        h.run(h.SEEDS[0],self.root)
        folder=self.root/'runs'/f'A_FIXED_{h.SEEDS[0]}'
        f=folder/'events.jsonl';orig=f.read_bytes()
        f.write_bytes(orig.replace(b'A_FIXED',b'B_FIXED',1))
        with self.assertRaises(h.IntegrityError):h.verify_run(folder)
        f.write_bytes(orig)
        p=folder/'task_results.jsonl';text=p.read_text();p.write_text(text.replace('PASS','FAKE',1))
        with self.assertRaises(h.IntegrityError):h.verify_run(folder)

    def test_F1_T11_full_reconciliation_all_seeds(self):
        for seed in h.SEEDS:h.run(seed,self.root)
        rep=h.summarize(self.root)
        self.assertEqual(rep['total_task_attempts'],108)
        self.assertEqual(rep['held_out_attempts'],0)
        self.assertEqual(sum(x['total'] for x in rep['per_family_split'].values()),108)
        self.assertEqual(rep['total_pass'],sum(x['pass'] for x in rep['per_family_split'].values()))
        self.assertEqual(len(rep['runs']),3)
        self.assertTrue(all(x['complete'] for x in rep['runs']))

    def test_F1_T12_snapshot_export_portability_and_src_hash(self):
        h.run(h.SEEDS[0],self.root)
        folder=self.root/'runs'/f'A_FIXED_{h.SEEDS[0]}'
        self.assertTrue(h.verify_run(folder,require_complete=True)['complete'])
        destination=self.root/'migrated'
        shutil.copytree(folder,destination)
        self.assertEqual(h.verify_run(folder),h.verify_run(destination))
        cfg=h.read_json(folder/'config.snapshot.json')
        self.assertEqual(cfg['provenance']['code_sha256'],h.file_hash(Path(h.__file__)))
        self.assertEqual(cfg['provenance']['additional_cost_idr'],0)

    def test_supplement_heldout_type_mismatch_denial(self):
        with self.assertRaises(ValueError):h.get_task('foo',[])
        t=h.generate(h.SEEDS[0])[0]
        bad=h.public_task(t);bad['seed']=0
        with self.assertRaises(ValueError):h.a_fixed_solve(bad)

    def test_supplement_response_cost_recomputed_and_constraints(self):
        t=next(x for x in h.generate(h.SEEDS[0]) if x['template_id']=='G.must_visit.v1')
        bad=h.a_fixed_solve(h.public_task(t));bad['answer']['cost']=9999
        self.assertNotEqual(h.evaluate(t,bad)['status'],'PASS')
        q=copy.deepcopy(t)
        q['problem']['max_hops']=1
        q['problem'].pop('must_visit')
        x={'task_id':q['task_id'],'answer':{'path':['A','B','E'],'cost':2,'reachable':True}}
        self.assertEqual(h.evaluate(q,x)['status'],'INCORRECT')

if __name__=='__main__':unittest.main(verbosity=2)
