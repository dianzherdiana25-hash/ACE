"""ACE F1 deterministic fixed baseline harness (stdlib only).

Scope: trusted hand-authored algorithms on development/validation fixtures only.
Held-out tasks deliberately do not exist in this package.
"""
from __future__ import annotations

import argparse
import hashlib
import heapq
import json
import os
import random
import shutil
import sys
import tempfile
import time
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

BENCHMARK_VERSION = 'ace-bench-0.1.0'
SOLVER_VERSION = 'A-fixed-0.1.0'
EVALUATOR_VERSION = 'ace-evaluator-0.1.0'
STUDY_ID = 'ACE-F1-20261104'
SEEDS = (1729, 2027, 4093)
RUN_TIMEOUT_SECONDS = 1800
ALLOW_PAID = False
SYMBOLIC_DEV = ('reverse', 'rotate_left', 'filter_eq', 'compose')
SYMBOLIC_VAL = ('dedupe', 'swap_pairs')
GRAPH_DEV = ('weighted_undirected', 'weighted_directed', 'grid_shortest')
GRAPH_VAL = ('must_visit', 'max_hops')

class IntegrityError(RuntimeError):
    pass

class BudgetError(RuntimeError):
    pass

class AccessDenied(PermissionError):
    pass


def canonical(obj):
    return json.dumps(obj, sort_keys=True, ensure_ascii=False, separators=(',', ':'), allow_nan=False)


def digest(obj):
    if isinstance(obj, bytes):
        b = obj
    elif isinstance(obj, str):
        b = obj.encode('utf8')
    else:
        b = canonical(obj).encode('utf8')
    return hashlib.sha256(b).hexdigest()


def atomic_json(path: Path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name('.' + path.name + '.tmp')
    try:
        with open(tmp, 'w', encoding='utf8') as f:
            f.write(canonical(obj) + '\n')
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, path)
    finally:
        if tmp.exists():
            tmp.unlink()


def read_json(path):
    with open(path, encoding='utf8') as f:
        return json.load(f)


def file_hash(path: Path):
    return digest(path.read_bytes())


def _rand(seed, family, split, ordinal):
    return random.Random(int(digest(f'{seed}|{family}|{split}|{ordinal}')[:16], 16))


def _task(family, split, ordinal, template, problem, answer_format, seed):
    part = {'development': 'DEV', 'validation': 'VAL'}[split]
    return {
        'task_id': f'{family}-{part}-{ordinal:04d}', 'family': family,
        'split': split, 'template_id': f'{family}.{template}.v1',
        'benchmark_version': BENCHMARK_VERSION, 'seed': seed,
        'problem': problem, 'answer_format': answer_format,
        'limits': {'max_output_items': 64, 'max_path_length': 32}
    }


def generate(seed):
    """Generate 12 development + 6 validation IDs *per family*, held-out untouched."""
    tasks = []
    token_pool = list('aabcde')
    for split, templates, count_per in [('development', SYMBOLIC_DEV, 3), ('validation', SYMBOLIC_VAL, 3)]:
        for k, template in enumerate(templates):
            for j in range(count_per):
                ordinal = k * count_per + j + 1
                rng = _rand(seed, 'S', split, ordinal)
                tokens = [rng.choice(token_pool) for _ in range(rng.randint(0, 9))]
                if template == 'reverse': ops = [{'op': 'reverse'}]
                elif template == 'rotate_left': ops = [{'op': 'rotate_left', 'steps': rng.randint(0, 14)}]
                elif template == 'filter_eq': ops = [{'op': 'filter_eq', 'value': rng.choice(token_pool)}]
                elif template == 'compose': ops = [{'op': 'reverse'}, {'op': 'rotate_left', 'steps': rng.randint(0, 14)}]
                elif template == 'dedupe': ops = [{'op': 'dedupe'}]
                elif template == 'swap_pairs': ops = [{'op': 'swap_pairs'}]
                else: raise AssertionError(template)
                tasks.append(_task('S', split, ordinal, template,
                    {'tokens': tokens, 'operations': ops}, 'tokens_array', seed))
    for split, templates, count_per in [('development', GRAPH_DEV, 4), ('validation', GRAPH_VAL, 3)]:
        for k, template in enumerate(templates):
            for j in range(count_per):
                ordinal = k * count_per + j + 1
                rng = _rand(seed, 'G', split, ordinal)
                if template == 'grid_shortest':
                    blocked = [[1, 1], [2, 1]] if j % 2 == 0 else [[1, 2], [2, 2]]
                    problem = {'kind': 'grid', 'rows': 4, 'cols': 4, 'blocked': blocked,
                               'start': [0, 0], 'goal': [3, 3]}
                else:
                    names = ['A', 'B', 'C', 'D', 'E']
                    edges = [
                        ['A', 'B', rng.randint(0, 3)],
                        ['B', 'E', rng.randint(1, 5)],
                        ['A', 'C', rng.randint(1, 3)],
                        ['C', 'D', rng.randint(0, 3)],
                        ['D', 'E', rng.randint(1, 3)],
                        ['B', 'C', rng.randint(1, 4)],
                    ]
                    if template == 'weighted_directed':
                        edges += [['C', 'E', rng.randint(2, 7)]]
                    problem = {'kind': 'graph', 'nodes': names, 'edges': edges,
                               'directed': template == 'weighted_directed',
                               'start': 'A', 'goal': 'E'}
                    if template == 'must_visit': problem['must_visit'] = 'D'
                    elif template == 'max_hops': problem['max_hops'] = 2
                tasks.append(_task('G', split, ordinal, template, problem,
                                   'path_with_cost', seed))
    validate_task_manifest(tasks)
    return tasks


def validate_task_manifest(tasks):
    ids = set()
    for t in tasks:
        if t['task_id'] in ids: raise ValueError('duplicate task ID')
        ids.add(t['task_id'])
        if t['split'] not in ('development', 'validation'):
            raise AccessDenied('held-out split cannot be generated in F1')
        if t['family'] not in ('S', 'G') or not isinstance(t['problem'], dict):
            raise ValueError('invalid task')
    expected = {('S', 'development'): 12, ('S', 'validation'): 6,
                ('G', 'development'): 12, ('G', 'validation'): 6}
    actual = Counter((t['family'], t['split']) for t in tasks)
    if actual != expected: raise ValueError(f'manifest counts: {actual}')
    for fam in ('S', 'G'):
        dev = {t['template_id'] for t in tasks if t['family']==fam and t['split']=='development'}
        val = {t['template_id'] for t in tasks if t['family']==fam and t['split']=='validation'}
        if not dev.isdisjoint(val): raise ValueError('template leakage')
    return True


def public_task(t):
    # Transfer through JSON to prevent mutation of private task structure.
    return json.loads(canonical({k: t[k] for k in ('task_id', 'family', 'problem', 'answer_format', 'limits')}))


def get_task(split, tasks):
    if split == 'held-out': raise AccessDenied('F4-only: held-out is not present in F1')
    if split not in ('development', 'validation'): raise ValueError('unknown split')
    return [public_task(t) for t in tasks if t['split']==split]


def interpret_s(problem, supported=None):
    tokens = problem['tokens'][:]
    if not isinstance(tokens, list) or not all(isinstance(x, str) for x in tokens):
        raise ValueError('tokens must be strings')
    for op in problem['operations']:
        name = op['op']
        if supported is not None and name not in supported:
            return None
        if name == 'reverse': tokens = tokens[::-1]
        elif name == 'rotate_left':
            s = op['steps'] % len(tokens) if tokens else 0
            tokens = tokens[s:] + tokens[:s]
        elif name == 'filter_eq': tokens = [x for x in tokens if x == op['value']]
        elif name == 'dedupe': tokens = list(dict.fromkeys(tokens))
        elif name == 'swap_pairs':
            for i in range(0, len(tokens)-1, 2): tokens[i], tokens[i+1] = tokens[i+1], tokens[i]
        else: raise ValueError('unknown operation')
    return tokens


def to_graph(problem):
    if problem['kind'] == 'grid':
        rows, cols = problem['rows'], problem['cols']
        blocked = {tuple(x) for x in problem['blocked']}
        nodes = {(r,c) for r in range(rows) for c in range(cols) if (r,c) not in blocked}
        edges = []
        for r,c in sorted(nodes):
            for dr,dc in ((0,1),(1,0)):
                target = (r+dr,c+dc)
                if target in nodes: edges.append(((r,c),target,1))
        return nodes, edges, False, tuple(problem['start']), tuple(problem['goal'])
    nodes = set(problem['nodes'])
    edges = [(a,b,w) for a,b,w in problem['edges']]
    if any(w < 0 for a,b,w in edges): raise ValueError('negative cost not supported')
    if any(a not in nodes or b not in nodes for a,b,w in edges): raise ValueError('dangling edge')
    return nodes, edges, bool(problem['directed']), problem['start'], problem['goal']


def neighbors(problem):
    nodes, edges, directed, start, goal = to_graph(problem)
    graph = {v: [] for v in nodes}
    for a,b,w in edges:
        graph[a].append((b,w))
        if not directed: graph[b].append((a,w))
    for k in graph: graph[k].sort(key=lambda p: (str(p[0]),p[1]))
    return graph,start,goal


def oracle_graph(problem):
    """Independent exhaustive simple-path reference for small fixed-size fixtures."""
    graph,start,goal = neighbors(problem)
    must = problem.get('must_visit')
    max_hops = problem.get('max_hops')
    solutions=[]
    stack=[(start,[start],0)]
    while stack:
        u,path,cost=stack.pop()
        if u==goal:
            if (must is None or must in path) and (max_hops is None or len(path)-1 <= max_hops):
                solutions.append((cost,path))
            continue
        if max_hops is not None and len(path)-1 >= max_hops: continue
        for v,w in graph[u]:
            if v not in path: stack.append((v,path+[v],cost+w))
    if not solutions: return {'reachable':False,'cost':None,'path':[]}
    cost,path=min(solutions,key=lambda v: (v[0],tuple(map(str,v[1]))))
    def present(v): return list(v) if isinstance(v,tuple) else v
    return {'reachable':True,'cost':cost,'path':[present(v) for v in path]}


def baseline_shortest(problem):
    """Frozen generic Dijkstra; deliberately has no constrained-path module."""
    graph,start,goal=neighbors(problem)
    pq=[(0,0,start,[start])]
    best={start:0}
    step=0
    while pq:
        cost,_,node,path=heapq.heappop(pq)
        if cost>best[node]: continue
        if node==goal:
            p=[list(v) if isinstance(v,tuple) else v for v in path]
            return {'path':p,'cost':cost,'reachable':True}
        for other,w in graph[node]:
            new_cost=cost+w
            if new_cost<best.get(other,float('inf')):
                best[other]=new_cost
                step+=1;heapq.heappush(pq,(new_cost,step,other,path+[other]))
    return {'path':[],'cost':None,'reachable':False}


def a_fixed_solve(task):
    if set(task.keys()) != {'task_id','family','problem','answer_format','limits'}:
        raise ValueError('private metadata may not be sent to candidate')
    if task['family']=='S':
        out=interpret_s(task['problem'],supported={'reverse','rotate_left','filter_eq'})
        if out is None: return {'task_id':task['task_id'],'answer':None,'declared_status':'UNSUPPORTED'}
        return {'task_id':task['task_id'],'answer':{'tokens':out}}
    if task['family']=='G':
        return {'task_id':task['task_id'],'answer':baseline_shortest(task['problem'])}
    return {'task_id':task['task_id'],'answer':None,'declared_status':'UNSUPPORTED'}


def evaluate(t, response):
    if not isinstance(response,dict) or response.get('task_id')!=t['task_id']:
        return {'status':'INVALID_OUTPUT','reason':'missing/wrong task id','score':0}
    if response.get('declared_status')=='UNSUPPORTED' and response.get('answer') is None:
        return {'status':'INCORRECT','reason':'baseline unsupported task','score':0}
    ans=response.get('answer')
    if not isinstance(ans,dict):
        return {'status':'INVALID_OUTPUT','reason':'answer must be object','score':0}
    if t['family']=='S':
        toks=ans.get('tokens')
        if set(ans.keys()) != {'tokens'} or not isinstance(toks,list) or not all(isinstance(x,str) for x in toks):
            return {'status':'INVALID_OUTPUT','reason':'tokens must be list[str]','score':0}
        if len(toks)>t['limits']['max_output_items']:
            return {'status':'INVALID_OUTPUT','reason':'output too long','score':0}
        expected=interpret_s(t['problem'])
        good=toks==expected
        return {'status':'PASS' if good else 'INCORRECT','reason':'match' if good else 'wrong token sequence','score':int(good)}
    p=t['problem']
    oracle=oracle_graph(p)
    path=ans.get('path');cost=ans.get('cost');reach=ans.get('reachable')
    if set(ans.keys()) != {'path','cost','reachable'} or not isinstance(path,list) or not isinstance(reach,bool):
        return {'status':'INVALID_OUTPUT','reason':'path/cost/reachable schema','score':0}
    if len(path)>t['limits']['max_path_length']:
        return {'status':'INVALID_OUTPUT','reason':'path too long','score':0}
    if not reach:
        if path != [] or cost is not None:
            return {'status':'INVALID_OUTPUT','reason':'unreachable format','score':0}
        ok=not oracle['reachable']
        return {'status':'PASS' if ok else 'INCORRECT','reason':'unreachable correctness','score':int(ok)}
    if not isinstance(cost,int) or isinstance(cost,bool) or not path:
        return {'status':'INVALID_OUTPUT','reason':'cost/path types','score':0}
    graph,start,goal=neighbors(p)
    try:
        conv=[tuple(v) if isinstance(v,list) else v for v in path]
        if any(v not in graph for v in conv): raise ValueError('unknown node')
        if conv[0]!=start or conv[-1]!=goal: raise ValueError('endpoints')
        if len(conv)!=len(set(conv)): raise ValueError('non-simple path')
        if p.get('max_hops') is not None and len(conv)-1>p['max_hops']:
            raise ValueError('max_hops violated')
        if p.get('must_visit') is not None and p['must_visit'] not in conv:
            raise ValueError('must_visit violated')
        possible={0}
        for u,v in zip(conv,conv[1:]):
            weights=[w for n,w in graph[u] if n==v]
            if not weights: raise ValueError('invalid edge')
            possible={a+b for a in possible for b in weights}
        if cost not in possible: raise ValueError('wrong reported cost')
        good=oracle['reachable'] and cost==oracle['cost']
        return {'status':'PASS' if good else 'INCORRECT','reason':'optimal' if good else 'nonoptimal','score':int(good)}
    except (ValueError,TypeError,KeyError):
        return {'status':'INCORRECT','reason':'invalid/constraint-violating path','score':0}


def provenance():
    script=Path(__file__)
    return {'solver_version':SOLVER_VERSION,'evaluator_version':EVALUATOR_VERSION,
            'benchmark_version':BENCHMARK_VERSION, 'code_sha256':file_hash(script),
            'allow_paid':ALLOW_PAID,'model_calls':0,'additional_cost_idr':0}


def config(seed,run_id):
    return {'study_id':STUDY_ID,'run_id':run_id,'mode':'A_FIXED',
            'seed':seed,'splits':['development','validation'],'provenance':provenance(),
            'per_run_wall_seconds':RUN_TIMEOUT_SECONDS,'max_tasks':36,'max_cost_idr':0,
            'held_out_access':'DENIED_F1','status':'F1_BASELINE'}


def event_hash(ev):
    return digest({k:v for k,v in ev.items() if k!='event_hash'})


def read_ledger(path):
    events=[]
    if not path.exists(): return events
    prior='0'*64
    with path.open(encoding='utf8') as f:
        for line in f:
            if not line.strip(): continue
            try: ev=json.loads(line)
            except json.JSONDecodeError as e: raise IntegrityError(f'corrupt ledger JSON: {e}')
            if ev.get('previous_hash') != prior or ev.get('event_hash') != event_hash(ev):
                raise IntegrityError('ledger hash-chain broken')
            if ev.get('event_id') != len(events)+1:
                raise IntegrityError('ledger event order broken')
            prior=ev['event_hash']; events.append(ev)
    return events


def write_event(path,ev):
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('a',encoding='utf8') as f:
        f.write(canonical(ev)+'\n'); f.flush();os.fsync(f.fileno())


def event_results(events):
    results=[]; keys=set()
    for ev in events:
        if ev['action']!='TASK_RESULT': continue
        row=ev['result']
        key=(row['seed'],row['task_id'],row['split'])
        if key in keys: raise IntegrityError('duplicate result in ledger')
        keys.add(key);results.append(row)
    return results


def project_results(path,events):
    expected=[canonical(row) for row in event_results(events)]
    if path.exists():
        actual=[line.rstrip('\n') for line in path.read_text(encoding='utf8').splitlines() if line.strip()]
        if actual != expected[:len(actual)]:
            raise IntegrityError('result projection differs from ledger')
        # A killed process may have committed an event but not yet materialized its projection.
        if len(actual) < len(expected):
            with path.open('a', encoding='utf8') as f:
                for x in expected[len(actual):]: f.write(x+'\n')
                f.flush(); os.fsync(f.fileno())
    else:
        path.write_text(''.join(x+'\n' for x in expected),encoding='utf8')
    return len(expected)


def save_checkpoint(path,run_id,config_sha,events,count,completed=False):
    atomic_json(path,{'run_id':run_id,'config_sha256':config_sha,
        'last_committed_event_id':len(events),'ledger_sha256':events[-1]['event_hash'] if events else '0'*64,
        'completed_tasks':count, 'next_task_index':count,'status':'COMPLETED' if completed else 'CHECKPOINTED',
        'updated_at_utc':datetime.now(timezone.utc).isoformat()})


def verify_run(run_dir, require_complete=False):
    run_dir=Path(run_dir)
    cfg=read_json(run_dir/'config.snapshot.json')
    # Ensure source is unchanged in current runner; exports are verified separately with SHA256SUMS.
    if cfg['provenance']['code_sha256'] != file_hash(Path(__file__)):
        raise IntegrityError('frozen source code sha mismatch')
    evs=read_ledger(run_dir/'events.jsonl')
    if any(e.get('config_sha256') != digest(cfg) for e in evs): raise IntegrityError('config mismatch')
    if any(e.get('solver_sha256') != cfg['provenance']['code_sha256'] for e in evs):
        raise IntegrityError('solver mismatch')
    rows=event_results(evs)
    if (run_dir/'task_results.jsonl').exists():
        project_results(run_dir/'task_results.jsonl',evs)
    manifest=generate(cfg['seed'])
    by_id={t['task_id']:t for t in manifest}
    for row in rows:
        t=by_id[row['task_id']]
        if row['task_sha256'] != digest(t):raise IntegrityError('task fingerprint mismatch')
        if row['split'] != t['split'] or row['family']!=t['family']:raise IntegrityError('task split mismatch')
        if digest(row['response']) != row['response_sha256']:raise IntegrityError('response mismatch')
        expected=evaluate(t,row['response'])
        if expected != row['evaluation']:raise IntegrityError('score mismatch')
    chk=read_json(run_dir/'checkpoint.json') if (run_dir/'checkpoint.json').exists() else None
    if chk and (chk['config_sha256']!=digest(cfg) or chk['last_committed_event_id']>len(evs)):
        raise IntegrityError('checkpoint references incompatible config/future')
    if chk and chk['last_committed_event_id'] and chk['ledger_sha256'] != evs[chk['last_committed_event_id']-1]['event_hash']:
        raise IntegrityError('checkpoint mismatches ledger')
    if require_complete and (len(rows)!=len(manifest) or not chk or chk['status']!='COMPLETED'):
        raise IntegrityError('incomplete run')
    if len(rows)>len(manifest): raise IntegrityError('too many results')
    return {'run_id':cfg['run_id'],'seed':cfg['seed'],'task_results':len(rows),
        'expected':len(manifest),'event_count':len(evs), 'ledger_head':evs[-1]['event_hash'] if evs else '0'*64,
        'complete':len(rows)==len(manifest) and bool(chk) and chk['status']=='COMPLETED'}


def run(seed,root,run_id=None,stop_after=None,simulate_stale_checkpoint=False,max_cost_idr=0):
    if max_cost_idr != 0 or ALLOW_PAID: raise BudgetError('additional cost must be zero')
    if seed not in SEEDS: raise ValueError('seed is not preregistered')
    rid=run_id or f'A_FIXED_{seed}'
    out=Path(root)/'runs'/rid
    out.mkdir(parents=True,exist_ok=True)
    conf=config(seed,rid)
    config_path=out/'config.snapshot.json'
    if config_path.exists():
        if read_json(config_path)!=conf: raise IntegrityError('resume config changed')
    else: atomic_json(config_path,conf)
    config_sha=digest(conf)
    tasks=generate(seed)
    evs=read_ledger(out/'events.jsonl')
    project_results(out/'task_results.jsonl',evs)
    if (out/'checkpoint.json').exists():
        # Verify checkpoint against a prefix of ledger, allowing crash after event fsync before checkpoint.
        verify_run(out)
    done={x['task_id'] for x in event_results(evs)}
    started=time.monotonic()
    completed_now=0
    for t in tasks:
        if t['task_id'] in done: continue
        if stop_after is not None and completed_now >= stop_after: break
        if time.monotonic()-started>RUN_TIMEOUT_SECONDS: raise BudgetError('wall-time cap reached')
        begin=time.monotonic(); cpu_begin=time.process_time()
        response=a_fixed_solve(public_task(t))
        verdict=evaluate(t,response)
        elapsed=round((time.monotonic()-begin)*1000,6)
        cpu=round(time.process_time()-cpu_begin,9)
        row={'task_id':t['task_id'],'family':t['family'],'split':t['split'],'seed':seed,
             'task_sha256':digest(t),'response':response,'response_sha256':digest(response),
             'evaluation':verdict,'elapsed_ms':elapsed,'cpu_seconds':cpu}
        ev={'event_id':len(evs)+1,'timestamp_utc':datetime.now(timezone.utc).isoformat(),
            'study_id':STUDY_ID,'run_id':rid,'mode':'A_FIXED','phase':'F1','seed':seed,
            'candidate_id':SOLVER_VERSION,'parent_id':None,'action':'TASK_RESULT',
            'outcome':verdict['status'],'artifact_sha256':digest(row),
            'evaluator_version':EVALUATOR_VERSION,'solver_sha256':conf['provenance']['code_sha256'],
            'config_sha256':config_sha, 'cpu_seconds':cpu,'model_calls':0,
            'input_tokens':0,'output_tokens':0,'additional_cost_idr':0,
            'error_code':None if verdict['score'] else verdict['status'],
            'task_id':t['task_id'],'family':t['family'],'split':t['split'],
            'result':row,'previous_hash':evs[-1]['event_hash'] if evs else '0'*64}
        ev['event_hash']=event_hash(ev)
        write_event(out/'events.jsonl',ev)
        evs.append(ev); completed_now+=1
        # Test hook: an interrupted process after durable event, before updating checkpoint.
        if simulate_stale_checkpoint and completed_now==1:
            raise InterruptedError('injected interruption after event commit')
        project_results_file=out/'task_results.jsonl'
        with project_results_file.open('a',encoding='utf8') as f:
            f.write(canonical(row)+'\n');f.flush();os.fsync(f.fileno())
        save_checkpoint(out/'checkpoint.json',rid,config_sha,evs,len(event_results(evs)))
    n=len(event_results(evs))
    finished=n==len(tasks)
    save_checkpoint(out/'checkpoint.json',rid,config_sha,evs,n,completed=finished)
    check=verify_run(out,require_complete=finished)
    return check


def summarize(root):
    root=Path(root)
    reports=[]; allrows=[]
    for seed in SEEDS:
        run_dir=root/'runs'/f'A_FIXED_{seed}'
        verified=verify_run(run_dir,require_complete=True)
        ev=read_ledger(run_dir/'events.jsonl')
        rows=event_results(ev)
        reports.append(verified);allrows.extend(rows)
    counts={}
    for family in ('S','G'):
        for split in ('development','validation'):
            sub=[x for x in allrows if x['family']==family and x['split']==split]
            passed=sum(x['evaluation']['score'] for x in sub)
            counts[f'{family}_{split}']={'pass':passed,'total':len(sub),'success_rate':passed/len(sub) if sub else None,
             'status_counts':dict(Counter(x['evaluation']['status'] for x in sub))}
    report={'study_id':STUDY_ID,'phase':'F1','mode':'A_FIXED',
        'engineering_note':'F1 fixed-solver baseline: not an AI learning/evolution experiment',
        'research_hypothesis':'NOT_TESTED', 'seeds':list(SEEDS),
        'task_ids_per_seed':36,'total_task_attempts':len(allrows),
        'held_out_attempts':0,'held_out_task_data':'NOT_GENERATED',
        'model_calls':0,'additional_cost_idr':0,
        'per_family_split':counts,
        'total_pass':sum(x['evaluation']['score'] for x in allrows),
        'runs':reports,'versions':provenance()}
    root.joinpath('reports').mkdir(parents=True,exist_ok=True)
    atomic_json(root/'reports'/'metrics.json',report)
    s=['# ACE F1 — Baseline A: actual execution results','',
       'Mode: `A_FIXED` (frozen deterministic solver, no model/API).',
       'Research hypothesis: **NOT_TESTED**. Held-out: **NOT GENERATED / NOT ACCESSED**.','',
       f"- 3 preregistered seeds: {', '.join(map(str,SEEDS))}",
       f"- Task IDs per seed: 36 (S:12 dev+6 validation, G:12 dev+6 validation)",
       f"- Attempts: {len(allrows)}, passes: {report['total_pass']}",
       '- External API/model calls: 0; additional service charge incurred by harness: Rp0', '',
       '| Family/split | PASS | Total | Success |','|---|---:|---:|---:|']
    for key,x in counts.items():
        s.append(f"| {key} | {x['pass']} | {x['total']} | {x['success_rate']:.1%} |")
    s.extend(['','No AGI, autonomous evolution, cross-task transfer, or held-out generalization claim is supported.',
     'Scores may be high on development because A implements the three familiar S operations and standard Dijkstra. Validation templates are disjoint from development; they remain internal validation, not sealed F4 held-out.',
     'A is a deterministic hand-coded algorithm; future B/C comparisons require matching initial algorithm/model and bounded candidate budgets.',
     'Persistence across Colab restarts and isolation for untrusted generated code have NOT been demonstrated.'])
    (root/'reports'/'summary.id.md').write_text('\n'.join(s)+'\n',encoding='utf8')
    return report


def clean_smoke(root):
    root=Path(root)
    if root.exists():shutil.rmtree(root)
    for s in SEEDS:run(s,root)
    summarize(root)
    return root


def main():
    ap=argparse.ArgumentParser(description='ACE F1 trusted deterministic fixed baseline')
    ap.add_argument('command',choices=('run','verify','summary'))
    ap.add_argument('--root',default='ace_f1_evidence')
    ap.add_argument('--seed',type=int,choices=SEEDS)
    ap.add_argument('--stop-after',type=int)
    ap.add_argument('--max-cost-idr',type=int,default=0)
    a=ap.parse_args()
    if a.command=='run':
        seeds=[a.seed] if a.seed else SEEDS
        for seed in seeds: print(canonical(run(seed,a.root,stop_after=a.stop_after,max_cost_idr=a.max_cost_idr)))
    elif a.command=='verify':
        for seed in ([a.seed] if a.seed else SEEDS):print(canonical(verify_run(Path(a.root)/'runs'/f'A_FIXED_{seed}',require_complete=True)))
    else:print(canonical(summarize(a.root)))

if __name__=='__main__':main()
