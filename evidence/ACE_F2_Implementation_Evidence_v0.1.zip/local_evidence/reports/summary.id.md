# ACE F2 — Local adaptive-catalog experiment

**Research inference:** strategy-selection pilot only; not autonomous AI evolution.

- 6 complete run ledgers; 12 scorer probes + 32 frozen final evaluations per seed and condition.
- F4 held-out tasks never generated; no paid APIs; no dynamically generated source execution.

| Mode / family / split | Correct | Total | Rate |
|---|---:|---:|---:|
| A_CONTROL_S_development | 36 | 36 | 100.0% |
| A_CONTROL_S_validation | 0 | 12 | 0.0% |
| A_CONTROL_G_development | 36 | 36 | 100.0% |
| A_CONTROL_G_validation | 7 | 12 | 58.3% |
| B_ADAPT_S_development | 36 | 36 | 100.0% |
| B_ADAPT_S_validation | 12 | 12 | 100.0% |
| B_ADAPT_G_development | 36 | 36 | 100.0% |
| B_ADAPT_G_validation | 10 | 12 | 83.3% |

**Design caution:** each seed reuses 1 validation example/template as adaptation probe, with 2 remaining examples/template as post-freeze tests. They are not unseen templates.

B selects between fixed handwritten profiles based only on probe `score` and never sees reference solutions. No claims about intelligence generalization or successor agents.
