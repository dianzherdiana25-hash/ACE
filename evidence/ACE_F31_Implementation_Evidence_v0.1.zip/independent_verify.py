"""A second scoring path, independent of the run writer's scoring function.
Validates recorded decisions and test cases using independently implemented DSL
and exhaustive graph paths; does not claim external signoff or prove AGI.
"""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import ace_f31 as study

def sym(t,mask):
    x=t['tokens'].copy()
    if mask%2:
        out=[]
        for value in x:
            if value not in out:out.append(value)
        x=out
    if mask//2%2:x=sum(([x[i+1],x[i]] if i+1<len(x) else [x[i:][0]] for i in range(0,len(x),2)),[])
    if mask//4%2 and x:x=x[1:]+x[:1]
    if mask//8%2:x=list(reversed(x))
    return x

def graph(t,mask):
    adj={node:[] for node in t['nodes']}
    for u,v,w in t['edges']:
        adj[u].append((v,w));adj[v].append((u,w))
    paths=[]
    def walk(node,visited,cost):
        if node=='T':
            if mask&1 and 'C' not in visited:return
            if mask&2 and len(visited)-1>2:return
            if mask&8 and 'B' in visited:return
            paths.append((visited.copy(),cost));return
        for v,w in adj[node]:
            if v in visited:continue
            if mask&2 and len(visited)>=3:continue
            walk(v,visited+[v],cost+w)
    walk('S',['S'],0)
    if not paths:return {'reachable':False,'path':[],'cost':None}
    if mask&4:path,cost=min(paths,key=lambda x:(len(x[0])-1,x[1],tuple(x[0])))
    else:path,cost=min(paths,key=lambda x:(x[1],len(x[0])-1,tuple(x[0])))
    return {'reachable':True,'path':path,'cost':cost}

def score(t,fam,mask):return sym(t,mask) if fam=='S' else graph(t,mask)

def check(root):
    root=Path(root)
    records=[]; candidates=0;probes=0;disagreements=0
    for seed in study.SEEDS:
        for fam in study.FAMILIES:
            train=[study.generate_example(seed,fam,'probe',i) for i in range(study.TRAIN_EXAMPLES)]
            test=[study.generate_example(seed,fam,'within_template_test',i) for i in range(study.TEST_EXAMPLES)]
            target=study.hidden_target(seed,fam)
            for mode in study.MODES:
                assert study.verify(root,seed,fam,mode,complete=True)['complete']
                evs=[e['payload'] for e in study.load_events(study.run_dir(root,seed,fam,mode)/'events.jsonl')]
                cands=[x['candidate'] for x in evs if x['action']=='CANDIDATE']
                assert len(cands)==study.CANDIDATES
                ids={x['candidate_id'] for x in cands}
                for c in cands:
                    assert c['parent_id'] is None or c['parent_id'] in ids
                    for i,task in enumerate(train):
                        a=score(task,fam,c['genome']);b=score(task,fam,target)
                        r=study.fitness(a,b,fam)
                        assert r==c['probe_rewards'][i]
                        probes+=1
                    candidates+=1
                expected=max(cands,key=lambda c:(c['mean_reward'],-c['generation'])) if mode!='BLIND_LAST' else cands[-1]
                selected=next(x for x in evs if x['action']=='FREEZE')
                assert selected['genome']==expected['genome']
                assert selected['candidate_id']==expected['candidate_id']
                observed=next(x['evaluation'] for x in evs if x['action']=='FINAL')
                scores=[int(score(task,fam,target)==score(task,fam,selected['genome'])) for task in test]
                assert observed['case_scores']==scores
                assert observed['correct']==sum(scores)
                records.append({'seed':seed,'family':fam,'mode':mode,'correct':sum(scores)})
    totals={mode:sum(x['correct'] for x in records if x['mode']==mode) for mode in study.MODES}
    old=study.read_json(root/'reports'/'results.json')
    for mode,correct in totals.items():assert old['score'][mode]['correct']==correct
    return {'verdict':'PASS','runs_verified':len(records),'candidates_verified':candidates,
            'scalar_probe_rewards_verified':probes,'totals':totals,'heldout_f4':'NOT_GENERATED'}

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--root',default='evidence');a=p.parse_args()
    print(json.dumps(check(a.root),sort_keys=True))
