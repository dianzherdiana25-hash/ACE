"""Self-contained, offline CPU replication runner for Colab or Python 3.10+."""
import hashlib, os, subprocess, sys, zipfile
from pathlib import Path

ROOT=Path(__file__).resolve().parent
os.chdir(ROOT)
steps=[
    ('unit_tests',[sys.executable,'-m','unittest','-v','test_f31']),
    ('experiment',[sys.executable,'ace_f31.py','all','--root','evidence']),
    ('semantic_verify',[sys.executable,'ace_f31.py','verify','--root','evidence']),
    ('independent_verify',[sys.executable,'independent_verify.py','--root','evidence'])]
for name,cmd in steps:
    print('RUN',name,flush=True)
    output=subprocess.run(cmd,check=True,cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
    (ROOT/(name+'.log')).write_text(output.stdout,encoding='utf8')
    print(output.stdout[-1200:],flush=True)
output_path=ROOT/'ACE_F31_reproduced_evidence.zip'
with zipfile.ZipFile(output_path,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=8) as z:
    for name in ('ace_f31.py','test_f31.py','independent_verify.py','run_colab.py','README.md',
                 'unit_tests.log','experiment.log','semantic_verify.log','independent_verify.log'):
        p=ROOT/name
        if p.exists():z.write(p,arcname=name)
    for p in sorted((ROOT/'evidence').rglob('*')):
        if p.is_file():z.write(p,arcname=str(p.relative_to(ROOT)))
print('REPLICATION_PASS',output_path,'BYTES',output_path.stat().st_size,'SHA256',
      hashlib.sha256(output_path.read_bytes()).hexdigest(),flush=True)
try:
    from google.colab import files
    files.download(str(output_path))
except ImportError:
    pass
