# ACE F3.1 — Feedback-Directed Search

Status: **eksperimen lokal eksploratoris selesai; keunggulan pencarian berbasis umpan balik BELUM TERBUKTI.**

Penelitian ini mengganti jalur mutasi F3 yang telah ditentukan sebelumnya dengan pemilihan induk berbasis skor dari probe pada `GUIDED_BEST`, dibanding kontrol `BLIND_BEST` yang membuat kandidat tanpa memakai skor namun tetap memilih kandidat akhir terbaik, dan kontrol tambahan `BLIND_LAST`.

- 24 seed x 2 keluarga masalah (symbolic S, graph G) x 3 kebijakan = 144 run.
- Setiap run: 10 kandidat x 5 probe = 50 evaluasi feedback; 24 pengujian pasca-pembekuan (dengan contoh baru tetapi grammar *sama*).
- Seluruh gene dan interpreter adalah rancangan manusia, tanpa LLM/API berbayar, hanya Python standard library.
- Tidak ada bank *held-out* F4 yang dibuat, dibuka, atau dinilai.
- Rancangan ini adalah eksplorasi mekanisme kausal, **bukan** pembuktian evolusi AI yang otonom atau generalisasi lintas paradigma.

## Hasil

| Kebijakan | Jawaban benar | Rate |
|---|---:|---:|
| `GUIDED_BEST` | 958/1152 | 83.16% |
| `BLIND_BEST` | 966/1152 | 83.85% |
| `BLIND_LAST` | 315/1152 | 27.34% |

Gap yang relevan untuk manfaat _arah mutasi_ adalah `GUIDED_BEST - BLIND_BEST = -0.694 poin persentase`. Rentang bootstrap cluster 95% sekitar [-13.889, 13.108] poin: tidak ada bukti keunggulan. Perubahan arah proposal terbukti pada 48/48 pasangan seed-keluarga, tetapi efek terhadap performa tidak positif pada agregat.

## Reproduksi dari sumber

```bash
python -m unittest -v test_f31
python ace_f31.py all --root evidence
python ace_f31.py verify --root evidence
python independent_verify.py --root evidence
```

Keluaran: `evidence/reports/results.json`, `runs.csv`, `candidate_lineage.csv`, 144 ledger, 144 checkpoint, 1440 artefak kandidat. Perintah `all` mendukung **resume** jika dihentikan setelah mencatat event. Tidak ada kebutuhan internet, akun API, GPU, atau paket pip tambahan.

File `ACE_F31_Feedback_Colab_v0.1.ipynb` dapat dijalankan dengan `Runtime > Run all` pada Google Colab untuk mereproduksi eksperimen, kemudian mengunduh `ACE_F31_reproduced_evidence.zip`.

**Catatan metodologis:** hasil 79/96, 94/96, dan 96/96 dari F3 lama tidak dapat langsung dibandingkan dengan skor F3.1 karena benchmark telah diperluas menjadi tugas induksi program laten yang berbeda. `BLIND_BEST` tetap memakai skor probe saat memilih kandidat final sehingga eksperimen mengisolasi manfaat arah **proposal**, bukan manfaat umpan balik secara keseluruhan. Pengerjaan ini bersifat eksploratoris, bukan preregistrasi konfirmatori dan belum memberi pembuktian kausal di luar lingkungan sintetis.
