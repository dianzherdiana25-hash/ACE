# ACE F3.1 — Laporan Eksperimen Mutasi Berbasis Umpan Balik

**Tanggal:** 4 November 2026  
**Status:** `EXPERIMENT_COMPLETE / NO_ADVANTAGE_DEMONSTRATED`  
**Cakupan:** eksperimen komputasi sintetis F3.1, bukan validasi F4 atau AGI/ASI.

## Pertanyaan penelitian

Ketika jumlah evaluasi sama, apakah memilih induk untuk mutasi berikutnya dengan memanfaatkan skor probe meningkatkan keberhasilan pada tugas baru dalam keluarga yang sama dibandingkan pencarian yang mengabaikan skor ketika menghasilkan kandidat?

## Desain yang benar-benar dijalankan

Sebanyak 24 seed (termasuk 1729, 2027, 4093), dua keluarga tugas (transformasi simbolik dan jalur graf), dan tiga kebijakan menghasilkan **144 run**. Semua kebijakan menggunakan DSL empat bit yang sama, 10 kandidat per run, 5 probe per kandidat (**50 evaluasi probe per run**), dan 24 kasus evaluasi akhir per run. Total **1.440 kandidat**, **7.200 skor probe**, dan **3.456 evaluasi akhir** (1.152 per kebijakan). Skor akhir tidak dibuka sampai kandidat dipilih.

- `GUIDED_BEST`: induk untuk mutasi berikutnya berasal dari kandidat dengan skor probe tertinggi yang telah diamati.
- `BLIND_BEST`: mutasi mengikuti induk terbaru tanpa membaca skor, tetapi kandidat akhir dipilih berdasarkan skor probe tertinggi. Ini **kontrol utama** untuk kontribusi kausal arah mutasi.
- `BLIND_LAST`: mutasi sama seperti `BLIND_BEST`, tetapi kandidat akhir dipilih berdasarkan generasi terakhir. Ini hanya kontrol tambahan untuk manfaat seleksi final.

Dua kandidat awal setiap eksperimen identik antar kebijakan. Evolusi selanjutnya menggunakan prosedur bit-flip dan restart terbatas. Semua aturan mutasi, evaluator, dan objek pencarian adalah hasil pemrograman manusia. Setiap kebijakan memiliki anggaran panggilan evaluator sama; biaya dan waktu CPU tidak dipaksakan identik. Tidak ada kode Python buatan kandidat yang dieksekusi.

Tugas evaluasi akhir memakai instans baru dari grammar yang sama dengan probe. Bank *held-out* F4 **tidak dibuat atau diakses**.

## Hasil yang dihitung dari log

| Kebijakan | Benar / total | Persentase |
|---|---:|---:|
| Mutasi diarahkan oleh skor (`GUIDED_BEST`) | **958 / 1152** | **83,16%** |
| Mutasi tanpa skor, pilihan akhir terbaik (`BLIND_BEST`) | **966 / 1152** | **83,85%** |
| Mutasi tanpa skor, pilihan kandidat terakhir (`BLIND_LAST`) | 315 / 1152 | 27,34% |

Perbedaan utama `GUIDED_BEST − BLIND_BEST`: **−8 jawaban benar** pada 1.152 kasus, atau **−0,694 poin persentase**. Estimasi interval bootstrap 95% dengan resampling berkelompok menurut seed adalah **[−13,889; +13,108] poin persentase**. Ini interval eksploratoris pada seed sintetis, bukan pembuktian atas populasi tugas dunia nyata.

Distribusi menurut keluarga tugas:

| Keluarga | Guided | Blind + best | Blind + last |
|---|---:|---:|---:|
| S — simbolik | 427/576 | 451/576 | 124/576 |
| G — graf | 531/576 | 515/576 | 191/576 |

Pada 48 unit pembanding berpasangan, Guided unggul pada 8 unit, sama pada 32, dan kalah pada 8. Deret genom generasi ke-3 dan seterusnya berbeda antara Guided dan Blind pada **48/48 unit**; artinya skor memang berpengaruh terhadap urutan proposal, bukan sekadar pemilihan final.

## Pemeriksaan aktual

- **19/19 tes unit lulus:** struktur domain, penolakan F4, konsistensi generasi, kuota evaluasi, pengaruh skor pada proposal, ketidakbergantungan kontrol terhadap skor, crash recovery, resume, dan pendeteksian manipulasi.
- **144/144 run lolos semantic replay** dan rantai hash/artefak/checkpoint dapat divalidasi.
- Pemeriksa kedua yang mengimplementasikan kembali operasi simbolik dan pencarian jalur graf mengonfirmasi **144 run, 1.440 kandidat, 7.200 reward probe**, serta skor akhir 958/966/315.
- Tidak ada model API, GPU, pembelian layanan, pengunggahan data pribadi, atau perubahan pada repositori.

## Interpretasi dan batas pembuktian

**Temuan positif terbatas:** desain F3.1 mengatasi kelemahan struktural F3; skor benar-benar memengaruhi kandidat yang diusulkan berikutnya. Namun **manfaat performa dari arah mutasi berbasis skor belum terbukti** karena kontrol dengan proposal tanpa skor tetapi seleksi akhir berbasis skor sedikit lebih unggul pada agregat, dengan ketidakpastian besar. Pada simbolik hasil Guided lebih lemah, sementara pada graf lebih baik; belum dapat digeneralisasi.

- Benchmark baru F3.1 berbeda dari F3; **jangan membandingkan langsung** skor 96/96 F3 dengan 958/1152 F3.1.
- Target program laten dan semua primitive telah dirancang manusia, bukan ditemukan otomatis oleh AI.
- Penilaian baru pada contoh berbeda **bukan** uji generalisasi struktural atau *held-out* F4.
- Ini pilot **eksploratoris**; sebagian seed diperiksa pada pengembangan. Jangan mengklaim uji prospektif yang sepenuhnya telah diregistrasi.
- Pemeriksaan kedua adalah replay berdasarkan spesifikasi dan generator yang sama, bukan verifikasi semantik oleh laboratorium terpisah.
- Integritas SHA-256 membuktikan kesesuaian konten dari artefak yang tersedia, bukan asal/identitas Colab.
- Jumlah evaluasi setara, tetapi prior knowledge, ongkos CPU, dan kemampuan DSL masih dibatasi rancangan manusia.

## Keputusan

**F3.1 engineering: PASS. F3.1 causal improvement: NOT DEMONSTRATED. F3 autonomous method invention: NOT DEMONSTRATED. F4: HOLD.**

Langkah riset berikutnya perlu mengevaluasi algoritma proposal alternatif pada data pembangunan terpisah, lalu mengunci desain sebelum satu set pengujian konfirmatori baru. Tanpa itu, mengejar skor di pilot yang sama berisiko menghasilkan bias seleksi dan pembuktian semu.
