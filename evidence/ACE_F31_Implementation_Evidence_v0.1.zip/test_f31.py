import tempfile
import unittest
from pathlib import Path
import ace_f31 as m

class TestF31(unittest.TestCase):
    def test_scope(self):
        with self.assertRaises(AssertionError):m.generate_example(1729,'S','held-out',0)
        self.assertEqual(m.PAID_COST_IDR,0)
    def test_seeds(self):self.assertEqual(len(set(m.SEEDS)),24)
    def test_families(self):self.assertEqual(m.FAMILIES,('S','G'))
    def test_reproducible_data(self):
        self.assertEqual(m.generate_example(1729,'S','probe',0),m.generate_example(1729,'S','probe',0))
        self.assertNotEqual(m.generate_example(1729,'S','probe',0),m.generate_example(1729,'S','within_template_test',0))
    def test_grade_is_scalar_only(self):
        ps=[m.generate_example(1729,'S','probe',i) for i in range(5)]
        g=m.grade(1729,'S',0,ps)
        self.assertEqual(len(g),5);self.assertTrue(all(0<=x<=1 for x in g))
    def test_dsl_bounds(self):
        with self.assertRaises(ValueError):m.program('S',{'tokens':[]},16)
    def test_same_initial_proposals(self):
        for seed in m.SEEDS[:5]:
            for fam in m.FAMILIES:
                guided=m.candidate_sequence(seed,fam,'GUIDED_BEST')
                blind=m.candidate_sequence(seed,fam,'BLIND_BEST')
                self.assertEqual([x['genome'] for x in guided[:2]],[x['genome'] for x in blind[:2]])
    def test_blind_ignores_feedback(self):
        history=m.candidate_sequence(1729,'S','BLIND_BEST')[:4]
        a=m.propose(1729,'S','BLIND_BEST',history)
        for c in history:c['mean_reward']=(c['mean_reward']+0.37)%1
        self.assertEqual(a,m.propose(1729,'S','BLIND_BEST',history))
    def test_feedback_affects_proposal(self):
        found=False
        for seed in m.SEEDS:
            for fam in m.FAMILIES:
                hist=m.candidate_sequence(seed,fam,'GUIDED_BEST')
                for step in range(3,9):
                    subset=[dict(c) for c in hist[:step]]
                    baseline=m.propose(seed,fam,'GUIDED_BEST',subset)
                    for c in subset:c['mean_reward']=0
                    subset[-1]['mean_reward']=100
                    changed=m.propose(seed,fam,'GUIDED_BEST',subset)
                    if baseline[0]!=changed[0]:found=True;break
                if found:break
            if found:break
        self.assertTrue(found)
    def test_distinct_generation_paths(self):
        guided=m.candidate_sequence(1729,'S','GUIDED_BEST')
        blind=m.candidate_sequence(1729,'S','BLIND_BEST')
        self.assertNotEqual([c['genome'] for c in guided[2:]],[c['genome'] for c in blind[2:]])
    def test_equal_budget(self):
        for mode in m.MODES:
            seq=m.candidate_sequence(1729,'S',mode)
            self.assertEqual(len(seq),10)
            self.assertEqual(sum(len(c['probe_rewards']) for c in seq),50)
    def test_graph_valid(self):
        t=m.generate_example(1729,'G','probe',0)
        for mask in range(16):
            result=m.graph_program(t,mask)
            self.assertEqual(set(result),{'reachable','path','cost'})
    def test_symbolic_deterministic(self):
        t=m.generate_example(1729,'S','probe',0)
        self.assertEqual(m.symbolic_program(t,9),m.symbolic_program(t,9))
    def test_full_run_verify(self):
        with tempfile.TemporaryDirectory() as d:
            r=m.run(d,1729,'S','GUIDED_BEST')
            self.assertTrue(r['complete']);self.assertEqual(r['events'],12)
            self.assertTrue(m.verify(d,1729,'S','GUIDED_BEST',complete=True)['complete'])
    def test_partial_resume(self):
        with tempfile.TemporaryDirectory() as d:
            r=m.run(d,1729,'G','BLIND_BEST',stop_after=3)
            self.assertFalse(r['complete']);self.assertEqual(r['events'],3)
            self.assertTrue(m.run(d,1729,'G','BLIND_BEST')['complete'])
    def test_crash_recovery(self):
        with tempfile.TemporaryDirectory() as d:
            with self.assertRaises(InterruptedError):m.run(d,1729,'G','GUIDED_BEST',inject_crash=True)
            self.assertTrue(m.run(d,1729,'G','GUIDED_BEST')['complete'])
    def test_tamper_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            m.run(d,1729,'S','BLIND_LAST')
            p=m.run_dir(d,1729,'S','BLIND_LAST')/'events.jsonl'
            data=p.read_text();p.write_text(data.replace('"generation":0','"generation":9',1))
            with self.assertRaises(m.IntegrityError):m.verify(d,1729,'S','BLIND_LAST')
    def test_candidate_tamper_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            m.run(d,1729,'S','GUIDED_BEST')
            p=next((m.run_dir(d,1729,'S','GUIDED_BEST')/'candidates').glob('*.json'))
            p.write_text('{"corrupted":true}')
            with self.assertRaises(m.IntegrityError):m.verify(d,1729,'S','GUIDED_BEST')
    def test_evaluation_limit(self):
        for fam in m.FAMILIES:
            result=m.evaluate_final(1729,fam,0)
            self.assertEqual(result['total'],24)
            self.assertEqual(len(result['case_scores']),24)

if __name__=='__main__':unittest.main()
