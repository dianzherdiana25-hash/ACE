import json, pathlib, tempfile, unittest
from ablation import select, evaluate, POLICIES

HERE=pathlib.Path(__file__).resolve().parent
ARCHIVE=HERE/'ACE_F3_reproduced_evidence.zip'

class AblationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        with tempfile.TemporaryDirectory() as folder:
            cls.result=evaluate(ARCHIVE,folder)

    def test_four_policies(self):
        self.assertEqual(set(self.result['policy_outcomes']),set(POLICIES))

    def test_original_feedback_unchanged(self):
        self.assertEqual(self.result['original_C_correct'],96)
        self.assertEqual(self.result['policy_outcomes']['feedback_tie_latest']['correct'],96)

    def test_no_feedback_latest_same_score(self):
        self.assertEqual(self.result['policy_outcomes']['no_feedback_latest']['correct'],96)

    def test_zero_paired_task_differences(self):
        self.assertEqual([r['feedback_vs_no_feedback_task_differences'] for r in self.result['paired_differences']],[0,0,0])

    def test_earliest_tie_changes_score(self):
        self.assertEqual(self.result['policy_outcomes']['feedback_tie_earliest']['correct'],94)

    def test_no_feedback_earliest(self):
        self.assertEqual(self.result['policy_outcomes']['no_feedback_earliest']['correct'],79)

    def test_18_candidates(self):
        self.assertEqual(len(self.result['candidate_table']),18)

    def test_heldout_untouched(self):
        self.assertEqual(self.result['F4_heldout'],'NOT_GENERATED_NOT_ACCESSED')

    def test_all_original_runs_verified(self):
        self.assertEqual(self.result['source_f3_runs_verified'],3)
        self.assertEqual(self.result['source_f2_A_B_runs_verified'],6)

    def test_feedback_selector_tie_priors(self):
        pool=[{'candidate_id':'a','family':'S','generation':0},{'candidate_id':'b','family':'S','generation':2},
              {'candidate_id':'c','family':'G','generation':0},{'candidate_id':'d','family':'G','generation':2}]
        scores={'a':1,'b':1,'c':0,'d':1}
        self.assertEqual(select(pool,scores,'feedback_tie_latest')['S']['candidate_id'],'b')
        self.assertEqual(select(pool,scores,'feedback_tie_earliest')['S']['candidate_id'],'a')
        self.assertEqual(select(pool,scores,'no_feedback_latest')['G']['candidate_id'],'d')

    def test_2027_graph_order_control(self):
        d=self.result['order_permutations']['2027:G']
        self.assertEqual(d['winner_generation_by_six_permutations'],{'0':2,'1':2,'2':2})
        self.assertEqual(d['final_correct_by_six_permutations'],{'14':4,'16':2})

if __name__=='__main__':unittest.main(verbosity=2)
