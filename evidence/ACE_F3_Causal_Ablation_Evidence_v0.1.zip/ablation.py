"""ACE F3 causal ablation over user's Colab-reproduced evidence (no F4 tasks).

Deterministic paired counterfactual: same 3 seeds, same 6 candidates/seed,
same 12 probe scores and same 32 final tasks. Policy variants affect only
selection from the already generated candidate pool. No external API calls.
"""
from __future__ import annotations
import argparse, collections, hashlib, importlib, itertools, json, math, pathlib, shutil, sys, tempfile, zipfile

POLICIES = ('feedback_tie_latest', 'no_feedback_latest', 'feedback_tie_earliest', 'no_feedback_earliest')


def safe_extract(zf, dest):
    dest=pathlib.Path(dest).resolve()
    for inf in zf.infolist():
        name=pathlib.PurePosixPath(inf.filename)
        if not inf.filename or name.is_absolute() or '..' in name.parts or '\\' in inf.filename:
            raise ValueError('unsafe archive member')
        if inf.file_size > 3_000_000: raise ValueError('oversized archive member')
        if not str((dest / inf.filename).resolve()).startswith(str(dest)+'/'):
            raise ValueError('member escapes extraction root')
    zf.extractall(dest)


def select(candidates, scores, policy):
    if policy not in POLICIES:raise ValueError(policy)
    result={}
    for family in ('S','G'):
        pool=[c for c in candidates if c['family']==family]
        if policy=='no_feedback_latest':
            choice=max(pool,key=lambda c:c['generation'])
        elif policy=='no_feedback_earliest':
            choice=min(pool,key=lambda c:c['generation'])
        elif policy=='feedback_tie_latest':
            choice=max(pool,key=lambda c:(scores[c['candidate_id']],c['generation']))
        else:
            choice=max(pool,key=lambda c:(scores[c['candidate_id']],-c['generation']))
        result[family]=choice
    return result


def evaluate(archive, output):
    archive=pathlib.Path(archive)
    output=pathlib.Path(output)
    output.mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='ace_f3_ablation_') as work:
        with zipfile.ZipFile(archive) as zf:
            bad=zf.testzip()
            if bad:raise ValueError('archive CRC error '+bad)
            safe_extract(zf,work)
        work=pathlib.Path(work)
        sys.path.insert(0,str(work))
        import ace_f1 as f1, ace_f2 as f2, ace_f3 as f3
        # Validate exact study code and original events: verifier also recalculates probes,
        # finals, source hash, checkpoint, candidate artifact integrity.
        original_hashes={f'ace_{phase}.py':hashlib.sha256((work/f'ace_{phase}.py').read_bytes()).hexdigest() for phase in ('f1','f2','f3')}
        recorded=json.loads((work/'evidence/reports/f3_metrics.json').read_text(encoding='utf8'))
        if recorded.get('source_sha256') != original_hashes:
            raise ValueError('source mismatch with recorded F3 study')
        verified={}
        rows=[]
        outcome={p:{'correct':0,'total':0} for p in POLICIES}
        ordered_summary={}
        original_selected={}
        original_C=0
        paired=[]
        for seed in f1.SEEDS:
            for mode in ('A_CONTROL','B_ADAPT'):
                f2.verify_run(work/'evidence',mode,seed,require_complete=True)
            v=f3.verify(work/'evidence',seed,complete=True)
            verified[str(seed)]={'events':v['events'],'final_pass':v['final_pass'],'head':v['head']}
            original_C+=v['final_pass']
            candidates,by_family,finals=f3.plan(seed)
            logged=f3.load_events(work/'evidence'/'runs'/f3.run_id(seed)/'events.jsonl')
            probes=[e for e in logged if e['action']=='PROBE']
            scores={c['candidate_id']:sum(e['score'] for e in probes if e['candidate_id']==c['candidate_id']) for c in candidates}
            for c in candidates:
                matching=[e for e in probes if e['candidate_id']==c['candidate_id']]
                if len(matching)!=2:raise AssertionError('wrong number of recorded probes')
                recomputed=sum(f1.evaluate(t,f3.solve(f1.public_task(t),c))['score'] for t in by_family[c['family']])
                if recomputed!=scores[c['candidate_id']]:raise AssertionError('probe mismatches')
            wins={policy:select(candidates,scores,policy) for policy in POLICIES}
            original_selected[str(seed)]=v['chosen']
            if {fam:c['candidate_id'] for fam,c in wins['feedback_tie_latest'].items()}!=v['chosen']:
                raise AssertionError('cannot reproduce frozen winner')
            by_fam={family:[t for t in finals if t['family']==family] for family in ('S','G')}
            for family in ('S','G'):
                pool=[c for c in candidates if c['family']==family]
                for c in pool:
                    final_sc=sum(f1.evaluate(t,f3.solve(f1.public_task(t),c))['score'] for t in by_fam[family])
                    rows.append({'seed':seed,'family':family,'generation':c['generation'],'genome':c['genome'],
                                 'candidate_id':c['candidate_id'],'probe_correct':scores[c['candidate_id']],
                                 'probe_total':2,'posthoc_final_correct':final_sc,'posthoc_final_total':len(by_fam[family])})
                # exact order controls, exhaustive 3! ties (only post-hoc selection order)
                freq=collections.Counter();run_score=collections.Counter()
                for order in itertools.permutations(pool):
                    top=max(enumerate(order),key=lambda j:(scores[j[1]['candidate_id']],j[0]))[1]
                    freq[str(top['generation'])]+=1
                    run_score[str(sum(f1.evaluate(t,f3.solve(f1.public_task(t),top))['score'] for t in by_fam[family]))]+=1
                ordered_summary[f'{seed}:{family}']={'winner_generation_by_six_permutations':dict(sorted(freq.items())),
                                                     'final_correct_by_six_permutations':dict(sorted(run_score.items()))}
            policy_res={}
            for policy in POLICIES:
                count=0
                per_task=[]
                for t in finals:
                    candidate=wins[policy][t['family']]
                    score=f1.evaluate(t,f3.solve(f1.public_task(t),candidate))['score']
                    count+=score;per_task.append(score)
                outcome[policy]['correct']+=count
                outcome[policy]['total']+=len(finals)
                policy_res[policy]={'correct':count,'total':len(finals),'selected':{fam:c['candidate_id'] for fam,c in wins[policy].items()},'task_scores':per_task}
            paired.append({'seed':seed,'feedback_vs_no_feedback_task_differences':sum(x!=y for x,y in zip(policy_res['feedback_tie_latest']['task_scores'],policy_res['no_feedback_latest']['task_scores']))})
            for policy in POLICIES:
                del policy_res[policy]['task_scores']
            verified[str(seed)]['policy_outcomes']=policy_res
        assert len(rows)==18 and len(paired)==len(f1.SEEDS)
        assert outcome['feedback_tie_latest']==outcome['no_feedback_latest']
        assert original_C==outcome['feedback_tie_latest']['correct']
        ablation={
            'study':'ACE-F3-CAUSAL-ABLATION-v0.1','source':'user_uploaded_ACE_F3_reproduced_evidence.zip',
            'source_zip_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),
            'code_hashes':original_hashes,'seeds':list(f1.SEEDS),
            'source_f3_runs_verified':3,'source_f2_A_B_runs_verified':6,
            'original_C_correct':original_C,'policy_outcomes':outcome,'runs':verified,
            'candidate_table':rows,'order_permutations':ordered_summary,'paired_differences':paired,
            'original_selections':original_selected,
            'probe_budget_per_seed':12,'final_tasks_per_seed':32,
            'experimental_domain':'F2 pilot post-freeze data; same templates as probes',
            'F4_heldout':'NOT_GENERATED_NOT_ACCESSED',
            'additional_paid_api_calls':0,
            'interpretation':'Feedback-selection was not necessary for F3 96/96 on this exact pilot: no-feedback latest selects identical candidates and yields identical scores. Does not establish absence of benefits in other tasks.',
            'study_limitations':['posthoc counterfactual analysis, not independently preregistered',
                                 'all candidates predefined by deterministic two-bit feature mutation',
                                 'latest generation always has both hand-coded features',
                                 'final tasks share templates with probe tasks',
                                 'no new unseen tasks, no autonomous model, no new AI-generated algorithm',
                                 'equal candidate probe scorer calls, not equal human design knowledge or CPU costs']}
        (output/'ablation_results.json').write_text(json.dumps(ablation,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
        assert all(i['feedback_vs_no_feedback_task_differences']==0 for i in paired)
        return ablation


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--archive',required=True)
    ap.add_argument('--out',required=True)
    args=ap.parse_args()
    r=evaluate(args.archive,args.out)
    print(json.dumps({'status':'PASS','source_verified':r['source_f3_runs_verified'],
        'outcomes':r['policy_outcomes'],'paired_differences':r['paired_differences'],
        'F4_heldout':r['F4_heldout']},indent=2))

if __name__=='__main__':main()
