# ACE F3 — Laporan Ablasi Kausal v0.1

**Tanggal:** 4 November 2026  
**Dasar:** `ACE_F3_reproduced_evidence.zip`, hasil Colab yang diunggah pengguna; SHA-256: `6c036fd1efc894e3fb38ea19f8cf62719f32ea2b7f1f00749f721b98fe1ccf9c`.  
**Status:** ABLA​TION_COMPLETE / NEGATIVE_CAUSAL_RESULT.  
**Ruang lingkup:** analisis kontra-faktual atas artefak dan tugas pilot F3. Bank *held-out* F4 **tidak dibuat atau diakses**.

## Ringkasan keputusan

**Tidak ada bukti bahwa umpan balik seleksi menyebabkan keunggulan C pada pilot F3.** Semua skor C dapat direproduksi oleh aturan tanpa umpan balik yang selalu memilih kandidat generasi terbaru. Prototipe rekayasa DSL F3 tetap lulus, tetapi hipotesis manfaat kausal mekanisme evolusi untuk pilot ini **tidak didukung**.

## Metode yang dieksekusi

1. Baca ZIP hasil Colab, uji CRC, validasi SHA-256 kode F1/F2/F3 terhadap laporan sumber.
2. Jalankan `f2.verify_run(..., require_complete=True)` untuk enam run A/B dan `f3.verify(..., complete=True)` untuk tiga run C. Proses ini mengecek konten peristiwa, kandidat, checkpoint, konfigurasi, dan replay skor.
3. Hitung ulang **dua skor probe** untuk setiap kandidat dari fungsi solusi dan scorer F1 asli.
4. Pada setiap seed dan keluarga tugas, terapkan empat kebijakan seleksi pada **enam kandidat asli yang identik**. Setiap kebijakan memiliki akses ke jadwal 12 probe yang sama; kontrol tanpa umpan balik membuang skornya. Tidak ada perubahan kandidat, urutan mutasi, soal akhir, atau evaluator.
5. Hitung ulang skor masing-masing kebijakan pada 32 soal akhir per seed, total 96 soal, tanpa membuka soal *held-out*.
6. Evaluasi sensitivitas tie-break: permutasikan urutan tiga kandidat per keluarga (6 urutan) tanpa menambah kandidat atau mengevaluasi tugas baru.
7. Jalankan 11 tes otomatis untuk implementasi ablation. Tidak ada model/API eksternal dipanggil.

## Hasil aktual

| Kebijakan | Jawaban benar | Keberhasilan |
| --- | ---: | ---: |
| C aktual: feedback, ikatan memilih kandidat terbaru | **96/96** | **100%** |
| Kontrol: tanpa feedback, selalu generasi terbaru | **96/96** | **100%** |
| Kontrol: feedback, ikatan memilih kandidat terdahulu | 94/96 | 97,92% |
| Kontrol: tanpa feedback, selalu generasi pertama | 79/96 | 82,29% |

**Perbedaan pasangan C vs kontrol generasi terbaru: 0/96 kasus**, dan sama pada seed 1729, 2027, dan 4093.

Khusus keluarga graf seed 2027, semua tiga kandidat memiliki skor probe **2/2**. Ketika urutannya dipermutasi, dua dari enam urutan memilih kandidat terbaik (16/16), sedangkan empat urutan memilih kandidat lebih lemah (14/16). Hal ini menunjukkan perbedaan pada aturan pemecahan seri, bukan bukti seleksi berdasarkan kemampuan baru.

## Interpretasi

- **Bukti negatif bersifat spesifik:** pada data dan ruang kandidat F3 yang sama, feedback tidak diperlukan untuk memperoleh 96/96. Tidak berarti feedback evolusioner tidak mungkin berguna di rancangan lain.
- Skor seleksi tidak menentukan arah mutasi; kandidat secara deterministik berjalan dari 0 fitur → 1 fitur → 2 fitur. Generasi terakhir sudah mencakup seluruh fitur yang dirancang manusia.
- Perbandingan ini *post hoc*, tidak diregistrasi sebelum F3; karena itu digunakan sebagai diagnosis kausal, bukan sebagai estimasi tak-bias efektivitas mekanisme evolusi pada populasi masalah.
- Menyamakan jumlah panggilan scorer tidak menyamakan pengetahuan rekayasa yang ditanamkan, ongkos CPU, atau ruang pencarian.
- Data *final* F3 mengikuti template yang juga muncul pada probe. Hasil di sini bukan pengujian generalisasi lintas struktur.
- Tidak ada algoritma orisinal yang diciptakan LLM, mutasi grammar mandiri, atau pengganti model; biaya API tambahan Rp0 untuk uji ini.

## Gerbang penelitian

| Gerbang | Status |
| --- | --- |
| F0 dan F1 | Tetap lulus pada lingkup yang telah diverifikasi sebelumnya |
| F2 | Lulus pada adaptasi katalog terdahulu |
| F3 prototipe rekayasa | Lulus; dapat direproduksi |
| F3 manfaat kausal dari feedback evolusi | **NOT DEMONSTRATED** |
| F3 penemuan metode otonom | **NOT DEMONSTRATED** |
| F4 unseen-template generalization | **NOT RUN** |

**Keputusan: HOLD klaim evolusi kemampuan.** F4 belum digunakan; jangan menyebut C unggul karena umpan balik evolusioner. Iterasi ilmiah berikutnya ialah eksperimen F3.1 dengan kebijakan seleksi yang benar-benar memengaruhi proposal kandidat berikutnya, variasi urutan dan seed, kontrol tanpa feedback yang memakai anggaran identik, dan evaluasi final terpisah secara struktural. Seluruh algoritma/strategi perlu dibekukan sebelum satu kali evaluasi F4.

## Reproduksi

Paket menyertakan `ablation.py`, `test_ablation.py`, `ablation_results.json`, `test_log.txt`, ZIP sumber F3 yang diunggah, dan notebook Colab mandiri. Jalankan dalam Python standar:

```bash
python -m unittest -v test_ablation
python ablation.py --archive ACE_F3_reproduced_evidence.zip --out hasil_ulang
```

Hasil lokal: **11/11 tes PASS**; verifikasi semantik 9/9 run sumber; empat kontrol dihitung ulang untuk 3 seed, tanpa membuat artefak F4. Pemeriksaan atas sumber bersifat konsistensi dan replay internal: hash bukan tanda tangan independen dan tidak membuktikan asal historis lingkungan Colab.
