# ACE F0 — Paket bukti uji lokal

Paket ini berisi bukti pengujian CPU/Python yang **sudah dieksekusi**, bukan hasil eksperimen evolusi AI.

Isi:
- `ace_f0_probe.py`: skrip uji menggunakan pustaka standar Python; tidak memakai internet/API.
- `evidence.json`: hasil pemeriksaan terstruktur.
- `runtime/events.jsonl`: ledger berantai hash.
- `runtime/checkpoint.json`: checkpoint pemulihan.
- `ACE_F0_Verification_Report_v0.1.md`: status dan batas kesimpulan.
- `SHA256SUMS.txt`: hash file bukti (dibuat setelah bukti disiapkan).

Untuk menjalankan ulang pada salinan bersih: gunakan Python 3.10+ dan tiga perintah berikut dalam folder **baru** yang hanya berisi `ace_f0_probe.py`:

```bash
python ace_f0_probe.py first
python ace_f0_probe.py resume
python ace_f0_probe.py verify
```

Jangan menjalankan fase `first` pada folder yang sudah memiliki `runtime/events.jsonl` dari pengujian sebelumnya. Arsipkan artefak yang dihasilkan agar tidak kehilangan bukti.

Penelitian belum memasuki F1. Reproduksi pada Colab/Kaggle/GitHub akun Anda belum dibuktikan.
