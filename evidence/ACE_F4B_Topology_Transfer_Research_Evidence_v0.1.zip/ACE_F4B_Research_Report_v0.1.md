# ACE F4b — Transfer Komposisi pada Topologi Graf Baru

**Tanggal penelitian:** 4 November 2026  
**Status:** `ENGINEERING_PASS / INTERNAL_TRANSFER_SUPPORTED / EXTERNAL_GENERALIZATION_NOT_PROVEN / AUTONOMOUS_INVENTION_NOT_PROVEN`

## 1. Pertanyaan penelitian

Apakah macro komposisional yang dipelajari dari tugas transformasi sinyal pada graf jalur dan siklus membantu pencarian solusi pada graf **pohon dan graf berarah tanpa siklus (DAG)**, dibanding pencarian adaptif tanpa pewarisan macro, dengan jumlah kandidat dan probe yang disamakan?

F4b merupakan **benchmark penghubung baru**, berdasarkan pelajaran metodologis F3.3 dan F4a, bukan evaluasi ulang byte-identik terhadap solver F3.3. Primitive graf F4b dibuat khusus untuk penelitian ini. Dengan demikian, hasil F4b **tidak boleh digabungkan langsung dengan skor F4a** atau disebut pembuktian bahwa sistem ACE yang sama berpindah domain secara mandiri.

## 2. Rancangan yang dikunci sebelum melihat hasil konfirmatori

- **Sumber:** enam tugas per seed pada graf `PATH` dan `CYCLE`, berukuran 8/10 simpul.
- **Sasaran:** graf `TREE` dan `DAG`, berukuran 9/11 simpul; dua rezim: `SHARED` (motif dua operasi yang digunakan di sumber juga relevan di sasaran) dan `NOVEL` (motif yang dihasilkan secara terpisah).
- **DSL:** enam operasi tetap `i`, `n`, `s`, `m`, `p`, `d` atas vektor nilai simpul; panjang program maksimum empat primitive.
- **Macro:** urutan dua primitive yang disimpan dari kandidat sumber yang dinilai menggunakan probe sumber. Tidak ada primitive baru yang diciptakan. Library dibekukan selama semua tugas sasaran sehingga tidak belajar dari label evaluasi akhir.
- **Empat kebijakan:** `A_BLIND` (pencarian acak dengan seleksi terbaik berdasarkan probe; **bukan** solver A-Fixed F1), `B_GUIDED` (mutasi adaptif tanpa transfer macro), `C_TRANSFER` (mutasi adaptif dengan macro dari sumber yang sesuai), `D_SHUFFLED` (macro yang dipelajari dari seed sumber berbeda, kontrol relevansi).
- **Anggaran pencarian per tugas:** 32 kandidat, 4 contoh probe per kandidat, dan 12 evaluasi akhir. Kondisi dibandingkan pada input, target, anggaran, dan dua proposal pertama yang sama.
- **Desain konfirmatori:** 16 seed × 2 topologi × 2 rezim × 4 kebijakan = **256 run**, masing-masing empat tugas sasaran. Total **1.024 catatan tugas** dan **12.288 kasus akhir**, masing-masing kebijakan 3.072 kasus.
- **Uji primer:** `C_TRANSFER − B_GUIDED` pada akurasi tepat, interval bootstrap persentil 95% dengan resampling seluruh klaster seed sebanyak 10.000 kali. Lulus dukungan internal bila batas bawah interval > 0; tidak mendukung bila batas atas < 0; selebihnya tidak konklusif.
- **Analisis sekunder:** per topologi dan rezim serta kontrol macro berbeda sumber; eksploratori, bukan klaim konfirmatori tersendiri.

**Penguncian lokal:** `ace_f4b.py` SHA-256 `54ec5e520f2ed4f5ef652d5e36f6a8f351a20060ca27a5fc7a77a30e82879034`; pra-registrasi SHA-256 `2548bace7796bc8dcad51fd10517a12e6903a807c38068319b81f2572766db51`. Dokumen protokol dibuat sebelum pengujian konfirmatori. **Tidak ada timestamp pihak ketiga atau penyegelan data eksternal.** Pengujian QA pada dua seed terpisah terjadi setelah penguncian, tanpa perubahan pada skrip yang dikunci.

## 3. Hasil konfirmatori yang dihitung ulang

| Kebijakan | Benar / 3.072 | Akurasi |
|---|---:|---:|
| A — Blind + best-of-probes | 260 | 8,46% |
| B — Guided, no macro | 284 | 9,24% |
| C — Guided + learned source macro | **505** | **16,44%** |
| D — Guided + mismatched source macro | 296 | 9,64% |

**Efek primer C – B:** `+221 / 3.072 = +7,1940` poin persentase. **95% bootstrap CI** berbasis 16 seed: **[+3,7760; +10,5469]** poin. Sesuai aturan yang didaftarkan sebelumnya, dukungan terhadap *manfaat transfer macro pada benchmark internal ini* ditemukan.

Analisis sekunder dan heterogenitas:

| Kelompok | C | B | Selisih C−B (poin persentase) |
|---|---:|---:|---:|
| Motif berulang `SHARED` | 361/1.536 | 131/1.536 | **+14,97** |
| Motif baru `NOVEL` | 144/1.536 | 153/1.536 | **−0,59** |
| Graf pohon `TREE` | 190/1.536 | 99/1.536 | **+5,92** |
| Graf berarah `DAG` | 315/1.536 | 185/1.536 | **+8,46** |

C juga mengungguli D sebanyak `209/3.072 = 6,80` poin persentase; tidak disimpulkan signifikansi statistik tersendiri. **Peningkatan utama terkonsentrasi pada struktur operasi yang sudah relevan selama pembelajaran sumber.** Pada motif baru, macro tidak menunjukkan keunggulan dibanding B.

## 4. Audit implementasi

- **13/13 tes rekayasa** lulus, termasuk topologi, validitas DSL, determinisme, kesamaan dua proposal awal, anggaran, dan pengujian bahwa perubahan label evaluasi akhir tidak mengubah kandidat yang dipilih.
- **256/256 run** lulus pemeriksaan rangkaian SHA-256 dan *semantic replay* dari kode penelitian yang sama.
- Auditor tambahan menilai ulang **1.024 hasil tugas / 12.288 kasus akhir** menggunakan input dan target deterministik, serta mengecek **131.072 evaluasi probe** yang direncanakan (32.768 per kebijakan), lineage library, dan 256 pasangan proposal awal. Ini merupakan audit dari laporan yang tersimpan, **bukan** verifikator eksternal yang benar-benar terpisah dari DSL benchmark.
- Total macro digunakan dalam 3.226 proposal kandidat C; library sumber memiliki 0–8 macro pada seed berbeda, sehingga beberapa trial tidak memiliki pengetahuan transfer.
- Kode dan praregistrasi tetap sama setelah penguncian. Auditor tambahan serta laporan ini dibuat setelah hasil diperoleh.
- Tidak ada API berbayar, akun Google yang diubah, ataupun eksekusi kode Python buatan agen yang tidak tepercaya.

## 5. Keterbatasan dan interpretasi

1. **Benchmark disusun oleh peneliti dalam sesi yang sama.** Generator label sasaran dan solver tersedia dalam satu kode, bukan bank soal tersiegel independen. Ini bukti rekayasa dan eksperimen internal, bukan bukti eksternal yang tahan kecurangan agen canggih.
2. Rezim `SHARED` secara sengaja mempertahankan motif dua-operator dari pembelajaran sumber, sehingga sebagian besar keunggulan menunjukkan **pemakaian ulang komposisi yang sama di graf berbeda**, bukan transfer universal ke metode yang tidak terkait.
3. Semua tugas menggunakan ruang primitive yang sama; hanya ukuran dan hubungan graf berubah. Operasi fundamental baru tidak diciptakan. Pengujian `NOVEL` memperlihatkan tidak ada keunggulan yang berkelanjutan pada motif baru.
4. `A_BLIND` hanya pembanding kebijakan dalam F4b, **bukan** implementasi Fixed A F1. Karena engine DSL dan domain berbeda, tidak sah membandingkan akurasi absolut F1/F2/F3/F4a dengan angka F4b.
5. Perbandingan menyamakan anggaran kandidat, probe, dan sumber pembelajaran nominal; tidak menyamakan latensi CPU atau biaya runtime persis.
6. Bootstrap menggunakan 16 klaster seed; interval menunjukkan ketidakpastian internal, bukan jaminan generalisasi dunia nyata. Perbandingan strata tanpa koreksi uji jamak diperlakukan eksploratori.
7. Penelitian F4b memperlihatkan transfer **mekanisme komposisi yang sudah ditentukan**, bukan transfer kecerdasan otonom yang mampu menemukan algoritma fundamental.

## 6. Keputusan gerbang

- **F4b benchmark internal / pengujian lintas topologi:** `PASS` (audit dan dukungan efek primer dalam tugas sintetis).
- **Transfer lintas motif yang belum dipelajari:** `NOT_SUPPORTED` pada data ini (selisih negatif kecil dan belum diuji secara terpisah untuk signifikansi).
- **F4 generalisasi eksternal / lintas domain bebas:** `OPEN`.
- **Penemuan primitive baru tanpa rancangan manusia:** `NOT_PROVEN`.
- **Visi Open-Ended Autonomous Intelligence Evolution:** `NOT ACHIEVED`.

**Keputusan riset berikutnya:** beralih ke **F5 — sintesis bukti dan keputusan penelitian** berdasarkan semua hasil F0–F4b, serta merancang satu tes pihak ketiga/sealed yang independen sebelum investasi dalam klaim lebih luas. Hindari mengoptimalkan ulang model berdasarkan target F4b yang kini sudah terungkap.
