# ACE F4b — Reproduksi CPU

Paket F4b menguji transfer komposisi DSL graf dari PATH/CYCLE ke TREE/DAG. Ini adalah benchmark **internal** yang seluruh targetnya dapat dibangun ulang oleh kode Python; bukan tes independen yang disegel.

Python 3.10+ dan pustaka standar sudah cukup. Di direktori sumber:

```bash
python test_f4b.py
python ace_f4b.py run --root confirm_reproduced --prereg F4B_PREREGISTRATION.json
python ace_f4b.py semantic --root confirm_reproduced --prereg F4B_PREREGISTRATION.json
python independent_audit.py confirm_reproduced
python ace_f4b.py analyze --root confirm_reproduced --prereg F4B_PREREGISTRATION.json
```

Skrip menolak menimpa folder hasil yang sudah mempunyai `events.jsonl`; gunakan direktori baru untuk pengujian ulang. `F4B_PREREGISTRATION_SHA256.txt` merekam hash protokol yang dibuat sebelum pengujian konfirmatori. Semua perubahan setelah itu berada di artefak auditor, laporan, dan notebook pendistribusian, bukan pada skrip penelitian yang dikunci.

Benchmark mengukur perolehan kembali *macro* dua-primitive yang disimpan dari tugas sumber, bukan penciptaan primitive baru, bukan AGI, bukan sistem agen otonom yang mampu mengembangkan arsitekturnya sendiri. Tidak menggunakan API, GPU, atau izin akun.
