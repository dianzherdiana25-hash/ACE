"""Post-registration semantic audit for ACE F4b.
Uses explicit target final vectors to re-grade selected programs, checks source
library provenance, budget equality, source/target topology shifts, and seed pairing.
This code is NOT an independent model/evaluator; it imports the benchmark DSL.
"""
import hashlib,json,sys
from pathlib import Path
import ace_f4b as m

def canonical(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False)
def audit(folder):
    root=Path(folder)
    events=[json.loads(line)['record'] for line in (root/'events.jsonl').read_text().splitlines()]
    unique={(r['seed'],r['topology'],r['regime'],r['arm']) for r in events}
    assert len(unique)==len(events)
    checked=0;macro_from_source=0;correct_totals={arm:0 for arm in m.ARMS}
    probe_checks=0;probe_usage={arm:0 for arm in m.ARMS}
    by_pair={};macro_proposals=0
    for r in events:
        arm=r['arm'];lib=r['source_library'];active=r['active_library']
        assert len(r['source_trace'])==m.SOURCE_TASKS
        assert all(t['topology']==('PATH' if i%2==0 else 'CYCLE') for i,t in enumerate(r['source_trace']))
        assert all(len(pair)==2 and all(op in m.PRIMITIVES for op in pair) for pair in lib.values())
        if arm=='C_TRANSFER':assert active==lib
        if arm in ('A_BLIND','B_GUIDED'):assert active=={}
        if arm=='D_SHUFFLED':assert active=={k:list(v) for k,v in m.source_library(r['seed']+96331)[0].items()}
        key=(r['seed'],r['topology'],r['regime'])
        for task in r['tasks']:
            j=task['task']
            graph,final=m.task_examples(r['seed'],r['topology'],j,r['regime'],'final',m.FINAL)
            prog=tuple(task['best'])
            score=sum(tuple(m.execute(prog,x,graph))==tuple(y) for x,y in final)
            assert score==task['score']
            assert m.sha(final)==task['final_label_digest']
            graph2,probe=m.task_examples(r['seed'],r['topology'],j,r['regime'],'probe',m.PROBES)
            assert graph2==graph
            assert m.sha(m.target(r['seed'],j,r['regime']))==task['target_hash']
            assert 1<=len(prog)<=m.MAX_DEPTH
            assert len(task['first_two'])==2
            ik=(key,j)
            if ik not in by_pair:by_pair[ik]=task['first_two']
            else:assert by_pair[ik]==task['first_two']
            checked+=1;probe_checks+=m.PROBES*task['candidate_count'];probe_usage[arm]+=m.PROBES*task['candidate_count']
            macro_proposals+=task['macro_proposals']
        correct_totals[arm]+=r['correct']
        macro_from_source+=len(lib)
    expected=len(m.CONFIRM_SEEDS)*len(m.TOPOLOGIES)*len(m.REGIMES)*len(m.ARMS)*m.TARGET_TASKS
    assert checked==expected
    assert len(set(probe_usage.values()))==1
    # Explicit compare counts, no conjunction shortcut.
    summary=json.loads((root/'summary.json').read_text())
    for arm in m.ARMS:assert correct_totals[arm]==summary['by_arm'][arm]['correct']
    return {'pass':True,'task_records_regraded':checked,'final_cases_regraded':checked*m.FINAL,
            'candidate_probe_cases_checked':probe_checks,'paired_initial_proposals_checked':len(by_pair),
            'probe_evaluations_per_arm':probe_usage,'source_macro_records_seen':macro_from_source,
            'candidate_uses_macro_total':macro_proposals,'correct_per_arm':correct_totals,
            'limitation':'Uses existing DSL implementation; independent from cached summary, not independent external evaluator'}

if __name__=='__main__':
    print(json.dumps(audit(sys.argv[1]),indent=2))
