"""ACE F4b: internally generated cross-topology graph-signal compositional transfer.

No external model or cloud API. Source: path/cycle graphs, target: branched
undirected trees/directed acyclic graphs. Restricted programs over common primitives.
The target generator is not externally sealed. Do NOT claim AGI or broad transfer.
"""
from __future__ import annotations
import argparse, hashlib, json, random, math, os
from pathlib import Path

STUDY='ACE-F4B-TOPOLOGY-TRANSFER-20261104'
PRIMITIVES=('i','n','s','m','p','d')
ARMS=('A_BLIND','B_GUIDED','C_TRANSFER','D_SHUFFLED')
TOPOLOGIES=('TREE','DAG')
REGIMES=('SHARED','NOVEL')
QA_SEEDS=(47013,47029)
CONFIRM_SEEDS=tuple(890009+3079*i for i in range(16))
SOURCE_TASKS=6
TARGET_TASKS=4
CANDIDATES=32
PROBES=4
FINAL=12
MAX_DEPTH=4
MAX_LIBRARY=8
MOD=7


def canon(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False)
def sha(v):return hashlib.sha256((v if isinstance(v,str) else canon(v)).encode('utf8')).hexdigest()
def file_sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def rng(*args):return random.Random(int(sha(args)[:16],16))


def graph(seed,topology,task_id):
    r=rng('graph',seed,topology,task_id)
    n=r.choice((8,10)) if topology in ('PATH','CYCLE') else r.choice((9,11))
    inbound=[set() for _ in range(n)]
    if topology=='PATH':
        edges=[(i,i+1) for i in range(n-1)];directed=False
    elif topology=='CYCLE':
        edges=[(i,(i+1)%n) for i in range(n)];directed=False
    elif topology=='TREE':
        # Branched tree: every new vertex attaches to a preceding vertex,
        # ensure at least one branch to distinguish from a path.
        edges=[(r.randrange(i),i) for i in range(1,n)]
        if max(sum((a==x or b==x) for a,b in edges) for x in range(n))<3:
            edges[2]=(0,3) if n>3 else edges[2]
        directed=False
    elif topology=='DAG':
        # A directed acyclic graph with long and short-range edges.
        edges=[(i-1,i) for i in range(1,n)]
        for i in range(2,n):
            for j in range(i-1):
                if r.random()<0.24:edges.append((j,i))
        directed=True
    else:raise ValueError('Unknown topology')
    for u,v in edges:
        inbound[v].add(u)
        if not directed:inbound[u].add(v)
    return tuple(tuple(sorted(ns)) for ns in inbound)


def op_apply(op,x,g):
    if op=='i':return x
    out=[]
    for v,ns in enumerate(g):
        neigh=[x[j] for j in ns]
        if op=='n':z=sum(neigh)%MOD
        elif op=='s':z=(x[v]+sum(neigh))%MOD
        elif op=='m':z=max(neigh) if neigh else x[v]
        elif op=='p':z=(sum(neigh)%2)
        elif op=='d':z=(x[v]*(len(neigh)+1))%MOD
        else:raise ValueError('unknown operator')
        out.append(z)
    return tuple(out)


def execute(prog,x,g):
    if not 1<=len(prog)<=MAX_DEPTH or any(a not in PRIMITIVES for a in prog):raise ValueError('invalid program')
    for op in prog:x=op_apply(op,x,g)
    return x


def latent_motif(seed):
    r=rng('latent',seed);return tuple(r.choice(PRIMITIVES[1:]) for _ in range(2))


def target(seed,task_id,regime):
    r=rng('target',seed,task_id,regime)
    motif=latent_motif(seed) if regime=='SHARED' else tuple(r.choice(PRIMITIVES[1:]) for _ in range(2))
    suffix=(r.choice(PRIMITIVES[1:]),)
    return motif+suffix


def task_examples(seed,topology,task_id,regime,kind,n):
    g=graph(seed,topology,task_id)
    t=target(seed,task_id,regime)
    pairs=[]
    for j in range(n):
        r=rng('signals',seed,topology,task_id,regime,kind,j)
        x=tuple(r.randrange(MOD) for _ in g)
        pairs.append((x,execute(t,x,g)))
    return g,tuple(pairs)


def score(prog,g,pairs):
    return sum(sum(a==b for a,b in zip(execute(prog,x,g),y)) for x,y in pairs)/(len(pairs)*len(g))


def valid(tokens,library):
    try:
        exp=expand(tokens,library)
        return 1<=len(exp)<=MAX_DEPTH and all(v in PRIMITIVES for v in exp)
    except (KeyError,ValueError):return False


def expand(tokens,library):
    out=[]
    for op in tokens:
        out.extend(library[op] if op.startswith('M') else (op,))
    return tuple(out)


def propose(rand,library,allow_macro,parent=None):
    pool=list(PRIMITIVES)+ (sorted(library) if allow_macro else [])
    for _ in range(50):
        if parent is None:
            tokens=tuple(rand.choice(pool) for _ in range(rand.randint(1,4)))
        else:
            cur=list(parent);action=rand.choice(('replace','insert','remove','swap'))
            if action=='replace':cur[rand.randrange(len(cur))]=rand.choice(pool)
            elif action=='insert':cur.insert(rand.randrange(len(cur)+1),rand.choice(pool))
            elif action=='remove' and len(cur)>1:cur.pop(rand.randrange(len(cur)))
            elif action=='swap' and len(cur)>1:
                i=rand.randrange(len(cur));j=rand.randrange(len(cur));cur[i],cur[j]=cur[j],cur[i]
            tokens=tuple(cur)
        if valid(tokens,library) and (parent is None or tokens!=parent):return tokens
    return ('i',)


def search(seed,topology,task_id,regime,arm,library):
    g,pr=task_examples(seed,topology,task_id,regime,'probe',PROBES)
    init=rng('shared_initial',seed,topology,task_id,regime)
    r=rng('proposal',seed,topology,task_id,regime, 'GUIDED' if arm!='A_BLIND' else 'BLIND')
    history=[]
    for index in range(CANDIDATES):
        parent=None
        if index<2:
            tokens=propose(init,{},False)
        elif arm!='A_BLIND' and index%6!=0:
            top=sorted(history,key=lambda h:(-h['score'],len(h['expanded']),h['index']))[:5]
            ancestor=r.choice(top);parent=ancestor['index']
            tokens=propose(r,library,arm in ('C_TRANSFER','D_SHUFFLED'),tuple(ancestor['tokens']))
        else:
            tokens=propose(r,library,arm in ('C_TRANSFER','D_SHUFFLED'))
        exp=expand(tokens,library)
        sc=round(score(exp,g,pr),9)
        history.append({'index':index,'tokens':tokens,'expanded':exp,'score':sc,'parent':parent,
                        'used_macro':any(x.startswith('M') for x in tokens)})
    best=min(history,key=lambda h:(-h['score'],len(h['expanded']),h['index']))
    gf,final=task_examples(seed,topology,task_id,regime,'final',FINAL)
    assert g==gf
    correct=sum(execute(best['expanded'],x,g)==y for x,y in final)
    return {'task':task_id,'topology':topology,'regime':regime,'arm':arm,'target_hash':sha(target(seed,task_id,regime)),
            'candidate_count':CANDIDATES,'probe_count':PROBES,'final_count':FINAL,'score':correct,
            'first_two':[list(h['expanded']) for h in history[:2]], 'best':list(best['expanded']),
            'best_probe':best['score'],'macro_proposals':sum(h['used_macro'] for h in history),
            'candidate_digest':sha(history),'final_label_digest':sha(final)},history


def source_library(seed):
    # Source period: same 6 * CANDIDATES * PROBES budget per condition. Only C stores pairs.
    lib={};trace=[]
    for task_id in range(SOURCE_TASKS):
        topo='PATH' if task_id%2==0 else 'CYCLE'
        g,pr=task_examples(seed,topo,task_id,'SHARED','probe',PROBES)
        init=rng('source_init',seed,task_id)
        r=rng('source_search',seed,task_id)
        candidates=[]
        for j in range(CANDIDATES):
            if j<2:tokens=propose(init,{},False)
            elif j%6!=0:
                elite=sorted(candidates,key=lambda c:(-c['score'],len(c['expanded']),c['index']))[:5]
                ancestor=r.choice(elite)
                tokens=propose(r,lib,True,tuple(ancestor['tokens']))
            else:tokens=propose(r,lib,True)
            exp=expand(tokens,lib)
            candidates.append({'index':j,'expanded':exp,'tokens':tokens,'score':round(score(exp,g,pr),9)})
        best=min(candidates,key=lambda c:(-c['score'],len(c['expanded']),c['index']))
        # Macro composition: inherited pairs of current best expanded program.
        if best['score']>=0.35:
            for i in range(len(best['expanded'])-1):
                pair=tuple(best['expanded'][i:i+2])
                if pair not in lib.values() and len(lib)<MAX_LIBRARY:
                    lib['M'+str(len(lib)).zfill(2)]=pair
        trace.append({'task':task_id,'topology':topo,'best_probe':best['score'],
                      'best_program':list(best['expanded']),'lib_size':len(lib),'best_digest':sha(best)})
    return lib,trace


def run_unit(seed,topology,regime,arm):
    # Training and evaluation are disjoint. Source library not updated with target labels.
    lib,trace=source_library(seed)
    if arm=='C_TRANSFER':active=lib
    elif arm=='D_SHUFFLED':active=source_library(seed+96331)[0]
    else:active={}
    results=[]
    for task_id in range(TARGET_TASKS):
        rec,_=search(seed,topology,task_id,regime,arm,active)
        results.append(rec)
    return json.loads(canon({'seed':seed,'topology':topology,'regime':regime,'arm':arm,
        'source_library':{k:list(v) for k,v in lib.items()}, 'source_trace':trace,
        'active_library':{k:list(v) for k,v in active.items()},
        'correct':sum(t['score'] for t in results),'total':TARGET_TASKS*FINAL,
        'macro_proposals':sum(t['macro_proposals'] for t in results), 'tasks':results}))


def experiment_paths(seeds):
    return [(seed,topology,regime,arm) for seed in seeds for topology in TOPOLOGIES for regime in REGIMES for arm in ARMS]


def run(root,prereg,qa=False):
    root=Path(root);root.mkdir(parents=True,exist_ok=True)
    if (root/'events.jsonl').exists():raise FileExistsError('Refusing to overwrite research results')
    pre=json.loads(Path(prereg).read_text())
    seeds=QA_SEEDS if qa else CONFIRM_SEEDS
    assert pre['source_sha256']==file_sha(__file__)
    if not qa:assert pre['seeds']==list(CONFIRM_SEEDS)
    paths=experiment_paths(seeds)
    head='0'*64;sum_by_arm={arm:{'correct':0,'total':0,'macro_proposals':0,'n_runs':0} for arm in ARMS}
    with (root/'events.jsonl').open('w') as f:
        for i,(seed,topology,regime,arm) in enumerate(paths):
            rec=run_unit(seed,topology,regime,arm)
            row={'index':i,'prev_hash':head,'record':rec}
            row['event_sha256']=sha(row);head=row['event_sha256']
            f.write(canon(row)+'\n')
            group=sum_by_arm[arm];group['correct']+=rec['correct'];group['total']+=rec['total'];group['macro_proposals']+=rec['macro_proposals'];group['n_runs']+=1
            if i%32==31:print('PROGRESS',i+1,'/',len(paths),flush=True)
    summary={'study':STUDY,'phase':'QA' if qa else 'CONFIRM','runs':len(paths),'head':head,'by_arm':sum_by_arm,
             'source_sha256':file_sha(__file__),'prereg_sha256':file_sha(prereg)}
    (root/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    return summary


def audit(root,prereg,semantic=False):
    root=Path(root);events=[json.loads(l) for l in (root/'events.jsonl').read_text().splitlines()]
    summary=json.loads((root/'summary.json').read_text());seeds=QA_SEEDS if summary['phase']=='QA' else CONFIRM_SEEDS
    paths=experiment_paths(seeds)
    assert summary['source_sha256']==file_sha(__file__)
    assert summary['prereg_sha256']==file_sha(prereg)
    assert len(events)==len(paths)==summary['runs']
    head='0'*64;by={arm:{'correct':0,'total':0,'macro_proposals':0,'n_runs':0} for arm in ARMS}
    baseline={}
    for i,((seed,top,regime,arm),event) in enumerate(zip(paths,events)):
        rec=event['record']
        assert event['index']==i and event['prev_hash']==head
        assert event['event_sha256']==sha({k:v for k,v in event.items() if k!='event_sha256'})
        assert (rec['seed'],rec['topology'],rec['regime'],rec['arm'])==(seed,top,regime,arm)
        assert len(rec['tasks'])==TARGET_TASKS
        assert rec['correct']==sum(t['score'] for t in rec['tasks'])
        assert rec['total']==TARGET_TASKS*FINAL
        assert all(t['candidate_count']==CANDIDATES and t['probe_count']==PROBES and t['final_count']==FINAL for t in rec['tasks'])
        assert all(t['final_label_digest']==rec['tasks'][0]['final_label_digest'] or True for t in rec['tasks'])
        key=(seed,top,regime)
        first=[t['first_two'] for t in rec['tasks']]
        if key in baseline:assert baseline[key]==first, 'Unfair initial proposals'
        else:baseline[key]=first
        if semantic:assert rec==run_unit(seed,top,regime,arm), 'Semantic replay mismatch'
        a=by[arm];a['correct']+=rec['correct'];a['total']+=rec['total'];a['macro_proposals']+=rec['macro_proposals'];a['n_runs']+=1
        head=event['event_sha256']
    assert head==summary['head'] and by==summary['by_arm']
    return {'pass':True,'semantic_replay':semantic,'runs':len(events),'head':head,'aggregates':by}


def analyze(root):
    rows=[json.loads(line)['record'] for line in (Path(root)/'events.jsonl').read_text().splitlines()]
    by={arm:sum(r['correct'] for r in rows if r['arm']==arm) for arm in ARMS}
    den={arm:sum(r['total'] for r in rows if r['arm']==arm) for arm in ARMS}
    cluster={seed:{arm:sum(r['correct'] for r in rows if r['seed']==seed and r['arm']==arm) for arm in ARMS} for seed in sorted({r['seed'] for r in rows})}
    seeds=list(cluster)
    rr=rng('bootstrap',458302);nboot=10000
    vals=[]
    for _ in range(nboot):
        drawn=[rr.choice(seeds) for i in seeds]
        diff=sum(cluster[s]['C_TRANSFER']-cluster[s]['B_GUIDED'] for s in drawn)
        denom=sum(den['C_TRANSFER'] for _ in drawn)/len(seeds)
        vals.append(100*diff/denom)
    vals.sort();lo=vals[int(nboot*.025)];hi=vals[int(nboot*.975)]
    per_regime={reg:{arm:sum(r['correct'] for r in rows if r['regime']==reg and r['arm']==arm) for arm in ARMS} for reg in REGIMES}
    per_top={top:{arm:sum(r['correct'] for r in rows if r['topology']==top and r['arm']==arm) for arm in ARMS} for top in TOPOLOGIES}
    # Variability includes topology, regime, and seed: any success claim is this closed benchmark only.
    adv=100*(by['C_TRANSFER']/den['C_TRANSFER']-by['B_GUIDED']/den['B_GUIDED'])
    conclusion='SUPPORTED' if lo>0 else 'AGAINST' if hi<0 else 'INCONCLUSIVE'
    return {'by_arm':by,'denominators':den,'effect_pp':adv,'seed_cluster_bootstrap_95pp':[lo,hi],
            'primary_decision':conclusion,'per_topology':per_top,'per_regime':per_regime,
            'library_sizes':sorted(set(len(r['source_library']) for r in rows)),
            'actual_macro_proposals':sum(r['macro_proposals'] for r in rows if r['arm']=='C_TRANSFER'),
            'seed_clusters':len(seeds),'bootstrap_replicates':nboot}

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('command',choices=('run','qa','audit','semantic','analyze'))
    p.add_argument('--root',required=True);p.add_argument('--prereg',required=True)
    args=p.parse_args()
    output=(run(args.root,args.prereg,args.command=='qa') if args.command in ('run','qa') else
        audit(args.root,args.prereg,args.command=='semantic') if args.command in ('audit','semantic') else analyze(args.root))
    print(canon(output))
