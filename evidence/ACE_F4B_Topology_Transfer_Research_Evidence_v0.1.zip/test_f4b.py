import unittest
from unittest.mock import patch
import ace_f4b as a

class F4BTests(unittest.TestCase):
    def test_graph_path(self):
        g=a.graph(5,'PATH',0);self.assertEqual(g[0],(1,));self.assertEqual(g[-1],(len(g)-2,))
    def test_graph_cycle(self):
        g=a.graph(5,'CYCLE',0);self.assertEqual(len(g[0]),2)
    def test_graph_tree(self):
        g=a.graph(5,'TREE',0);self.assertEqual(sum(len(x) for x in g),2*(len(g)-1))
    def test_graph_dag(self):
        g=a.graph(5,'DAG',0);self.assertTrue(all(u<v for v,ns in enumerate(g) for u in ns))
    def test_program_depth(self):
        g=a.graph(5,'PATH',0);self.assertRaises(ValueError,a.execute,('n',)*5,(1,)*len(g),g)
    def test_identity(self):
        g=a.graph(5,'TREE',0);x=(2,)*len(g);self.assertEqual(a.execute(('i',),x,g),x)
    def test_determinism(self):
        self.assertEqual(a.run_unit(17,'TREE','SHARED','B_GUIDED'),a.run_unit(17,'TREE','SHARED','B_GUIDED'))
    def test_paired_first_two(self):
        v=[a.run_unit(17,'TREE','SHARED',arm) for arm in a.ARMS]
        first=[[r['first_two'] for r in x['tasks']] for x in v]
        self.assertEqual(first,[first[0]]*4)
    def test_target_permitted_same(self):
        for top in a.TOPOLOGIES:
            x=a.task_examples(11,top,0,'SHARED','final',a.FINAL)
            self.assertEqual(len(x[1]),a.FINAL)
    def test_source_macro_inherited(self):
        lib,trace=a.source_library(17);self.assertEqual(len(trace),a.SOURCE_TASKS)
        self.assertLessEqual(len(lib),a.MAX_LIBRARY)
        self.assertTrue(all(len(v)==2 for v in lib.values()))
    def test_no_final_selection_leak(self):
        source=a.search(17,'TREE',0,'SHARED','C_TRANSFER',{})[0]
        orig=a.task_examples
        def swapped(seed,top,tid,reg,kind,n):
            g,p=orig(seed,top,tid,reg,kind,n)
            if kind=='final':return g,tuple((x,tuple((v+3)%7 for v in y)) for x,y in p)
            return g,p
        with patch.object(a,'task_examples',side_effect=swapped):
            altered=a.search(17,'TREE',0,'SHARED','C_TRANSFER',{})[0]
        self.assertEqual(source['best'],altered['best'])
        self.assertEqual(source['candidate_digest'],altered['candidate_digest'])
    def test_novel_regime(self):
        self.assertNotEqual(a.target(17,0,'NOVEL'),a.target(17,0,'SHARED'))
    def test_budget(self):
        r=a.run_unit(17,'DAG','NOVEL','C_TRANSFER')
        self.assertEqual(len(r['tasks']),a.TARGET_TASKS)
        self.assertEqual(sum(t['candidate_count'] for t in r['tasks']),a.TARGET_TASKS*a.CANDIDATES)
        self.assertEqual(r['total'],a.TARGET_TASKS*a.FINAL)

if __name__=='__main__':unittest.main(verbosity=2)
