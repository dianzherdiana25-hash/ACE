# ACE F3.2 — Locked Confirmation Package (4 November 2026)

This is a **bounded human-authored DSL search experiment**, not an independently intelligent AI or proof of AGI. No model API or unsafe dynamic candidate code is used. Uses Python standard library only.

## Files

- `ace_f32.py`: F3.2 source (frozen before confirmation)
- `ace_f31.py`: unmodified F3.1 benchmark fixture and legacy controls
- `test_f32.py`: 20 engineering unit tests (QA seeds separate from confirmation)
- `audit_f32.py`: independent-of-proposal evidence cross-check (same human-authored fixture)
- `F32_PREREGISTRATION.json`: locked protocol and initial source/file hashes
- `development_exploration.py` and `development_results.json`: exploratory algorithm selection after initial candidate alignment correction
- `confirmation_evidence/`: 288 run logs, candidates, checkpoints and summary CSV/JSON
- `F3_2_Execution_Report_v0.1.md`: results, interpretation and limitations
- `ACE_F32_Confirm_Colab_v0.1.ipynb`: portable notebook (also distributed separately)

## Local reproduction

```sh
python -m unittest -q test_f32
python ace_f32.py confirm --root confirmation_evidence
python ace_f32.py verify --root confirmation_evidence
python audit_f32.py
```

Running `confirm` on the existing evidence resumes/idempotently verifies completed events; use a different `--root` to generate a new deterministic replication. A new root will produce same source-bound results on the same seeds.

## Scientific meaning

Archive Neighbor improves over a score-blind candidate proposer with reward-based final selection, but it **underperforms the legacy Guided Best search** on the new confirmation batch. It does not invent novel primitives or provide F4 structural generalization evidence.

## Costs and caution

No paid API required, but a hosted notebook is not guaranteed to run forever or have persistent runtime storage. Save the generated ZIP after Colab finishes. Do not open/reuse the F4 holdout for further tuning.
