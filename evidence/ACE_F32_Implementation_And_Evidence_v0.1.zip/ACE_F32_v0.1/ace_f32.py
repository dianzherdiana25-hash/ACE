"""ACE F3.2: locked within-template causal comparison of a feedback-guided
archive-neighbor candidate proposer versus F3.1 blind-best and guided-best.

All tasks, mutations, and candidate programs are human-designed. A candidate is
ONLY an integer in [0,15] interpreted by trusted ace_f31.py. No arbitrary code
is executed. No API, F4-held-out samples or external network are used.

The final confirmation set is reserved for exactly ONE confirmatory comparison.
Do not modify algorithms after examining its result and call it confirmatory.
"""
from __future__ import annotations
import argparse
import csv
import hashlib
import json
import os
import random
import sys
from pathlib import Path
from collections import defaultdict
import ace_f31 as fixture

STUDY = 'ACE-F3.2-20261104'
VERSION = '0.1.0'
FAMILIES = ('S','G')
MODES = ('ARCHIVE_NEIGHBOR','BLIND_BEST','GUIDED_BEST')
DEV_SEEDS = tuple(fixture.SEEDS)
QA_SEEDS = (810011, 810021)
CONFIRM_SEEDS = tuple(1380001 + i*10007 for i in range(48))
CANDIDATES = 10
PROBES = 5
FINALS = 24
FIXTURE_SHA = 'd7609cd44de741b5574248b6f637f262a8ee7000ad7b3a8ea3743191c74cab53'
# Config confirms code/fixture bytes by SHA; source files are frozen before confirm.
class IntegrityError(ValueError): pass

def canonical(x): return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False)
def hash_payload(x): return hashlib.sha256((x if isinstance(x,str) else canonical(x)).encode('utf8')).hexdigest()
def hash_file(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def jread(p):return json.loads(Path(p).read_text(encoding='utf8'))
def jwrite(path,obj):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_name('.'+path.name+'.tmp')
    with tmp.open('w',encoding='utf8') as f:
        f.write(canonical(obj)+'\n');f.flush();os.fsync(f.fileno())
    os.replace(tmp,path)

def archive_propose(seed,fam,history):
    """Read only prior candidate genomes and numeric probe scores.
    Prioritize novel 1-bit neighbors of highest-reward archive members.
    During ties, prioritize proximity to the starting genome and lower mask.
    No target labels, holdouts or external tools are used by the proposal rule.
    """
    step=len(history)
    initial=fixture.rng_for('initial',seed,fam).randrange(16)
    if step==0:return initial,None,'shared_initial'
    if step==1:
        bit=fixture.rng_for('warmup',seed,fam).randrange(4)
        return initial^(1<<bit),history[-1]['candidate_id'],'shared_warmup'
    used={c['genome'] for c in history}
    options=[m for m in range(16) if m not in used]
    if not options:
        return history[-1]['genome'],history[-1]['candidate_id'],'exhausted'
    feasible=[]
    for m in options:
        parents=[c for c in history if (m^c['genome']).bit_count()==1]
        if parents:
            parent=max(parents,key=lambda c:c['mean_reward'])
            feasible.append((parent['mean_reward'],-(m^initial).bit_count(),-m,m,parent))
    if feasible:
        score,distance,mask_order,m,parent=max(feasible)
        return m,parent['candidate_id'],'score_guided_archive_neighbor'
    m=max(options,key=lambda m:(min((m^u).bit_count() for u in used),-m))
    return m,history[-1]['candidate_id'],'novelty_restart'

def candidate_sequence(seed,fam,mode):
    if mode not in MODES or fam not in FAMILIES:raise ValueError('unknown arm or family')
    if mode!='ARCHIVE_NEIGHBOR':
        return fixture.candidate_sequence(seed,fam,mode)
    probes=[fixture.generate_example(seed,fam,'probe',i) for i in range(PROBES)]
    history=[]
    for generation in range(CANDIDATES):
        mask,parent,origin=archive_propose(seed,fam,history)
        rewards=fixture.grade(seed,fam,mask,probes)
        candidate={
            'generation':generation,'family':fam,'genome':mask,'parent_id':parent,
            'origin':origin,'probe_rewards':rewards,
            'mean_reward':round(sum(rewards)/len(rewards),8),
            'probe_ids':[p['input_id'] for p in probes]
        }
        candidate['candidate_id']='c_'+fixture.sha({k:v for k,v in candidate.items() if k!='candidate_id'})[:18]
        history.append(candidate)
    return history

def choose_best(hist):return max(hist,key=lambda c:(c['mean_reward'],-c['generation']))

def events_for(seed,fam,mode):
    hist=candidate_sequence(seed,fam,mode)
    chosen=choose_best(hist)
    events=[{'type':'CANDIDATE','candidate':c} for c in hist]
    events.append({'type':'FREEZE','winner_id':chosen['candidate_id'],'mask':chosen['genome'],
                   'probe_mean':chosen['mean_reward']})
    # Final test is accessed only after the candidate choice is frozen.
    result=fixture.evaluate_final(seed,fam,chosen['genome'])
    events.append({'type':'EVALUATE','winner_id':chosen['candidate_id'],
                   'result':result})
    return events

def run_path(root,seed,fam,mode):return Path(root)/'runs'/str(seed)/fam/mode

def config(seed,fam,mode):
    if seed not in (CONFIRM_SEEDS + QA_SEEDS) or fam not in FAMILIES or mode not in MODES:
        raise ValueError('unregistered configuration')
    if hash_file(Path(__file__).parent/'ace_f31.py')!=FIXTURE_SHA:
        raise IntegrityError('F3.1 fixture has changed')
    return {'study':STUDY,'version':VERSION,'seed':seed,'family':fam,'mode':mode,
            'candidates':CANDIDATES,'probe_count_per_candidate':PROBES,
            'final_cases':FINALS,'eval_budget':CANDIDATES*PROBES,
            'fixture_sha256':FIXTURE_SHA,'policy_source_sha256':hash_file(__file__),
            'f4_heldout':'NOT_ACCESSED','api_calls':0,'additional_cost_idr':0}

def read_events(folder):
    p=Path(folder)/'events.jsonl'
    if not p.exists():return []
    rows=[];head='0'*64
    for line in p.read_text(encoding='utf8').splitlines():
        try:x=json.loads(line)
        except ValueError as exc:raise IntegrityError('invalid event') from exc
        if x.get('index')!=len(rows)+1 or x.get('prev')!=head:
            raise IntegrityError('event order or hash-link changed')
        if x.get('hash')!=hash_payload({k:v for k,v in x.items() if k!='hash'}):
            raise IntegrityError('event hash mismatch')
        head=x['hash'];rows.append(x)
    return rows

def verify(root,seed,fam,mode,complete=False):
    folder=run_path(root,seed,fam,mode)
    cfg=config(seed,fam,mode)
    if jread(folder/'config.json')!=cfg:raise IntegrityError('config mismatch')
    saved=read_events(folder);expected=events_for(seed,fam,mode)
    if len(saved)>len(expected):raise IntegrityError('unexpected events')
    for i,event in enumerate(saved):
        if event['config_sha256']!=hash_payload(cfg) or event['payload']!=expected[i]:
            raise IntegrityError(f'semantic mismatch: {i}')
        if event['payload']['type']=='CANDIDATE':
            c=event['payload']['candidate']
            if jread(folder/'candidates'/(c['candidate_id']+'.json'))!=c:
                raise IntegrityError('candidate mismatch')
    cp=folder/'checkpoint.json'
    if cp.exists():
        state=jread(cp);idx=state['last_index']
        if not 0<=idx<=len(saved):raise IntegrityError('checkpoint index mismatch')
        if state['head']!=(saved[idx-1]['hash'] if idx else '0'*64):
            raise IntegrityError('checkpoint head mismatch')
    if complete and len(saved)!=len(expected):raise IntegrityError('incomplete')
    if len(saved)==len(expected) and (not cp.exists() or jread(cp)['status']!='COMPLETED'):
        raise IntegrityError('completion checkpoint missing')
    return {'seed':seed,'family':fam,'mode':mode,'events':len(saved),
            'complete':len(saved)==len(expected),'head':saved[-1]['hash'] if saved else '0'*64}

def run(root,seed,fam,mode,stop_after=None,crash=False):
    folder=run_path(root,seed,fam,mode);folder.mkdir(parents=True,exist_ok=True)
    cfg=config(seed,fam,mode)
    if (folder/'config.json').exists():
        if jread(folder/'config.json')!=cfg:raise IntegrityError('resume config mismatch')
    else:jwrite(folder/'config.json',cfg)
    verify(root,seed,fam,mode)
    events=read_events(folder);expected=events_for(seed,fam,mode)
    writes=0
    for payload in expected[len(events):]:
        if stop_after is not None and writes>=stop_after:break
        event={'index':len(events)+1,'prev':events[-1]['hash'] if events else '0'*64,
               'config_sha256':hash_payload(cfg),'payload':payload}
        event['hash']=hash_payload(event)
        if payload['type']=='CANDIDATE':
            c=payload['candidate'];jwrite(folder/'candidates'/(c['candidate_id']+'.json'),c)
        with (folder/'events.jsonl').open('a',encoding='utf8') as f:
            f.write(canonical(event)+'\n');f.flush();os.fsync(f.fileno())
        events.append(event);writes+=1
        if crash and writes==1:raise InterruptedError('simulated loss after event append')
        jwrite(folder/'checkpoint.json',{'last_index':len(events),'head':event['hash'],
                'status':'COMPLETED' if len(events)==len(expected) else 'CHECKPOINTED'})
    return verify(root,seed,fam,mode,complete=(stop_after is None))

def summary(root):
    rows=[];heads=[]
    for seed in CONFIRM_SEEDS:
        for fam in FAMILIES:
            for mode in MODES:
                status=verify(root,seed,fam,mode,complete=True)
                events=read_events(run_path(root,seed,fam,mode))
                hist=[x['payload']['candidate'] for x in events if x['payload']['type']=='CANDIDATE']
                val=events[-1]['payload']['result']
                rows.append({'seed':seed,'family':fam,'mode':mode,'correct':val['correct'],
                       'total':val['total'],'winner_mask':events[-2]['payload']['mask'],
                       'candidate_unique':len({c['genome'] for c in hist}),
                       'case_manifest_sha256':val['case_manifest_sha256'],
                       'head':status['head']})
                heads.append(status['head'])
    results={mode:{'correct':sum(x['correct'] for x in rows if x['mode']==mode),
                   'total':sum(x['total'] for x in rows if x['mode']==mode)} for mode in MODES}
    paired=[]
    for seed in CONFIRM_SEEDS:
        for fam in FAMILIES:
            by={r['mode']:r['correct'] for r in rows if r['seed']==seed and r['family']==fam}
            paired.append({'seed':seed,'family':fam,
                 'archive_minus_blind':by['ARCHIVE_NEIGHBOR']-by['BLIND_BEST'],
                 'archive_minus_legacy_guided':by['ARCHIVE_NEIGHBOR']-by['GUIDED_BEST']})
    # Cluster by seed (includes both families). Seed-level, paired uncertainty.
    seed_effect=[sum(x['archive_minus_blind'] for x in paired if x['seed']==seed)
                 for seed in CONFIRM_SEEDS]
    r=random.Random(13790)
    boot=[]
    for _ in range(10000):
        boot.append(sum(seed_effect[r.randrange(len(seed_effect))] for _ in seed_effect)
             /(len(CONFIRM_SEEDS)*len(FAMILIES)*FINALS))
    boot.sort()
    delta=(results['ARCHIVE_NEIGHBOR']['correct']-results['BLIND_BEST']['correct']) / (len(CONFIRM_SEEDS)*len(FAMILIES)*FINALS)
    result={'study':STUDY,'analysis':'ONE_LOCKED_CONFIRMATION','seeds':len(CONFIRM_SEEDS),
        'families':list(FAMILIES),'modes':list(MODES),'runs':len(rows),
        'candidate_evaluations':len(rows)*CANDIDATES,
        'probe_evaluations':len(rows)*CANDIDATES*PROBES,
        'final_evaluations':len(rows)*FINALS,
        'score':results,
        'archive_minus_blind_ppt':round(100*delta,4),
        'seed_cluster_bootstrap_95pct_diff_pp':[round(boot[249]*100,4),round(boot[9749]*100,4)],
        'archive_vs_blind_paired_seed_family':{
            'better':sum(x['archive_minus_blind']>0 for x in paired),
            'equal':sum(x['archive_minus_blind']==0 for x in paired),
            'worse':sum(x['archive_minus_blind']<0 for x in paired)},
        'source_sha256':hash_file(__file__),'fixture_sha256':FIXTURE_SHA,
        'all_heads_sha256':hash_payload(heads),
        'f4_heldout':'NOT_ACCESSED','model_api_calls':0,'additional_api_cost_idr':0}
    folder=Path(root)/'reports';folder.mkdir(parents=True,exist_ok=True)
    jwrite(folder/'confirmation_results.json',result)
    with (folder/'run_rows.csv').open('w',newline='',encoding='utf8') as file:
        w=csv.DictWriter(file,fieldnames=rows[0].keys());w.writeheader();w.writerows(rows)
    with (folder/'paired_units.csv').open('w',newline='',encoding='utf8') as file:
        w=csv.DictWriter(file,fieldnames=paired[0].keys());w.writeheader();w.writerows(paired)
    return result

def main():
    p=argparse.ArgumentParser();p.add_argument('action',choices=['confirm','verify','summary'])
    p.add_argument('--root',default='F32_confirmation_evidence');a=p.parse_args()
    if a.action=='confirm':
        for seed in CONFIRM_SEEDS:
            for fam in FAMILIES:
                for mode in MODES:run(a.root,seed,fam,mode)
        print(canonical(summary(a.root)))
    elif a.action=='verify':
        for seed in CONFIRM_SEEDS:
            for fam in FAMILIES:
                for mode in MODES:verify(a.root,seed,fam,mode,complete=True)
        print(canonical({'pass':True,'runs':len(CONFIRM_SEEDS)*len(FAMILIES)*len(MODES)}))
    else:print(canonical(summary(a.root)))
if __name__=='__main__':main()
