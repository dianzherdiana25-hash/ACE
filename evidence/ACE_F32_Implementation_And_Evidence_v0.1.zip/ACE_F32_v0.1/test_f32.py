import tempfile,unittest,copy
from pathlib import Path
import ace_f32 as m
import ace_f31 as old

class TestF32(unittest.TestCase):
    def test_seed_separation(self):self.assertFalse(set(m.DEV_SEEDS)&set(m.CONFIRM_SEEDS))
    def test_families(self):self.assertEqual(m.FAMILIES,('S','G'))
    def test_budget(self):self.assertEqual((m.CANDIDATES,m.PROBES,m.FINALS),(10,5,24))
    def test_baseline_fixture_hash(self):self.assertEqual(m.hash_file(Path(m.__file__).parent/'ace_f31.py'),m.FIXTURE_SHA)
    def test_initial_equal(self):
        for fam in m.FAMILIES:
            for seed in m.DEV_SEEDS[:3]:
                a=m.candidate_sequence(seed,fam,'ARCHIVE_NEIGHBOR')
                b=m.candidate_sequence(seed,fam,'BLIND_BEST')
                c=m.candidate_sequence(seed,fam,'GUIDED_BEST')
                self.assertEqual([x['genome'] for x in a[:2]],[x['genome'] for x in b[:2]])
                self.assertEqual([x['genome'] for x in a[:2]],[x['genome'] for x in c[:2]])
    def test_distinct_all_masks(self):
        for fam in m.FAMILIES:
            for seed in m.DEV_SEEDS[:4]:
                a=m.candidate_sequence(seed,fam,'ARCHIVE_NEIGHBOR')
                self.assertEqual(len({x['genome'] for x in a}),10)
    def test_all_budget_probes(self):
        for mode in m.MODES:
            seq=m.candidate_sequence(m.DEV_SEEDS[0],'S',mode)
            self.assertEqual(len(seq),10)
            self.assertEqual(sum(len(c['probe_rewards']) for c in seq),50)
    def test_feedback_sensitive(self):
        found=False
        for s in m.DEV_SEEDS:
            hist=m.candidate_sequence(s,'S','ARCHIVE_NEIGHBOR')[:4]
            x=m.archive_propose(s,'S',hist)[0]
            manipulated=copy.deepcopy(hist)
            for c in manipulated:c['mean_reward']=0
            manipulated[0]['mean_reward']=10
            if m.archive_propose(s,'S',manipulated)[0]!=x:found=True;break
        self.assertTrue(found)
    def test_blind_controls_score_independent_proposals(self):
        # Existing fixture's BLIND_BEST must not condition proposals on scores.
        hist=old.candidate_sequence(m.DEV_SEEDS[0],'S','BLIND_BEST')[:5]
        a=old.propose(m.DEV_SEEDS[0],'S','BLIND_BEST',hist)
        for c in hist:c['mean_reward']=-2
        self.assertEqual(old.propose(m.DEV_SEEDS[0],'S','BLIND_BEST',hist),a)
    def test_candidate_replay(self):
        for fam in m.FAMILIES:
            a=m.candidate_sequence(m.DEV_SEEDS[0],fam,'ARCHIVE_NEIGHBOR')
            b=m.candidate_sequence(m.DEV_SEEDS[0],fam,'ARCHIVE_NEIGHBOR')
            self.assertEqual(a,b)
    def test_f4_closed(self):
        with self.assertRaises(AssertionError):old.generate_example(m.DEV_SEEDS[0],'S','held-out',0)
    def test_config_not_dev_seed(self):
        with self.assertRaises(ValueError):m.config(m.DEV_SEEDS[0],'S','ARCHIVE_NEIGHBOR')
    def test_run_verify(self):
        with tempfile.TemporaryDirectory() as d:
            x=m.run(d,m.QA_SEEDS[0],'S','ARCHIVE_NEIGHBOR')
            self.assertTrue(x['complete']);self.assertEqual(x['events'],12)
    def test_resume(self):
        with tempfile.TemporaryDirectory() as d:
            s=m.QA_SEEDS[1];m.run(d,s,'G','BLIND_BEST',stop_after=4)
            self.assertTrue(m.run(d,s,'G','BLIND_BEST')['complete'])
    def test_injected_crash(self):
        with tempfile.TemporaryDirectory() as d:
            s=m.QA_SEEDS[0]
            with self.assertRaises(InterruptedError):m.run(d,s,'G','ARCHIVE_NEIGHBOR',crash=True)
            self.assertTrue(m.run(d,s,'G','ARCHIVE_NEIGHBOR')['complete'])
    def test_event_tamper(self):
        with tempfile.TemporaryDirectory() as d:
            s=m.QA_SEEDS[0];m.run(d,s,'S','ARCHIVE_NEIGHBOR')
            p=m.run_path(d,s,'S','ARCHIVE_NEIGHBOR')/'events.jsonl';p.write_text(p.read_text().replace('"genome":','"forged_genome":',1))
            with self.assertRaises(m.IntegrityError):m.verify(d,s,'S','ARCHIVE_NEIGHBOR')
    def test_candidate_tamper(self):
        with tempfile.TemporaryDirectory() as d:
            s=m.QA_SEEDS[0];m.run(d,s,'S','ARCHIVE_NEIGHBOR')
            p=next((m.run_path(d,s,'S','ARCHIVE_NEIGHBOR')/'candidates').glob('*.json'));p.write_text('{"tampered":true}')
            with self.assertRaises(m.IntegrityError):m.verify(d,s,'S','ARCHIVE_NEIGHBOR')
    def test_cp_tamper(self):
        with tempfile.TemporaryDirectory() as d:
            s=m.QA_SEEDS[0];m.run(d,s,'S','BLIND_BEST')
            p=m.run_path(d,s,'S','BLIND_BEST')/'checkpoint.json';x=m.jread(p);x['head']='0'*64;m.jwrite(p,x)
            with self.assertRaises(m.IntegrityError):m.verify(d,s,'S','BLIND_BEST')
    def test_confirm_frozen_seed_count(self):self.assertEqual(len(m.CONFIRM_SEEDS),48)
    def test_deterministic_final(self):
        a=old.evaluate_final(m.QA_SEEDS[0],'S',7)
        self.assertEqual(a,old.evaluate_final(m.QA_SEEDS[0],'S',7))

if __name__=='__main__':unittest.main(verbosity=2)
