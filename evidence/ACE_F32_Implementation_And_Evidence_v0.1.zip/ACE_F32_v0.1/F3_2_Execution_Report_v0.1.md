# ACE F3.2 — Laporan Eksperimen Konfirmatori

**Tanggal:** 4 November 2026  
**Keputusan:** `ENGINEERING_PASS / PRIMARY_FEEDBACK_CONTROL_ADVANTAGE_SUPPORTED / NO_IMPROVEMENT_OVER_BEST_LEGACY / AUTONOMOUS_INVENTION_NOT_PROVEN`  
**Cakupan:** pencarian evolusioner DSL empat bit pada tugas sintetis sejenis; **bukan** F4, AGI, atau penemuan metode bebas.

## 1. Pertanyaan penelitian

Dapatkah pencarian kandidat *Archive Neighbor*, yang memakai skor probe terdahulu untuk memprioritaskan tetangga satu-bit yang belum diuji, mengungguli pencarian proposal yang tidak membaca skor, tetapi menggunakan skor untuk memilih kandidat akhir? Pembanding utama adalah `BLIND_BEST` dari F3.1; pembanding sekunder adalah `GUIDED_BEST` dari F3.1.

## 2. Pemisahan pengembangan dan konfirmasi

- **Pengembangan:** 24 seed F3.1 sebelumnya, dua keluarga S (simbolik) dan G (graf). Tiga strategi baru dicoba: `ACTIVE_FACTOR`, `KERNEL_UCB`, `ARCHIVE_NEIGHBOR`. Pada eksperimen eksplorasi awal, kandidat awal setiap strategi belum disejajarkan dengan kontrol; angka `ARCHIVE_NEIGHBOR = 1096/1152` dari tahap tersebut **tidak dipakai** sebagai perbandingan utama.
- **Koreksi metodologi sebelum konfirmasi:** dua kandidat awal disamakan antar-kebijakan. Hasil pengembangan terkoreksi: `ARCHIVE_NEIGHBOR = 1029/1152`, `KERNEL_UCB = 1000/1152`, `ACTIVE_FACTOR = 933/1152`, `BLIND_BEST = 966/1152`, dan `GUIDED_BEST = 958/1152`.
- **Pembekuan:** sebelum evaluasi konfirmatori, `F32_PREREGISTRATION.json` mencatat metode terpilih, seed baru, kontras primer, aturan seleksi, anggaran, dan inferensi. SHA-256 manifest adalah `94452b5f06565c35a7ba72663b76e898c89af0bc6fa5dc9621ec30ea308d4c71`; hash sumber algoritma beku `5b83fdf6d59a31796a8d3d6542722deda1da54e96b1abd573e7bde72b6c5258f`.
- **Konfirmasi:** 48 seed baru, berbeda dari seed pengembangan dan seed pemeriksaan unit. Satu batch konfirmatori dijalankan setelah pembekuan, tanpa memilih ulang kebijakan berdasarkan hasilnya.

Manifest dan hash dibuat dalam sesi eksekusi ini; ini adalah audit internal, **bukan preregistrasi bertanda waktu yang dikonfirmasi pihak ketiga**.

## 3. Kontrak eksperimen

Setiap seed, keluarga, dan kebijakan menjalankan **10 kandidat × 5 soal probe = 50 evaluasi probe**, lalu menilai satu kandidat yang dibekukan pada **24 kasus baru dalam grammar yang sama**. Total 48 seed × 2 keluarga × 3 kebijakan = **288 run**; **2.880 kandidat**, **14.400 evaluasi probe**, dan **6.912 kasus evaluasi akhir**.

Semua kebijakan memakai dua proposal awal identik, fungsi reward yang sama, grammar DSL empat bit yang sama, dan aturan pemenang yang sama: rata-rata skor probe tertinggi; bila seri, pilih generasi paling awal. `BLIND_BEST` hanya memakai skor untuk pilihan akhir, bukan untuk merencanakan proposal. `ARCHIVE_NEIGHBOR` memanfaatkan skor kandidat pendahulu saat memilih tetangga mutasi berikutnya. `GUIDED_BEST` adalah kebijakan induk-terbaik F3.1 yang tidak diubah.

Semua kandidat adalah mask integer dan dieksekusi melalui interpreter tepercaya; **tidak ada eksekusi Python buatan kandidat**. Semua primitive dan target laten dibuat manusia. Tidak ada API model, GPU, atau pembelian layanan. Batas kuantitas panggilan penilai sama, tetapi **biaya CPU aktual per algoritma tidak dipaksa identik**.

## 4. Hasil konfirmatori utama

| Kebijakan | Benar / 2.304 | Akurasi |
|---|---:|---:|
| `BLIND_BEST` — kontrol primer | 1.795 | 77,91% |
| `ARCHIVE_NEIGHBOR` — F3.2 | **2.050** | **88,98%** |
| `GUIDED_BEST` — pembanding lama | **2.142** | **92,97%** |

**Kontras primer beku, Archive − Blind:** `+255/2304 = +11,0677 poin persentase`. Interval ketidakpastian bootstrap 95% berkelompok menurut seed (10.000 resampling dengan mempertahankan dua keluarga dalam satu cluster): **[+1,3455; +20,5295] poin**. Dengan aturan keputusan yang telah dikunci, keunggulan terhadap kontrol primer *didukung* pada benchmark ini.

**Kontras sekunder, Archive − Guided:** `−92/2304 = −3,9931 poin`. Jadi F3.2 **tidak mengungguli kebijakan feedback-guided lama yang merupakan pembanding lebih kuat**.

Rincian keluarga tugas:

| Keluarga | Archive Neighbor | Blind + Best | Guided Best |
|---|---:|---:|---:|
| S — simbolik, masing-masing /1.152 | 931 | 679 | 1.035 |
| G — graf, masing-masing /1.152 | 1.119 | 1.116 | 1.107 |

Keunggulan Archive terhadap Blind terutama berasal dari **simbolik** (+252 jawaban), sedangkan graf hanya +3. Dengan demikian, keunggulan agregat tidak boleh ditafsirkan seragam lintas domain. Pada 96 pasangan seed×keluarga, Archive lebih tinggi pada 20, seri pada 66, dan lebih rendah pada 10.

## 5. Pengujian teknis dan pemeriksaan silang

- **20/20 tes rekayasa lulus**, meliputi ketetapan konfigurasi dan anggaran, dua kandidat awal sama, pengaruh skor pada proposal, ketidakbergantungan proposal kontrol dari skor, batas DSL, pemulihan, serta penolakan log/artefak yang diubah.
- **288/288 run lolos replay semantik** menggunakan implementasi F3.2 beku.
- Skrip pembaca independen dari mesin proposal (`audit_f32.py`) membaca dan mengecek ulang **3.456 event**, **2.880 kandidat**, **14.400 skor probe**, **6.912 skor akhir**, semua checksum event dan checkpoint; hasilnya identik. Auditor ini masih memakai oracle/generator F3.1 yang sama, jadi **bukan pengujian semantik oleh penilai eksternal**.
- Semua kode sumber, hasil pengembangan, konfigurasi, laporan, dan dataset konfirmatori tercatat dalam paket bukti. Bank *held-out* F4 tidak dibuat atau diakses.
- Pada eksperimen ini tidak ada perubahan ke akun pengguna, repositori, atau biaya API berbayar.

## 6. Interpretasi ilmiah

1. **Mekanisme terbukti berfungsi dalam batas DSL:** skor probe memengaruhi kandidat yang dicari. Dibanding `BLIND_BEST`, ini berkaitan dengan keuntungan evaluasi yang nyata pada tugas sintetis sejenis, dengan keterbandingan anggaran pemanggilan penilai.
2. **Bukan perbaikan metode terbaik yang tersedia:** `GUIDED_BEST` lama mengungguli F3.2 secara agregat pada konfirmasi baru. Karena itu jangan menyebut Archive Neighbor lebih unggul secara umum atau keberhasilan optimasi algoritma penelitian.
3. **Belum menemukan metode baru:** algoritma pencarian, primitive, target laten, dan keluarga masalah semuanya telah diprogram manusia. Program yang diwariskan hanyalah konfigurasi DSL empat bit.
4. **Belum mengukur generalisasi struktural:** soal evaluasi akhir adalah instans baru dari grammar yang sama; *held-out* F4 sengaja tetap tertutup.
5. **Pembatas sumber data dan kausalitas:** perbandingan antar-kebijakan merupakan eksperimen komputasi terkontrol, tetapi tidak mengisolasi satu komponen tunggal dari semua perbedaan prosedur pencarian. Interval hanya mencerminkan resampling seed sintetis yang dipilih, bukan seluruh tugas nyata.

## 7. Keputusan gerbang

| Gerbang | Status |
|---|---|
| F3.2 — implementasi dan reproduksibilitas internal | **PASS** |
| F3.2 — keunggulan atas kontrol primer Blind + Best | **SUPPORTED, DOMAIN-LIMITED** |
| F3.2 — lebih baik daripada Guided Best lama | **NO** |
| F3 — penciptaan metode baru secara otonom | **NOT PROVEN** |
| F4 — generalisasi out-of-template/struktur berbeda | **NOT RUN — HOLD** |

**Langkah riset yang tepat:** jangan memoles angka ini menjadi klaim evolusi kecerdasan. Jika tujuan berikutnya adalah menguji penemuan kemampuan baru, generasi penelitian selanjutnya harus memperluas representasi di luar empat bit dan menguji kemampuan menciptakan atau menyusun primitive yang sebelumnya tidak tersedia, dengan kontrol kuat (termasuk Guided Best), anggaran setara, dan pengujian struktural tertutup.
