"""ACE F3.1 feedback-directed candidate search (Python stdlib only).

This is bounded program search, not LLM-driven invention/AGI. Separately generated
within-family test instances are NOT the sealed F4 out-of-family held-out set.
No code supplied by a candidate is executed. Only integer DSL masks are read.
"""
from __future__ import annotations
import argparse
import csv
import difflib
import hashlib
import json
import os
import random
from pathlib import Path
from collections import Counter

STUDY = 'ACE-F3.1-20261104'
VERSION = '0.1.0'
FAMILIES = ('S','G')
MODES = ('GUIDED_BEST','BLIND_BEST','BLIND_LAST')
SEEDS = tuple([1729,2027,4093]+[5000+i*37 for i in range(21)])
CANDIDATES = 10
TRAIN_EXAMPLES = 5
TEST_EXAMPLES = 24
GENE_COUNT = 4
EVALS_PER_FAMILY = CANDIDATES*TRAIN_EXAMPLES
PAID_COST_IDR = 0

class IntegrityError(ValueError): pass

def canon(x): return json.dumps(x, sort_keys=True, separators=(',',':'),ensure_ascii=False,allow_nan=False)
def sha(x): return hashlib.sha256((x if isinstance(x,bytes) else (x if isinstance(x,str) else canon(x)).encode('utf8') if not isinstance(x,bytes) else x)).hexdigest()
def file_sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def write_json(path,obj):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_name('.'+path.name+'.tmp')
    with tmp.open('w',encoding='utf8') as f:
        f.write(canon(obj)+'\n');f.flush();os.fsync(f.fileno())
    os.replace(tmp,path)
def read_json(path): return json.loads(Path(path).read_text(encoding='utf8'))
def rng_for(*parts): return random.Random(int(sha('|'.join(map(str,parts)))[:16],16))

def hidden_target(seed,fam):
    # Latent fixture for a closed-form benchmark, NEVER passed to proposal code.
    return rng_for(STUDY,'target',seed,fam).randrange(1<<GENE_COUNT)

def generate_example(seed,fam,split,idx):
    assert split in ('probe','within_template_test'), 'F4 held-out not available'
    r=rng_for(STUDY,'example',seed,fam,split,idx)
    if fam=='S':
        pool='aaabbcde'
        tokens=[r.choice(pool) for _ in range(r.randint(5,13))]
        return {'input_id':f'{seed}-{fam}-{split}-{idx}','tokens':tokens}
    # Trust-authored small graph. Each instance uses random positive edge weights.
    names=('S','A','B','C','D','T')
    edges=[('S','A'),('A','T'),('S','B'),('B','T'),('S','C'),('C','T'),
           ('S','D'),('D','T'),('A','C'),('B','C'),('B','D'),('D','C'),('S','T')]
    weights=[[u,v,r.randint(1,9)] for u,v in edges]
    return {'input_id':f'{seed}-{fam}-{split}-{idx}','nodes':list(names),'edges':weights}

def symbolic_program(problem,mask):
    a=list(problem['tokens'])
    if mask & 1: a=list(dict.fromkeys(a))
    if mask & 2:
        for i in range(0,len(a)-1,2):a[i],a[i+1]=a[i+1],a[i]
    if mask & 4 and a:a=a[1:]+a[:1]
    if mask & 8:a=a[::-1]
    return a

def graph_program(problem,mask):
    graph={v:[] for v in problem['nodes']}
    for u,v,w in problem['edges']:
        graph[u].append((v,w));graph[v].append((u,w))
    choices=[]; stack=[('S',['S'],0)]
    while stack:
        node,path,cost=stack.pop()
        if node=='T':
            if (mask&1) and 'C' not in path:continue
            if (mask&2) and len(path)-1>2:continue
            if (mask&8) and 'B' in path:continue
            choices.append((cost,path));continue
        for nxt,w in graph[node]:
            if nxt in path:continue
            if (mask&2) and len(path)>=3:continue
            stack.append((nxt,path+[nxt],cost+w))
    if not choices:return {'reachable':False,'path':[],'cost':None}
    if mask&4:
        best=min(choices,key=lambda c:(len(c[1])-1,c[0],tuple(c[1])))
    else:
        best=min(choices,key=lambda c:(c[0],len(c[1])-1,tuple(c[1])))
    return {'reachable':True,'path':best[1],'cost':best[0]}

def program(fam,task,mask):
    if type(mask)!=int or not 0<=mask<16:raise ValueError('invalid 4-bit DSL')
    if fam=='S':return symbolic_program(task,mask)
    if fam=='G':return graph_program(task,mask)
    raise ValueError('bad family')

def fitness(a,b,fam):
    if a==b:return 1.0
    if fam=='S':return round(.35*difflib.SequenceMatcher(None,a,b,autojunk=False).ratio(),6)
    if a['reachable']!=b['reachable']:return 0.0
    if not a['reachable']:return 1.0
    overlap=len(set(a['path']) & set(b['path']))/len(set(a['path']) | set(b['path']))
    distance=abs(a['cost']-b['cost'])
    return round(.15*overlap + .1/(1+distance),6)

def grade(seed,fam,mask,tasks):
    # Only per-example numeric rewards returned to the search policy; no labels.
    target=hidden_target(seed,fam)
    return [fitness(program(fam,t,mask),program(fam,t,target),fam) for t in tasks]

def propose(seed,fam,mode,history):
    """Score-informed parent selection (guided) vs score-blind random walk.
    First two proposals identical by construction. Generation >1 uses history;
    guided policy chooses a top-scoring *parent*, not a pre-fixed generation.
    """
    step=len(history)
    initial=rng_for('initial',seed,fam).randrange(16)
    if step==0:return (initial,None,'initial')
    if step==1:
        bit=rng_for('warmup',seed,fam).randrange(4)
        return (initial^(1<<bit),history[-1]['candidate_id'],'shared_warmup')
    if mode=='GUIDED_BEST':
        # Use score to choose the ancestor from which the next mutation begins.
        parent=max(history,key=lambda c:(c['mean_reward'],-c['generation']))
    else:
        # Identical query budget but no reward-informed proposals.
        parent=history[-1]
    used={c['genome'] for c in history}
    rr=rng_for('mutation',seed,fam,step)
    bits=list(range(4));rr.shuffle(bits)
    genome=None
    for bit in bits:
        test=parent['genome']^(1<<bit)
        if test not in used:genome=test;break
    if genome is None:
        # Bounded novelty restart; same rule for both arms.
        pool=[i for i in range(16) if i not in used]
        if pool:genome=pool[rr.randrange(len(pool))]
        else:genome=parent['genome']
    return genome,parent['candidate_id'],'feedback_parent' if mode=='GUIDED_BEST' else 'recency_parent'

def candidate_sequence(seed,fam,mode):
    assert mode in MODES
    probes=[generate_example(seed,fam,'probe',i) for i in range(TRAIN_EXAMPLES)]
    history=[]
    for generation in range(CANDIDATES):
        genome,parent,origin=propose(seed,fam,mode,history)
        rewards=grade(seed,fam,genome,probes)
        c={'generation':generation,'family':fam,'genome':genome,'parent_id':parent,
           'origin':origin,'probe_rewards':rewards,'mean_reward':round(sum(rewards)/len(rewards),8),
           'probe_ids':[p['input_id'] for p in probes]}
        c['candidate_id']='c_'+sha({k:v for k,v in c.items() if k!='candidate_id'})[:18]
        history.append(c)
    return history

def winner(history,mode):
    if mode=='BLIND_LAST':return history[-1]
    return max(history,key=lambda c:(c['mean_reward'],-c['generation']))

def evaluate_final(seed,fam,selected_mask):
    cases=[generate_example(seed,fam,'within_template_test',i) for i in range(TEST_EXAMPLES)]
    # Final suite is never accessed until selection freezes.
    truth=hidden_target(seed,fam)
    results=[int(program(fam,c,selected_mask)==program(fam,c,truth)) for c in cases]
    return {'correct':sum(results),'total':len(results), 'case_scores':results,
            'case_ids':[c['input_id'] for c in cases],
            'case_manifest_sha256':sha(cases)}

def expected_events(seed,fam,mode):
    hist=candidate_sequence(seed,fam,mode)
    chosen=winner(hist,mode)
    events=[{'action':'CANDIDATE','generation':c['generation'],'candidate':c} for c in hist]
    events.append({'action':'FREEZE','candidate_id':chosen['candidate_id'],
                   'genome':chosen['genome'],'policy':mode,
                   'probe_score':chosen['mean_reward']})
    events.append({'action':'FINAL','candidate_id':chosen['candidate_id'],
                   'evaluation':evaluate_final(seed,fam,chosen['genome'])})
    return events

def run_dir(root,seed,fam,mode):return Path(root)/'runs'/str(seed)/fam/mode

def config(seed,fam,mode):
    if seed not in SEEDS or fam not in FAMILIES or mode not in MODES:raise ValueError('unregistered configuration')
    return {'study':STUDY,'version':VERSION,'seed':seed,'family':fam,'mode':mode,
            'algorithm':'4-bit bounded DSL, score-guided parent vs recency parent',
            'candidates':CANDIDATES,'train_examples':TRAIN_EXAMPLES,'test_examples':TEST_EXAMPLES,
            'feedback_scoring_calls':EVALS_PER_FAMILY,'additional_cost_idr':PAID_COST_IDR,
            'f4_heldout':'NOT_PRESENT','model_api_calls':0,'tooling':'Python standard library',
            'source_sha256':file_sha(Path(__file__))}

def load_events(path):
    path=Path(path)
    if not path.exists():return []
    events=[];prev='0'*64
    for line in path.read_text(encoding='utf8').splitlines():
        if not line.strip():continue
        try:e=json.loads(line)
        except json.JSONDecodeError as exc:raise IntegrityError('invalid event JSON') from exc
        if e.get('event_id')!=len(events)+1 or e.get('previous_hash')!=prev:
            raise IntegrityError('incorrect event order/hash link')
        if e.get('event_hash')!=sha({k:v for k,v in e.items() if k!='event_hash'}):
            raise IntegrityError('event hash tampered')
        events.append(e);prev=e['event_hash']
    return events

def verify(root,seed,fam,mode,complete=False):
    folder=run_dir(root,seed,fam,mode)
    cfg=read_json(folder/'config.json')
    if cfg!=config(seed,fam,mode):raise IntegrityError('wrong source/config')
    events=load_events(folder/'events.jsonl')
    expected=expected_events(seed,fam,mode)
    if len(events)>len(expected):raise IntegrityError('too many events')
    for i,e in enumerate(events):
        if e.get('config_sha256')!=sha(cfg) or e.get('payload')!=expected[i]:
            raise IntegrityError(f'semantic mismatch at event {i+1}')
    for e in events:
        if e['payload']['action']=='CANDIDATE':
            c=e['payload']['candidate']
            if read_json(folder/'candidates'/(c['candidate_id']+'.json'))!=c:
                raise IntegrityError('candidate artifact changed')
    cp=folder/'checkpoint.json'
    if cp.exists():
        obj=read_json(cp);n=obj['last_event_id']
        if not 0<=n<=len(events):raise IntegrityError('invalid checkpoint position')
        if obj['head']!=(events[n-1]['event_hash'] if n else '0'*64):
            raise IntegrityError('checkpoint hash mismatch')
    if complete and len(events)!=len(expected):raise IntegrityError('not complete')
    if len(events)==len(expected):
        if not cp.exists() or read_json(cp)['status']!='COMPLETED':
            raise IntegrityError('completed checkpoint missing')
    return {'seed':seed,'family':fam,'mode':mode,'events':len(events),
            'complete':len(events)==len(expected),
            'head':events[-1]['event_hash'] if events else '0'*64}

def run(root,seed,fam,mode,stop_after=None,inject_crash=False):
    folder=run_dir(root,seed,fam,mode);folder.mkdir(parents=True,exist_ok=True)
    cp=folder/'config.json';cfg=config(seed,fam,mode)
    if cp.exists():
        if read_json(cp)!=cfg:raise IntegrityError('resume config mismatch')
    else:write_json(cp,cfg)
    verify(root,seed,fam,mode)
    events=load_events(folder/'events.jsonl')
    expected=expected_events(seed,fam,mode)
    added=0
    for payload in expected[len(events):]:
        if stop_after is not None and added>=stop_after:break
        e={'event_id':len(events)+1,'previous_hash':events[-1]['event_hash'] if events else '0'*64,
           'config_sha256':sha(cfg),'payload':payload}
        e['event_hash']=sha(e)
        if payload['action']=='CANDIDATE':
            c=payload['candidate'];write_json(folder/'candidates'/(c['candidate_id']+'.json'),c)
        with (folder/'events.jsonl').open('a',encoding='utf8') as f:
            f.write(canon(e)+'\n');f.flush();os.fsync(f.fileno())
        events.append(e);added+=1
        if inject_crash and added==1:raise InterruptedError('injected crash between event and checkpoint')
        write_json(folder/'checkpoint.json',{'last_event_id':len(events),'head':e['event_hash'],
                'status':'COMPLETED' if len(events)==len(expected) else 'CHECKPOINTED'})
    return verify(root,seed,fam,mode,complete=(stop_after is None))

def scan(root):
    root=Path(root)
    rows=[];candidates=[]
    for seed in SEEDS:
        for fam in FAMILIES:
            for mode in MODES:
                v=verify(root,seed,fam,mode,complete=True)
                events=load_events(run_dir(root,seed,fam,mode)/'events.jsonl')
                evs=[x['payload'] for x in events]
                decision=next(e for e in evs if e['action']=='FREEZE')
                result=next(e['evaluation'] for e in evs if e['action']=='FINAL')
                rows.append({'seed':seed,'family':fam,'mode':mode,
                    'correct':result['correct'],'total':result['total'],
                    'selected_mask':decision['genome'],'selected_id':decision['candidate_id'],
                    'probe_score':decision['probe_score'],'run_head':v['head'],
                    'case_manifest_sha256':result['case_manifest_sha256']})
                for e in evs:
                    if e['action']=='CANDIDATE':
                        c=e['candidate'];candidates.append({'seed':seed,'family':fam,'mode':mode,
                          'generation':c['generation'],'genome':c['genome'],'parent_id':c['parent_id'],
                          'candidate_id':c['candidate_id'],'origin':c['origin'],
                          'mean_reward':c['mean_reward']})
    scores={}
    for mode in MODES:
        cases=[r for r in rows if r['mode']==mode]
        scores[mode]={'correct':sum(r['correct'] for r in cases),
            'total':sum(r['total'] for r in cases),
            'rate':sum(r['correct'] for r in cases)/sum(r['total'] for r in cases)}
    paired=[]
    for seed in SEEDS:
        for fam in FAMILIES:
            by={r['mode']:r for r in rows if r['seed']==seed and r['family']==fam}
            paired.append({'seed':seed,'family':fam,
              'guided_minus_blind_best':by['GUIDED_BEST']['correct']-by['BLIND_BEST']['correct'],
              'guided_minus_blind_last':by['GUIDED_BEST']['correct']-by['BLIND_LAST']['correct'],
              'blind_best_minus_last':by['BLIND_BEST']['correct']-by['BLIND_LAST']['correct']})
    # Cluster bootstrap: draw entire seeds, preserving both families within each seed.
    bootstrap=rng_for('bootstrap',STUDY)
    byseed={s:[x for x in paired if x['seed']==s] for s in SEEDS}
    bs=[]
    for _ in range(2000):
        draws=[SEEDS[bootstrap.randrange(len(SEEDS))] for _ in SEEDS]
        diff=sum(x['guided_minus_blind_best'] for s in draws for x in byseed[s])
        bs.append(diff/(len(SEEDS)*len(FAMILIES)*TEST_EXAMPLES))
    bs.sort()
    gap=scores['GUIDED_BEST']['rate']-scores['BLIND_BEST']['rate']
    divergence=sum(1 for s in SEEDS for fam in FAMILIES
        if [x['genome'] for x in candidates if x['seed']==s and x['family']==fam and x['mode']=='GUIDED_BEST'][2:] !=
           [x['genome'] for x in candidates if x['seed']==s and x['family']==fam and x['mode']=='BLIND_BEST'][2:])
    result={'study':STUDY,'version':VERSION,'seeds':list(SEEDS),'families':list(FAMILIES),
      'score':scores,'guided_minus_blind_best_ppt':round(gap*100,3),
      'seed_cluster_bootstrap_95pct_diff_pp':[round(bs[49]*100,3),round(bs[1949]*100,3)],
      'paired':paired,'runs':len(rows),'candidates':len(candidates),
      'probes_per_policy_seed_family':EVALS_PER_FAMILY,
      'finals_per_policy_seed_family':TEST_EXAMPLES,
      'feedback_changed_proposals_seed_family':divergence,
      'total_seed_family_pairs':len(SEEDS)*len(FAMILIES),
      'heldout_f4':'NOT_CREATED_NOT_ACCESSED','model_calls':0,'additional_api_cost_idr':0,
      'method_limits':['All candidate genes, interpreters and hidden target distribution are human-authored.',
        'Within-template test problems are newly generated but share the same operator grammar as probes.',
        'Feedback is numeric oracle score; the experiment does not include an LLM generating new methods.',
        'Synthetic seeds are clustered and not necessarily representative of broader scientific tasks.',
        'A positive treatment gap is evidence only for feedback-guided search in this bounded DSL.',
        'Blind-best uses score to select at freeze, but does not use it during candidate proposal.',
        'Equal evaluator calls do not prove equal CPU cost or background prior knowledge.']}
    write_json(root/'reports'/'results.json',result)
    with (root/'reports'/'runs.csv').open('w',newline='',encoding='utf8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    with (root/'reports'/'candidate_lineage.csv').open('w',newline='',encoding='utf8') as f:
        w=csv.DictWriter(f,fieldnames=list(candidates[0]));w.writeheader();w.writerows(candidates)
    return result

def main():
    p=argparse.ArgumentParser()
    p.add_argument('command',choices=('all','verify','summary'))
    p.add_argument('--root',default='f31_evidence')
    args=p.parse_args()
    if args.command=='all':
        for seed in SEEDS:
            for fam in FAMILIES:
                for mode in MODES:run(args.root,seed,fam,mode)
        print(canon(scan(args.root)))
    elif args.command=='verify':
        for seed in SEEDS:
            for fam in FAMILIES:
                for mode in MODES:verify(args.root,seed,fam,mode,complete=True)
        print(canon({'status':'PASS','runs':len(SEEDS)*len(FAMILIES)*len(MODES)}))
    else:print(canon(scan(args.root)))
if __name__=='__main__':main()
