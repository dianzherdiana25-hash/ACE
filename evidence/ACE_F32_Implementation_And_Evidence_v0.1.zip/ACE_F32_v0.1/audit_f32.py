"""Read-only cross-check of locked F3.2 evidence.
Uses same human-authored oracle from frozen F3.1 fixture, not independent science.
Does not call the F3.2 candidate proposal or evaluator's summary method.
"""
import sys, json, csv, hashlib, random
from pathlib import Path
from collections import defaultdict
import ace_f31 as fixture

BASE=Path(__file__).parent
ROOT=BASE/'confirmation_evidence'
def canon(x):return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False)
def sha(x):return hashlib.sha256((x if isinstance(x,str) else canon(x)).encode('utf8')).hexdigest()
def file_sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def verify():
    manifest=json.loads((BASE/'F32_PREREGISTRATION.json').read_text())
    for name,expected in manifest['sources'].items():
        assert file_sha(BASE/name)==expected,(name,'source changed')
    seeds=manifest['confirmation_seeds'];families=manifest['family_count'];modes=manifest['policies']
    assert families==2 and len(seeds)==48 and len(modes)==3
    assert manifest['confirmation_manifest_sha256']==sha({'confirm':seeds,'families':['S','G'],'policies':modes})
    totals={m:0 for m in modes};per_fam={m:{f:0 for f in ('S','G')} for m in modes}
    unique={m:[] for m in modes}
    rows=[];events_total=0
    for s in seeds:
        for fam in ('S','G'):
            first_two=[];cases=[];unit={}
            for mode in modes:
                folder=ROOT/'runs'/str(s)/fam/mode
                cfg=json.loads((folder/'config.json').read_text())
                assert cfg['seed']==s and cfg['family']==fam and cfg['mode']==mode
                assert cfg['eval_budget']==50 and cfg['final_cases']==24
                assert cfg['policy_source_sha256']==manifest['sources']['ace_f32.py']
                assert cfg['fixture_sha256']==manifest['sources']['ace_f31.py']
                entries=[json.loads(line) for line in (folder/'events.jsonl').read_text().splitlines()]
                assert len(entries)==12
                events_total+=len(entries)
                prev='0'*64
                for j,e in enumerate(entries):
                    assert e['index']==j+1 and e['prev']==prev
                    assert e['hash']==sha({k:v for k,v in e.items() if k!='hash'})
                    assert e['config_sha256']==sha(cfg)
                    prev=e['hash']
                cp=json.loads((folder/'checkpoint.json').read_text())
                assert cp=={'last_index':12,'head':prev,'status':'COMPLETED'}
                hist=[]
                for j,e in enumerate(entries[:10]):
                    c=e['payload']['candidate']
                    assert e['payload']['type']=='CANDIDATE' and c['generation']==j
                    assert c['family']==fam and type(c['genome'])==int and 0<=c['genome']<16
                    assert len(c['probe_rewards'])==5
                    assert (folder/'candidates'/(c['candidate_id']+'.json')).exists()
                    assert json.loads((folder/'candidates'/(c['candidate_id']+'.json')).read_text())==c
                    if c['parent_id'] is not None:assert c['parent_id'] in {x['candidate_id'] for x in hist}
                    tasks=[fixture.generate_example(s,fam,'probe',i) for i in range(5)]
                    assert c['probe_rewards']==fixture.grade(s,fam,c['genome'],tasks)
                    assert c['mean_reward']==round(sum(c['probe_rewards'])/5,8)
                    hist.append(c)
                first_two.append(tuple(c['genome'] for c in hist[:2]))
                unique[mode].append(len({c['genome'] for c in hist}))
                win=max(hist,key=lambda c:(c['mean_reward'],-c['generation']))
                frozen=entries[-2]['payload'];final=entries[-1]['payload']
                assert frozen['type']=='FREEZE' and frozen['winner_id']==win['candidate_id']
                assert frozen['mask']==win['genome']
                assert final['type']=='EVALUATE' and final['winner_id']==win['candidate_id']
                answer=final['result'];assert len(answer['case_scores'])==24
                cases.append(answer['case_manifest_sha256'])
                task_list=[fixture.generate_example(s,fam,'within_template_test',i) for i in range(24)]
                assert answer['case_manifest_sha256']==fixture.sha(task_list)
                truth=fixture.hidden_target(s,fam)
                scores=[int(fixture.program(fam,t,win['genome'])==fixture.program(fam,t,truth)) for t in task_list]
                assert scores==answer['case_scores'] and sum(scores)==answer['correct']
                assert len(scores)==answer['total']==24
                totals[mode]+=sum(scores);per_fam[mode][fam]+=sum(scores)
                unit[mode]=sum(scores)
            assert len(set(first_two))==1, ('different warmup',s,fam)
            assert len(set(cases))==1, ('different testing cases',s,fam)
            rows.append({'seed':s,'family':fam,**unit})
    primary=[r['ARCHIVE_NEIGHBOR']-r['BLIND_BEST'] for r in rows]
    secondary=[r['ARCHIVE_NEIGHBOR']-r['GUIDED_BEST'] for r in rows]
    by_seed=defaultdict(int)
    for r in rows:by_seed[r['seed']]+=r['ARCHIVE_NEIGHBOR']-r['BLIND_BEST']
    # Same pre-registered cluster bootstrap, implemented independently.
    rng=random.Random(13790);arr=[by_seed[s] for s in seeds]
    samples=[]
    for _ in range(10000):
        samples.append(sum(arr[rng.randrange(len(arr))] for i in arr)/(len(arr)*48))
    samples.sort()
    original=json.loads((ROOT/'reports'/'confirmation_results.json').read_text())
    assert original['runs']==len(rows)*len(modes)
    assert {m:original['score'][m]['correct'] for m in modes}==totals
    assert [round(samples[249]*100,4),round(samples[9749]*100,4)]==original['seed_cluster_bootstrap_95pct_diff_pp']
    return {
      'status':'PASS',
      'preregistration_sha256':file_sha(BASE/'F32_PREREGISTRATION.json'),
      'source_code_sha256':file_sha(BASE/'ace_f32.py'),
      'crosschecked_run_count':len(rows)*len(modes),
      'crosschecked_event_count':events_total,
      'crosschecked_candidate_count':len(rows)*len(modes)*10,
      'crosschecked_probe_scores':len(rows)*len(modes)*10*5,
      'crosschecked_final_scores':len(rows)*len(modes)*24,
      'scores':{m:{'correct':totals[m],'total':len(rows)*24,'rate':totals[m]/(len(rows)*24)} for m in modes},
      'by_family':per_fam,
      'primary_diff_pp':100*sum(primary)/(len(rows)*24),
      'secondary_diff_pp':100*sum(secondary)/(len(rows)*24),
      'primary_seed_cluster_bootstrap_95pct_diff_pp':[round(samples[249]*100,4),round(samples[9749]*100,4)],
      'pairwise_primary':{'better':sum(x>0 for x in primary),'tied':sum(x==0 for x in primary),'worse':sum(x<0 for x in primary)},
      'candidate_uniqueness':{m:{'min':min(unique[m]),'max':max(unique[m])} for m in modes},
      'f4_access':'NONE',
      'limitations':'Uses frozen F3.1 oracle; not independent human-reviewed semantic acceptance.'
    }
if __name__=='__main__':
    result=verify()
    (ROOT/'reports'/'independent_audit.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
    print(json.dumps(result,indent=2,ensure_ascii=False))
