"""Exploratory development-only policy comparison. NEVER evaluate confirmation seeds here."""
import sys, math, json, hashlib, statistics
from pathlib import Path
sys.path.insert(0,'/mnt/data/ACE_F31_feedback_evolution_v0.1')
import ace_f31 as f
DEV_SEEDS=f.SEEDS
FAMILIES=f.FAMILIES
CANDIDATES=10
PROBES=5
FINALS=24
VARIANTS=('ACTIVE_FACTOR','KERNEL_UCB','ARCHIVE_NEIGHBOR')
def rng(*a):return f.rng_for('ACE-F3.2','explore',*a)
def h(a,b):return (a^b).bit_count()
def dither(s,fam,mode,g,m):return rng(s,fam,mode,g,m).random()
def choose(seed,fam,mode,history):
    step=len(history); used={x['genome'] for x in history}
    initial=f.rng_for('initial',seed,fam).randrange(16)
    if step==0:return initial,'initial',None
    if step==1:return initial^(1<<f.rng_for('warmup',seed,fam).randrange(4)),'shared_warmup',history[-1]['candidate_id']
    if mode=='ACTIVE_FACTOR':
        if step<=4:
            return initial^(1<<step-1),f'probe_bit_{step-1}',history[0]['candidate_id']
        b=history[0]['mean_reward']
        effects={k:history[k+1]['mean_reward']-b for k in range(4)}
        def pred(m):return b+sum(effects[k] for k in range(4) if bool((m>>k)&1)!=bool((initial>>k)&1))
        opts=[m for m in range(16) if m not in used]
        # slightly reward novelty; first candidate follows predicted reward exclusively
        winner=max(opts,key=lambda m:(pred(m),min(h(m,x) for x in used),-m))
        return winner,'additive_surrogate',history[0]['candidate_id']
    if mode=='KERNEL_UCB':
        opts=[m for m in range(16) if m not in used]
        def score(m):
            ws=[math.exp(-1.3*h(m,x['genome'])) for x in history]
            avg=sum(w*x['mean_reward'] for w,x in zip(ws,history))/sum(ws)
            nov=min(h(m,x) for x in used)
            return avg+0.045*nov
        winner=max(opts,key=lambda m:(score(m),-m))
        near=min(history,key=lambda x:(h(winner,x['genome']),-x['mean_reward']))
        return winner,'kernel_ucb',near['candidate_id']
    if mode=='ARCHIVE_NEIGHBOR':
        opts=[m for m in range(16) if m not in used]
        best=[]
        for m in opts:
            parents=[x for x in history if h(m,x['genome'])==1]
            if parents:
                par=max(parents,key=lambda x:x['mean_reward'])
                best.append((par['mean_reward'],-h(m,history[0]['genome']),-m,m,par))
        if best:
            _,_,_,winner,par=max(best)
            return winner,'archive_neighbor',par['candidate_id']
        winner=max(opts,key=lambda m:(min(h(m,x) for x in used),-m))
        return winner,'novelty_restart',history[-1]['candidate_id']
    raise ValueError(mode)

def seq(seed,fam,mode):
    tasks=[f.generate_example(seed,fam,'probe',i) for i in range(PROBES)]
    hist=[]
    for gen in range(CANDIDATES):
        genome,origin,parent=choose(seed,fam,mode,hist)
        rewards=f.grade(seed,fam,genome,tasks)
        c={'candidate_id':f'c{gen}','generation':gen,'genome':genome,'origin':origin,'parent_id':parent,'mean_reward':round(sum(rewards)/len(rewards),8)}
        hist.append(c)
    return hist

def score_one(seed,fam,mode):
    if mode=='BLIND_BEST':hist=f.candidate_sequence(seed,fam,'BLIND_BEST')
    elif mode=='GUIDED_BEST':hist=f.candidate_sequence(seed,fam,'GUIDED_BEST')
    else:hist=seq(seed,fam,mode)
    best=max(hist,key=lambda c:(c['mean_reward'],-c['generation']))
    e=f.evaluate_final(seed,fam,best['genome'])
    return e['correct'],best['genome']

if __name__=='__main__':
    modes=VARIANTS+('BLIND_BEST','GUIDED_BEST')
    rows=[{'seed':seed,'fam':fam,**{mode:score_one(seed,fam,mode)[0] for mode in modes}} for seed in DEV_SEEDS for fam in FAMILIES]
    totals={m:sum(r[m] for r in rows) for m in modes}
    byfam={fam:{m:sum(r[m] for r in rows if r['fam']==fam) for m in modes} for fam in FAMILIES}
    vs={m:{'better':sum(r[m]>r['BLIND_BEST'] for r in rows),'same':sum(r[m]==r['BLIND_BEST'] for r in rows),'worse':sum(r[m]<r['BLIND_BEST'] for r in rows)} for m in VARIANTS}
    report={'development_seeds':list(DEV_SEEDS),'families':list(FAMILIES),'cases_per_mode':len(rows)*FINALS,'totals':totals,'by_family':byfam,'paired_vs_blind_best':vs,'rows':rows}
    Path('/mnt/data/ACE_F32_DEV_EXPLORATORY.json').write_text(json.dumps(report,indent=2))
    print(json.dumps({k:v for k,v in report.items() if k!='rows'},indent=2))
