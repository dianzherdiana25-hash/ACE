"""ACE F3 acceptance tests (bounded DSL genotype search only)."""
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import ace_f1 as f1
import ace_f2 as f2
import ace_f3 as f3


class TestF3(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(prefix='ace_f3_t_')
        self.root=Path(self.tmp.name)
        self.s=f3.SEEDS[0]

    def tearDown(self):
        self.tmp.cleanup()

    def test_01_frozen_f1_source_same(self):
        self.assertEqual(f3.sources()['ace_f1.py'],'4ef8a5c06b75a9df00367ce74226443f1c394b29d253d3f977183f8a9df3a46b')

    def test_02_frozen_f2_source_same(self):
        self.assertEqual(f3.sources()['ace_f2.py'],'69f2244939113ca01c1eea82c48e366f809a957ef6efac6f04af1e82e3caf323')

    def test_03_candidate_lineage_and_genomes(self):
        for s in f3.SEEDS:
            can=f3.candidates(s)
            self.assertEqual(len(can),6)
            self.assertEqual(len({c['candidate_id'] for c in can}),6)
            for fam in ('S','G'):
                group=[c for c in can if c['family']==fam]
                self.assertEqual([c['generation'] for c in group],[0,1,2])
                self.assertEqual(group[0]['genome'],0)
                self.assertIn(group[1]['genome'],(1,2))
                self.assertEqual(group[2]['genome'],3)
                self.assertIsNone(group[0]['parent_id'])
                self.assertEqual(group[1]['parent_id'],group[0]['candidate_id'])
                self.assertEqual(group[2]['parent_id'],group[1]['candidate_id'])

    def test_04_public_only(self):
        t=f1.generate(self.s)[0]
        with self.assertRaises(ValueError):f3.solve(t,f3.candidates(self.s)[0])

    def test_05_heldout_not_generated_and_identical_splits(self):
        can,probes,finals=f3.plan(self.s)
        p2,f2final=f2.make_manifest(self.s)
        self.assertEqual([x['task_id'] for x in finals],[x['task_id'] for x in f2final])
        self.assertEqual({t['task_id'] for ps in probes.values() for t in ps},{t['task_id'] for t in p2})
        self.assertTrue(all(t['split'] in ('development','validation') for t in finals+p2))

    def test_06_base_genome_parity_with_A(self):
        seed=self.s;cs=f3.candidates(seed)
        for t in f1.generate(seed):
            p=f1.public_task(t)
            base=next(c for c in cs if c['family']==t['family'] and c['generation']==0)
            self.assertEqual(f3.solve(p,base),f1.a_fixed_solve(p))

    def test_07_full_dsl_matches_oracle_on_known_fixtures(self):
        seed=self.s;cs=f3.candidates(seed)
        for t in f1.generate(seed):
            p=f1.public_task(t)
            top=next(c for c in cs if c['family']==t['family'] and c['generation']==2)
            self.assertEqual(f1.evaluate(t,f3.solve(p,top))['score'],1)

    def test_08_zero_cost_enforced(self):
        with self.assertRaises(f3.BudgetError):f3.run(self.root,self.s,max_cost_idr=1)
        self.assertFalse((self.root/'runs').exists())

    def test_09_crash_after_fsync_resume(self):
        with self.assertRaises(InterruptedError):
            f3.run(self.root,self.s,interrupt_after_first_event=True)
        d=self.root/'runs'/f3.run_id(self.s)
        self.assertEqual(len(f3.load_events(d/'events.jsonl')),1)
        result=f3.run(self.root,self.s)
        self.assertTrue(result['complete'])
        self.assertEqual(result['events'],51)
        before=(d/'events.jsonl').read_bytes()
        self.assertEqual(f3.run(self.root,self.s)['final_pass'],result['final_pass'])
        self.assertEqual((d/'events.jsonl').read_bytes(),before)

    def test_10_partial_then_resume(self):
        result=f3.run(self.root,self.s,stop_after=25)
        self.assertFalse(result['complete'])
        self.assertEqual(result['events'],25)
        final=f3.run(self.root,self.s)
        self.assertEqual(final['final_count'],32)
        self.assertEqual(final['probes'],12)

    def test_11_detect_simple_ledger_tamper(self):
        f3.run(self.root,self.s)
        path=self.root/'runs'/f3.run_id(self.s)/'events.jsonl'
        original=path.read_text()
        path.write_text(original.replace('"score":1','"score":0',1))
        with self.assertRaises(f3.IntegrityError):f3.verify(self.root,self.s)

    def test_12_detect_rehashed_semantic_forgery(self):
        f3.run(self.root,self.s)
        path=self.root/'runs'/f3.run_id(self.s)/'events.jsonl'
        events=f3.load_events(path)
        ev=next(e for e in events if e['action']=='PROBE')
        ev['score']=1-ev['score']
        prior='0'*64
        for e in events:
            e['previous_hash']=prior;e['event_hash']=f3.sha({k:v for k,v in e.items() if k!='event_hash'});prior=e['event_hash']
        path.write_text(''.join(f1.canonical(e)+'\n' for e in events))
        with self.assertRaises(f3.IntegrityError):f3.verify(self.root,self.s)

    def test_13_detect_candidate_artifact_tamper(self):
        f3.run(self.root,self.s)
        d=self.root/'runs'/f3.run_id(self.s)
        candidate=next(e for e in f3.load_events(d/'events.jsonl') if e['action']=='BIRTH')
        path=d/'candidates'/(candidate['candidate_id']+'.json')
        obj=f3.read(path);obj['genome']=3;f3.save(path,obj)
        with self.assertRaises(f3.IntegrityError):f3.verify(self.root,self.s)

    def test_14_detect_checkpoint_tamper(self):
        f3.run(self.root,self.s)
        path=self.root/'runs'/f3.run_id(self.s)/'checkpoint.json'
        obj=f3.read(path);obj['head']='0'*64;f3.save(path,obj)
        with self.assertRaises(f3.IntegrityError):f3.verify(self.root,self.s)

    def test_15_full_equal_budget_comparison(self):
        for mode in ('A_CONTROL','B_ADAPT'):
            for seed in f3.SEEDS:f2.run(self.root,mode,seed)
        for seed in f3.SEEDS:f3.run(self.root,seed)
        r=f3.summary(self.root)
        self.assertEqual(r['budget_per_mode_seed'],{'probe_evaluations':12,'frozen_final_evaluations':32})
        self.assertEqual(r['heldout_f4'],'NOT_GENERATED_NOT_ACCESSED')
        for mode,expected in [('A_CONTROL',79),('B_ADAPT',94),('C_EVOLVE',96)]:
            self.assertEqual(sum(v['correct'] for v in r['scores'][mode].values()),expected)
            self.assertEqual(sum(v['total'] for v in r['scores'][mode].values()),96)
        self.assertTrue(all(v['complete'] for v in r['c_runs']))

    def test_16_timing_cap(self):
        with patch.object(f3,'MAX_SECONDS',-1):
            with self.assertRaises(f3.BudgetError):f3.run(self.root,self.s)
        self.assertFalse((self.root/'runs'/f3.run_id(self.s)/'events.jsonl').exists())


if __name__=='__main__':unittest.main(verbosity=2)
