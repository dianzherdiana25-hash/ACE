"""ACE F3 — bounded evolutionary search over a tiny declarative program grammar.

This is NOT open-ended AI, generated Python, autonomous algorithm invention, or
an F4 generalization evaluation. It uses zero LLM/API calls. The two feature
bits per family are pre-defined human-coded primitives. Evolution mutates and
combines those bits; scorer feedback selects which candidate is inherited.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import time
from datetime import datetime, timezone
from pathlib import Path

import ace_f1 as f1
import ace_f2 as f2

STUDY = 'ACE-F3-20261104'
VERSION = 'C-bounded-DSL-evolution-0.1.0'
SEEDS = f1.SEEDS
PROBES_PER_SEED = 12
FINAL_PER_SEED = 32
MAX_SECONDS = 1800
FEATURES = {'S': ('dedupe', 'swap_pairs'), 'G': ('must_visit', 'max_hops')}

class IntegrityError(RuntimeError):
    pass

class BudgetError(RuntimeError):
    pass


def sha(x):
    return f1.digest(x)


def save(path, obj):
    f1.atomic_json(Path(path), obj)


def read(path):
    return f1.read_json(Path(path))


def sources():
    return {p: f1.file_hash(Path(__file__).with_name(p)) for p in ('ace_f1.py','ace_f2.py','ace_f3.py')}


def run_id(seed):
    return f'C_EVOLVE_{seed}'


def conf(seed):
    if seed not in SEEDS: raise ValueError('seed not preregistered')
    return {'study':STUDY,'version':VERSION,'seed':seed, 'source_sha256':sources(),
        'trial_cap':PROBES_PER_SEED,'final_cap':FINAL_PER_SEED,'max_additional_cost_idr':0,
        'model_calls':0,'grammar':{k:list(v) for k,v in FEATURES.items()},
        'candidate_policy':'two-bit declarative genomes; 0 -> seeded single bit -> both bits; neutral drift permitted',
        'promotion_policy':'per-family highest two-probe score; latest generation wins score ties',
        'data_policy':'F2 four probe task IDs only; post-freeze 32 F2 finals; F4 held-out absent'}


def candidates(seed):
    out=[]
    for family in ('S','G'):
        first=1 << (int(sha(f'{seed}|{family}|mutation_order')[:8],16) % 2)
        masks=(0,first,3)
        parent=None
        for generation,mask in enumerate(masks):
            candidate={'family':family,'generation':generation,'genome':mask,
                       'features':list(FEATURES[family]),'parent_id':parent,
                       'program_kind':'bounded_declarative_policy',
                       'origin':'deterministic_bit_mutation_not_model_generated'}
            candidate['candidate_id']='C'+sha(candidate)[:16]
            out.append(candidate)
            parent=candidate['candidate_id']
    return out


def program_s(problem, mask):
    tokens=list(problem['tokens'])
    for operation in problem['operations']:
        op=operation['op']
        if op=='reverse': tokens=tokens[::-1]
        elif op=='rotate_left':
            k=operation['steps']%len(tokens) if tokens else 0
            tokens=tokens[k:]+tokens[:k]
        elif op=='filter_eq':tokens=[t for t in tokens if t==operation['value']]
        elif op=='dedupe' and (mask&1):
            seen=set();out=[]
            for item in tokens:
                if item not in seen:seen.add(item);out.append(item)
            tokens=out
        elif op=='swap_pairs' and (mask&2):
            for i in range(0,len(tokens)-1,2):
                tokens[i],tokens[i+1]=tokens[i+1],tokens[i]
        else:return None
    return tokens


def program_g(problem,mask):
    # Bounded interpreter for trusted graph fixtures. Never call oracle_graph.
    if mask==0:return f1.baseline_shortest(problem)
    graph,start,goal=f1.neighbors(problem)
    must=problem.get('must_visit') if (mask&1) else None
    hops=problem.get('max_hops') if (mask&2) else None
    best=None
    stack=[(start,[start],0)]
    while stack:
        node,path,cost=stack.pop()
        if best is not None and cost>best[0]:continue
        if node==goal:
            if (must is None or must in path) and (hops is None or len(path)-1<=hops):
                cand=(cost,tuple(map(str,path)),path)
                if best is None or cand[:2]<best[:2]:best=cand
            continue
        if hops is not None and len(path)-1>=hops:continue
        for nxt,w in graph[node]:
            if nxt not in path:stack.append((nxt,path+[nxt],cost+w))
    if best is None:return {'path':[],'cost':None,'reachable':False}
    return {'path':[list(n) if isinstance(n,tuple) else n for n in best[2]],
            'cost':best[0],'reachable':True}


def solve(public,candidate):
    if set(public)!={'task_id','family','problem','answer_format','limits'}:
        raise ValueError('public input only; no split, oracle, or hidden metadata')
    if public['family']!=candidate['family']:raise ValueError('wrong family')
    mask=candidate['genome']
    if type(mask) is not int or not 0<=mask<=3:raise ValueError('invalid genome')
    if public['family']=='S':
        answer=program_s(public['problem'],mask)
        if answer is None:return {'task_id':public['task_id'],'answer':None,'declared_status':'UNSUPPORTED'}
        return {'task_id':public['task_id'],'answer':{'tokens':answer}}
    if public['family']=='G':return {'task_id':public['task_id'],'answer':program_g(public['problem'],mask)}
    raise ValueError('unknown family')


def plan(seed):
    probes,finals=f2.make_manifest(seed)
    can=candidates(seed)
    by_family={fam:[t for t in probes if t['family']==fam] for fam in ('S','G')}
    assert all(len(x)==2 for x in by_family.values())
    assert len(finals)==FINAL_PER_SEED
    return can,by_family,finals


def selected(evs,can):
    choices={}
    for fam in ('S','G'):
        feasible=[]
        for c in can:
            if c['family']!=fam:continue
            scores=[e['score'] for e in evs if e['action']=='PROBE' and e['candidate_id']==c['candidate_id']]
            if len(scores)!=2:raise IntegrityError('unscored genotype')
            feasible.append((sum(scores),c['generation'],c))
        winner=max(feasible,key=lambda x:(x[0],x[1]))[2]
        choices[fam]=winner['candidate_id']
    return choices


def load_events(file):
    file=Path(file)
    if not file.exists():return []
    result=[];prior='0'*64
    for line in file.read_text(encoding='utf8').splitlines():
        if not line.strip():continue
        try:e=json.loads(line)
        except json.JSONDecodeError as exc:raise IntegrityError('invalid JSON in ledger') from exc
        if e.get('event_id')!=len(result)+1 or e.get('previous_hash')!=prior:
            raise IntegrityError('broken event chain')
        if e.get('event_hash')!=sha({k:v for k,v in e.items() if k!='event_hash'}):
            raise IntegrityError('ledger SHA-256 mismatch')
        result.append(e);prior=e['event_hash']
    return result


def append_event(file,event):
    with Path(file).open('a',encoding='utf8') as f:
        f.write(f1.canonical(event)+'\n');f.flush();os.fsync(f.fileno())


def checkpoint(folder,events):
    save(folder/'checkpoint.json',{'run_id':folder.name,'last_event_id':len(events),
        'head':events[-1]['event_hash'] if events else '0'*64,
        'status':'COMPLETED' if sum(e['action']=='FINAL' for e in events)==FINAL_PER_SEED else 'CHECKPOINTED'})


def expected(seed,recorded):
    """Compute expected deterministic event payload, excluding runtime metadata.

    Replay uses candidates' *public* problems. The oracle remains outside solve.
    """
    can,by_family,finals=plan(seed)
    specs=[]
    for candidate in can:
        specs.append({'action':'BIRTH','family':candidate['family'],'candidate':candidate,
            'candidate_sha256':sha(candidate),'candidate_id':candidate['candidate_id']})
        for task in by_family[candidate['family']]:
            resp=solve(f1.public_task(task),candidate);grade=f1.evaluate(task,resp)
            specs.append({'action':'PROBE','family':task['family'],'candidate_id':candidate['candidate_id'],
                'task_id':task['task_id'],'task_sha256':sha(task),
                'score':grade['score'],'status':grade['status'],'response_sha256':sha(resp)})
    freeze_position=len(specs)
    if len(recorded)>=freeze_position:
        chosen=selected(recorded[:freeze_position],can)
        specs.append({'action':'FREEZE','selected':chosen,'policy_sha256':sha(chosen)})
        by_id={c['candidate_id']:c for c in can}
        for task in finals:
            c=by_id[chosen[task['family']]]
            resp=solve(f1.public_task(task),c);grade=f1.evaluate(task,resp)
            specs.append({'action':'FINAL','family':task['family'],'split':task['split'],
                'candidate_id':c['candidate_id'],'task_id':task['task_id'],
                'task_sha256':sha(task),'score':grade['score'],'status':grade['status'],
                'response_sha256':sha(resp)})
    return specs


def verify(root,seed,complete=False):
    root=Path(root);folder=root/'runs'/run_id(seed)
    cfg=read(folder/'config.snapshot.json')
    if cfg!=conf(seed):raise IntegrityError('F3 source/config mismatch')
    events=load_events(folder/'events.jsonl')
    spec=expected(seed,events)
    if len(events)>len(spec):raise IntegrityError('excess/invalid events')
    for i,e in enumerate(events):
        for k,v in spec[i].items():
            if e.get(k)!=v:raise IntegrityError(f'event {i+1} semantic replay mismatch at {k}')
        if e.get('config_sha256')!=sha(cfg) or e.get('study')!=STUDY or e.get('seed')!=seed:
            raise IntegrityError('wrong provenance')
        if e.get('additional_cost_idr')!=0 or e.get('model_calls')!=0:
            raise IntegrityError('external model/budget recorded')
        if not isinstance(e.get('cpu_seconds'),(int,float)) or e['cpu_seconds']<0:
            raise IntegrityError('invalid CPU measurement')
    can,_,_=plan(seed)
    for e in (x for x in events if x['action']=='BIRTH'):
        path=folder/'candidates'/(e['candidate_id']+'.json')
        if not path.exists() or read(path)!=e['candidate']:raise IntegrityError('missing/tampered candidate artifact')
    chkpath=folder/'checkpoint.json'
    if chkpath.exists():
        chk=read(chkpath);n=chk['last_event_id']
        if n>len(events) or n<0 or chk['run_id']!=run_id(seed):raise IntegrityError('bad checkpoint index')
        if chk['head']!=(events[n-1]['event_hash'] if n else '0'*64):
            raise IntegrityError('checkpoint hash invalid')
    finals=[e for e in events if e['action']=='FINAL']
    finished=(len(events)==len(can)*3+1+FINAL_PER_SEED)
    if complete and not finished:raise IntegrityError('incomplete experiment')
    if finished and (not chkpath.exists() or read(chkpath)['status']!='COMPLETED'):
        raise IntegrityError('missing completed checkpoint')
    return {'mode':'C_EVOLVE','seed':seed,'events':len(events),'probes':sum(x['action']=='PROBE' for x in events),
            'candidates':sum(x['action']=='BIRTH' for x in events),
            'final_count':len(finals),'final_pass':sum(x['score'] for x in finals),
            'chosen':next((x['selected'] for x in events if x['action']=='FREEZE'),None),
            'head':events[-1]['event_hash'] if events else '0'*64,'complete':finished}


def run(root,seed,max_cost_idr=0,stop_after=None,interrupt_after_first_event=False):
    if max_cost_idr!=0:raise BudgetError('additional cost must equal Rp0')
    cfg=conf(seed)
    folder=Path(root)/'runs'/run_id(seed)
    folder.mkdir(parents=True,exist_ok=True)
    cfgfile=folder/'config.snapshot.json'
    if cfgfile.exists():
        if read(cfgfile)!=cfg:raise IntegrityError('resume code/config changed')
    else:save(cfgfile,cfg)
    if (folder/'checkpoint.json').exists():verify(root,seed)
    eventfile=folder/'events.jsonl';events=load_events(eventfile)
    # Verify already durable events even when checkpoint is one event behind.
    verify(root,seed)
    started=time.monotonic();added=0
    while True:
        specs=expected(seed,events)
        if len(events)==len(specs):break
        if stop_after is not None and added>=stop_after:break
        if time.monotonic()-started>MAX_SECONDS:raise BudgetError('time cap')
        payload=specs[len(events)]
        stamp=time.process_time()
        e={'event_id':len(events)+1,'previous_hash':events[-1]['event_hash'] if events else '0'*64,
           'utc':datetime.now(timezone.utc).isoformat(),'study':STUDY,'seed':seed,'phase':'F3',
           'config_sha256':sha(cfg),'model_calls':0,'additional_cost_idr':0,**payload}
        e['cpu_seconds']=round(max(0.0,time.process_time()-stamp),9)
        e['event_hash']=sha(e)
        if e['action']=='BIRTH':
            save(folder/'candidates'/(e['candidate_id']+'.json'),e['candidate'])
        append_event(eventfile,e);events.append(e);added+=1
        if interrupt_after_first_event and added==1:
            raise InterruptedError('injected after durable event before checkpoint')
        checkpoint(folder,events)
    return verify(root,seed,complete=(stop_after is None))


def summary(root):
    root=Path(root)
    from collections import defaultdict
    ab=f2.summary(root)
    runs=[verify(root,s,complete=True) for s in SEEDS]
    counts={m:defaultdict(lambda:[0,0]) for m in ('A_CONTROL','B_ADAPT','C_EVOLVE')}
    per_run={}
    for mode in ('A_CONTROL','B_ADAPT'):
        for seed in SEEDS:
            evs=f2.read_events(root/'runs'/f2.run_id(mode,seed)/'events.jsonl')
            rows=[e for e in evs if e['action']=='FINAL']
            for e in rows:
                k=f"{e['family']}_{e['split']}";counts[mode][k][0]+=e['score'];counts[mode][k][1]+=1
            per_run[f'{mode}_{seed}']={'correct':sum(e['score'] for e in rows),'total':len(rows)}
    for seed in SEEDS:
        events=load_events(root/'runs'/run_id(seed)/'events.jsonl')
        rows=[e for e in events if e['action']=='FINAL']
        for e in rows:
            k=f"{e['family']}_{e['split']}";counts['C_EVOLVE'][k][0]+=e['score'];counts['C_EVOLVE'][k][1]+=1
        per_run[run_id(seed)]={'correct':sum(e['score'] for e in rows),'total':len(rows),
           'selection':runs[SEEDS.index(seed)]['chosen']}
    result={'study':STUDY,'version':VERSION,'seeds':list(SEEDS),
        'comparators':'A and B from frozen ace_f2.py, C from generated two-bit DSL programs',
        'budget_per_mode_seed':{'probe_evaluations':12,'frozen_final_evaluations':32},
        'scores':{mode:{k:{'correct':v[0],'total':v[1],'rate':v[0]/v[1]} for k,v in d.items()}
                  for mode,d in counts.items()},'per_run':per_run,'c_runs':runs,
        'source_sha256':sources(),'heldout_f4':'NOT_GENERATED_NOT_ACCESSED',
        'additional_cost_idr':0,'model_calls':0,
        'limitations':[
            'C only mutates two predefined feature bits per family; its interpreter and grammar are human-coded. Not spontaneous method invention.',
            'C candidate trajectory (0 -> one bit -> both bits) is fixed in advance; feedback selects survivors but does not discover search directions.',
            'A/B/C share F2 validation templates between probe selection and post-freeze test; cannot claim unseen-template generalization.',
            'Same number of scorer calls does not equalize CPU runtime, hand-coded prior knowledge, or programmer effort.',
            'Three seeds only; results descriptive, without causal attribution to general intelligence.',
            'F4 held-out tasks are absent; persistent Colab storage and untrusted Python sandbox isolation not demonstrated.'
        ]}
    save(root/'reports'/'f3_metrics.json',result)
    return result


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('command',choices=('all','run','verify','summary'))
    ap.add_argument('--root',default='f3_evidence')
    ap.add_argument('--seed',type=int,choices=SEEDS)
    ap.add_argument('--max-cost-idr',type=int,default=0)
    ap.add_argument('--stop-after',type=int)
    a=ap.parse_args()
    if a.command=='all':
        for mode in ('A_CONTROL','B_ADAPT'):
            for seed in SEEDS:f2.run(a.root,mode,seed)
        for seed in SEEDS:run(a.root,seed,max_cost_idr=a.max_cost_idr)
        print(f1.canonical(summary(a.root)))
    elif a.command=='run':
        for seed in ([a.seed] if a.seed else SEEDS):print(f1.canonical(run(a.root,seed,max_cost_idr=a.max_cost_idr,stop_after=a.stop_after)))
    elif a.command=='verify':
        for mode in ('A_CONTROL','B_ADAPT'):
            for seed in SEEDS:print(f1.canonical(f2.verify_run(a.root,mode,seed,require_complete=True)))
        for seed in SEEDS:print(f1.canonical(verify(a.root,seed,complete=True)))
    else:print(f1.canonical(summary(a.root)))

if __name__=='__main__':main()
