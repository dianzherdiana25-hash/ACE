# ACE F3 — Laporan Implementasi dan Pengujian Lokal v0.1

**Tanggal:** 4 November 2026  
**Ruang lingkup:** eksperimen terkendali `C_EVOLVE` dengan mutasi dan seleksi kandidat DSL dua-bit; pembanding `A_CONTROL` dan `B_ADAPT` dari modul F2 yang tidak diubah.  
**Status:** `LOCAL_ENGINEERING_VERIFIED`; reproduksi pada akun Colab pengguna `PENDING`; hipotesis penemuan algoritma otonom `NOT_PROVEN`.

## 1. Sistem yang benar-benar dibangun

- Kode `ace_f1.py` dan `ace_f2.py` dipertahankan byte-per-byte dari sumber verifikasi sebelumnya.
- Sistem C menghasilkan artefak *genome* deklaratif dua-bit untuk dua keluarga tugas: simbolik (`dedupe`, `swap_pairs`) dan graf (`must_visit`, `max_hops`).
- Tiga generasi per keluarga dan seed: generasi 0 tanpa fitur tambahan, generasi 1 menambahkan satu fitur, generasi 2 menggabungkan kedua fitur. Mutasi pertama bergantung pada seed; **urutan evolusi dan pilihan fitur tetap didesain manusia**.
- Setiap kandidat memiliki `candidate_id`, `parent_id`, generasi, genome, fitur, hash, serta dua skor probe. Seleksi final memakai jumlah dua skor probe; ikatan skor memilih generasi terbaru (*neutral drift*).
- Output program DSL dieksekusi oleh interpreter Python tepercaya. **Tidak ada kode Python buatan AI yang dieksekusi, tidak ada model bahasa yang dipanggil.**
- F2 menyediakan empat tugas probe validasi yang sama, dan 32 tugas akhir yang sama per seed. Bank *held-out* F4 tidak dibuat atau dibaca.
- Ledger event SHA-256, konfigurasi beku, berkas kandidat, dan checkpoint menyediakan *resume* serta verifikasi semantik ulang.

## 2. Hasil aktual lokal

| Kondisi | Probe per seed | Tugas akhir per seed | Benar / 96 | Persentase |
|---|---:|---:|---:|---:|
| A — Fixed | 12 | 32 | 79/96 | 82,29% |
| B — Adaptive catalogue | 12 | 32 | 94/96 | 97,92% |
| C — Bounded DSL evolution | 12 | 32 | 96/96 | 100,00% |

**Selisih C terhadap B:** +2 jawaban benar dari 96 (+2,08 poin persentase). Tidak ada peningkatan C dibanding B pada seed 1729 dan 4093; keduanya 32/32. Seluruh selisih berasal dari seed 2027 (B 30/32 versus C 32/32).

| Seed | A | B | C |
|---|---:|---:|---:|
| 1729 | 27/32 | 32/32 | 32/32 |
| 2027 | 26/32 | 30/32 | 32/32 |
| 4093 | 26/32 | 32/32 | 32/32 |

**Menurut split:** semua sistem benar pada 72/72 tugas development masing-masing. Pada validation akhir A 7/24, B 22/24, C 24/24. Validasi ini **berbagi template** dengan data probe; tidak dapat dibaca sebagai generalisasi pada tipe masalah baru.

## 3. Verifikasi teknis

- Total **46/46 unit test PASS**: 14 F1, 16 F2, dan 16 F3.
- **9/9 run lengkap** (3 seed × 3 kondisi) diverifikasi ulang dari input, implementasi, skor, hash hasil, dan checkpoint.
- **18 kandidat C** ditulis sebagai artefak (6 per seed) dengan hubungan parent-child yang dapat direkonstruksi.
- **153 event C** diverifikasi: 18 kelahiran kandidat, 36 probe, 3 freeze, 96 final.
- **270 event A/B** dijalankan ulang menggunakan kode F2 tetap (6 run × 45 event).
- Checkpoint dapat pulih setelah simulasi putus di antara penulisan event dan checkpoint; tidak menduplikasi event saat dilanjutkan.
- Penolakan biaya positif, pembatasan waktu, pengubahan kode sumber, pengubahan artefak kandidat, pengubahan checkpoint, perubahan hash, dan pemalsuan skor dengan perhitungan ulang hash diuji.
- Tidak ada pemanggilan model atau API eksternal; biaya tambahan API untuk harness ini Rp0.
- Notebook Colab mandiri berhasil dijalankan sebagai simulasi lokal, dengan keluaran identik dan ZIP bukti terbentuk. **Eksekusi pada akun Colab pengguna masih menunggu pengujian.**

## 4. Batas validitas dan keputusan

1. Ini **bukan** bukti AI menemukan algoritma baru secara otonom. Sistem C membuat kombinasi program dari interpreter dan dua fitur per keluarga yang **sepenuhnya dirancang manusia**.
2. Trajektori mutasi generasi 0 → satu fitur → dua fitur telah ditentukan di muka. Umpan balik hanya menentukan kandidat terpilih; urutan penemuan tidak dihasilkan agen. Dengan demikian, kemenangan 96/96 bukan bukti kausal bahwa *open-ended evolution* lebih unggul.
3. Soal pengujian akhir menggunakan template yang sama dengan probe; belum ada pengujian *unseen-template transfer*, metode baru yang tercipta tanpa arahan, atau generasi penerus yang merancang operatornya sendiri.
4. Menyamakan 12 panggilan evaluator per kondisi tidak berarti menyamakan seluruh pekerjaan pemrograman manusia dan CPU/wall-clock cost.
5. Hanya tiga seed; skor bersifat deskriptif. **Jangan mengekstrapolasi ke AGI atau ASI.**
6. Verifikasi ulang dalam proses yang sama bukan audit keamanan sandbox independen. Eksekusi Python tidak tepercaya dari agen tetap dilarang pada prototipe ini.
7. Penyimpanan lintas restart Colab yang independen, integrasi akun, dan pengujian F4 masih belum dilakukan.

**Keputusan:** `F3 Engineering Prototype: PASS (local)`; `F3 Scientific Capability Invention: OPEN / NOT PROVEN`; `F3 Colab Reproduction: PENDING`; `F4 Sealed Held-out: NOT RUN`.

## 5. Reproduksi lokal

Dari direktori yang berisi `ace_f1.py`, `ace_f2.py`, `ace_f3.py`, dan seluruh tes:

```bash
python -m unittest -v test_f1 test_f2 test_f3
python ace_f3.py all --root evidence
python ace_f3.py verify --root evidence
```

Pada HP, gunakan `ACE_F3_Evolution_Colab_v0.1.ipynb` dan unduh `ACE_F3_reproduced_evidence.zip`. Kirim ZIP ke percakapan untuk pemeriksaan silang setelah runtime Anda menjalankannya.
