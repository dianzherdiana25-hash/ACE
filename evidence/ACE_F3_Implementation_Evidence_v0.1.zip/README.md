# ACE F3 — Bounded Evolutionary DSL Pilot

Aplikasi CPU/stdlib Python, tanpa API key atau layanan berbayar. Penelitian terbatas pada dua-bit konfigurasi program deklaratif dan tugas F2; bukan LLM yang memprogram ulang dirinya sendiri.

**Kode:** `ace_f1.py` dan `ace_f2.py` adalah sumber beku F1/F2; `ace_f3.py` menambahkan kandidat deklaratif, mutasi, seleksi, catatan garis keturunan, pemulihan, dan verifikasi. `test_f1.py`, `test_f2.py`, `test_f3.py` mencakup 46 tes. `ACE_F3_Evolution_Colab_v0.1.ipynb` adalah notebook CPU yang dapat dijalankan langsung lewat HP.

**Eksekusi lokal:** `python -m unittest -v test_f1 test_f2 test_f3`, kemudian `python ace_f3.py all --root evidence` dan `python ace_f3.py verify --root evidence`.

**Bukti:** folder `local_evidence/` berisi sembilan run dari tiga kondisi dan seed yang sama, 18 kandidat C, dan ringkasan metrik. `F3_Execution_Report_v0.1.md` menjelaskan batas klaim. Bank F4 held-out tidak disentuh.

**Penggunaan di Colab:** buka https://colab.research.google.com, unggah notebook F3, gunakan Runtime → Run all, unduh ZIP hasil. Tidak perlu pip, token API, ataupun GPU.
