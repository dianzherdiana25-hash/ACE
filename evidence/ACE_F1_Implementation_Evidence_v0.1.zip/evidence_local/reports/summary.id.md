# ACE F1 — Baseline A: actual execution results

Mode: `A_FIXED` (frozen deterministic solver, no model/API).
Research hypothesis: **NOT_TESTED**. Held-out: **NOT GENERATED / NOT ACCESSED**.

- 3 preregistered seeds: 1729, 2027, 4093
- Task IDs per seed: 36 (S:12 dev+6 validation, G:12 dev+6 validation)
- Attempts: 108, passes: 83
- External API/model calls: 0; additional service charge incurred by harness: Rp0

| Family/split | PASS | Total | Success |
|---|---:|---:|---:|
| S_development | 36 | 36 | 100.0% |
| S_validation | 0 | 18 | 0.0% |
| G_development | 36 | 36 | 100.0% |
| G_validation | 11 | 18 | 61.1% |

No AGI, autonomous evolution, cross-task transfer, or held-out generalization claim is supported.
Scores may be high on development because A implements the three familiar S operations and standard Dijkstra. Validation templates are disjoint from development; they remain internal validation, not sealed F4 held-out.
A is a deterministic hand-coded algorithm; future B/C comparisons require matching initial algorithm/model and bounded candidate budgets.
Persistence across Colab restarts and isolation for untrusted generated code have NOT been demonstrated.
