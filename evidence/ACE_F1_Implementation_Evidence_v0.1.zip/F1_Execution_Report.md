# ACE F1 — Actual implementation verification

**Date:** 2026-11-04 (Asia/Jakarta).
**Engineering scope:** fixed hand-coded solver A, deterministic CPU fixtures.

## Actual results

- **12/12 blueprint acceptance scenarios PASS**, plus **2/2 supplemental tests PASS** (see unittest log).
- **108** task attempts; **83** correct answers; three preregistered seeds.
- 3/3 run ledgers verified complete (36/36 tasks/run).
- Cost incurred by experiment code: 0 model/API calls; no paid service invoked.
- Crash-resume test and ledger tamper detection: PASS.

| Split | Correct | Total |
|---|---:|---:|
| G_development | 36 | 36 |
| G_validation | 11 | 18 |
| S_development | 36 | 36 |
| S_validation | 0 | 18 |

## Acceptance decision

**F1 LOCAL ENGINEERING GATE: PASS** for the restricted **trusted, deterministic baseline A** in the ChatGPT session runtime.
**F1 USER COLAB REPLICATION: PENDING.**
**F2/F3/F4: NOT_RUN; RESEARCH_HYPOTHESIS: NOT_TESTED.**

## Limits

- The F0 Colab replication package provided a CPU smoke test, not durable persistence proof.
- Baseline does not employ an LLM. Differences between A, B, C cannot yet be interpreted scientifically.
- Development performance is unsurprising because A implements the core algorithms; S validation intentionally introduces unseen operators.
- The held-out bank for F4 is reserved but **not instantiated in this package**; no final generalization measurement.
- No genuine OS-level sandbox for untrusted AI-generated Python code and no independent controlled B/C agent exist yet.
- No user account billing audit; claims of zero additional service costs only refer to local standard-library execution.
- Output event SHA256 integrity is valid under a non-adversarial archive integrity model, not attacker-proof provenance.

## Files to reproduce

`python -m unittest -v test_f1` → `python ace_f1.py run --root evidence_new` → `python ace_f1.py verify --root evidence_new` → `python ace_f1.py summary --root evidence_new`.
