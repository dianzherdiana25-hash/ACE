# ACE F1 — Fixed Baseline Harness v0.1

**Dijalankan dan diuji pada 4 November 2026.** Ini implementasi **baseline A-Fixed**, **bukan** agen AI mandiri atau bukti pembelajaran/evolusi kecerdasan.

## Apa yang dapat dilakukan

- Generator deterministik dua keluarga: **S** (transformasi simbolik), **G** (graf dan grid).
- Distribusi pra-registrasi per seed: 12 `development` + 6 `validation` per keluarga = 36 tugas/seed. Dengan seed 1729, 2027, 4093 total 108 percobaan.
- `held-out` F4 (30 ID per keluarga; total 60) **tidak dibuat, tidak dibaca, dan tidak diuji pada F1**. Total target pilot ACE masih 96 ID unik, tetapi F1 mengimplementasikan 36 ID pra-registrasi dengan tiga instansiasi seed.
- Solver A tetap (mendukung operasi simbolik dasar dan graf standar), evaluator terpisah berbasis referensi, log berantai SHA-256, checkpoint atomik, dan pemulihan bila proses terinterupsi antara commit event dan checkpoint.
- 12 skenario penerimaan blueprint F1-T01…F1-T12 + 2 pemeriksaan tambahan; 14 tes otomatis.
- Python 3 standar, hanya CPU, tanpa akun/API/biaya layanan tambahan.

## Jalankan di Google Colab lewat HP

1. Unduh `ACE_F1_Baseline_Colab_v0.1.ipynb` dari percakapan.
2. Buka `https://colab.research.google.com/`, pilih **File → Upload notebook**.
3. Pilih **Runtime → Run all**.
4. Pastikan output menunjukkan `Ran 14 tests`, `OK`, `total_task_attempts: 108`, dan `F1_LOCAL_PASS`.
5. Unduh ZIP bukti yang ditawarkan notebook, lalu unggah ke ChatGPT untuk verifikasi hasil yang benar-benar berjalan pada sesi Colab Anda.

Notebook sudah **menyematkan sumber kode** untuk diuji sehingga tidak memerlukan instalasi paket tambahan atau mengakses jaringan. Folder runtime sementara Colab bisa hilang setelah sesi berakhir; unduh ZIP untuk menyimpan bukti. Tidak ada penyimpanan persisten otomatis ke Google Drive.

## Jalankan dari ZIP paket (PC/Python)

```bash
python -m unittest -v test_f1
python ace_f1.py run --root evidence_new
python ace_f1.py verify --root evidence_new
python ace_f1.py summary --root evidence_new
```

**Idempotensi:** perintah `run` dapat diulang dengan root dan versi sama; hasil terminal tidak dihitung lagi. Jika code hash berubah saat ada run yang masih tersimpan, resume ditolak. Untuk implementasi baru, gunakan direktori `evidence_new` terpisah, jangan memodifikasi bukti historis.

## Pengujian asli pada lingkungan ChatGPT

- `14/14` uji `unittest`: PASS (termasuk T01–T12).
- Tugas A: 108, berhasil 83 (`S dev 36/36`, `S val 0/18`, `G dev 36/36`, `G val 11/18`).
- Semua 3 ledger/run selesai dan lolos verifikasi.
- Simulasi crash setelah commit event sebelum checkpoint: PASS; resume tanpa menggandakan hasil.
- Percobaan merusak hash ledger dan proyeksi hasil ditolak.
- API/model eksternal: 0; biaya layanan tambahan dari harness Rp0. Ini bukan verifikasi saldo/tagihan akun.

## Status dan batas penting

| Aspek | Status |
|---|---|
| F1 baseline A di lingkungan sesi ChatGPT | PASS (terbatas pada kode tepercaya) |
| F1 sama di Colab milik pengguna | PENDING REPLICATION |
| Held-out sealed F4 | NOT_GENERATED; access gate denies requests in F1 |
| B Adaptive / C Evolutionary | NOT_IMPLEMENTED |
| Pembelajaran AI atau generalisasi held-out | NOT_TESTED |
| Penyimpanan persisten lintas sesi Colab | NOT_TESTED |
| Sandbox untuk menjalankan kode AI yang tak tepercaya | NOT_IMPLEMENTED / NOT_SAFE_TO_CLAIM |

**Batas keamanan:** kontrol akses held-out F1 adalah kontrak adaptor yang memfilter field, bukan isolasi OS. Seluruh kode eksperimen merupakan kode Python tepercaya dan ditulis manual. Jangan memakai paket ini untuk mengeksekusi kode generatif bebas atau memasukkan rahasia akun, kunci API, atau data pribadi. Hash berantai membantu mendeteksi perubahan, tetapi bukan bukti anti-pemalsuan dari penyerang yang mengontrol seluruh arsip. Perbandingan B/C nantinya harus memakai kemampuan awal dan batas evaluasi yang setara, serta memerlukan sandbox sesuai RES.

## Struktur

- `ace_f1.py` — generator, baseline A, oracle, evaluator, runner, checkpoint, verifikasi.
- `test_f1.py` — 12 acceptance + 2 supplemental tests.
- `evidence_local/` — 3 run aktual, events, checkpoint, response, summary, metrics.
- `F1_Acceptance_Test_Log.txt`, `F1_Verification_Log.txt` — hasil test harness lokal.
- `F1_Execution_Report.md` — ringkasan dan keputusan gerbang.
- `SHA256SUMS.txt` — hash semua artefak pada saat pengemasan.
